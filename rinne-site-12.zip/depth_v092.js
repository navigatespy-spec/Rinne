/* RINNE v0.9.2 environment presentation. Read-only: never changes gameRoom. */
'use strict';
(() => {
const themes = {"0":{"name":"地上","base":"#101f28","top":"#4c7272","light":"#ebd3a2","accent":"#e8d5a5","line":"#648176","panel":"#13282f","sub":"RETURN · SURFACE"},"1":{"name":"菌糸洞窟","base":"#081b22","top":"#214753","light":"#88d4bd","accent":"#b1dfca","line":"#477770","panel":"#10272d","sub":"MYCELIUM CAVERN"},"2":{"name":"地下森林","base":"#061b13","top":"#205238","light":"#c7dd91","accent":"#c4dd9b","line":"#587954","panel":"#122b21","sub":"SUBTERRANEAN FOREST"},"3":{"name":"捕食圏","base":"#201218","top":"#673530","light":"#c7a77a","accent":"#e7b797","line":"#845347","panel":"#301e20","sub":"PREDATOR DOMAIN"},"4":{"name":"地下海","base":"#031929","top":"#125474","light":"#7ce4e0","accent":"#9ae1e6","line":"#397e94","panel":"#0b293d","sub":"UNDERGROUND SEA"},"5":{"name":"灼熱層","base":"#201113","top":"#752b22","light":"#ffc178","accent":"#f5c086","line":"#9c593e","panel":"#301c1b","sub":"SCORCHING STRATUM"},"6":{"name":"古代生物圏","base":"#151e16","top":"#4d5832","light":"#e2c677","accent":"#e3cd94","line":"#7c7950","panel":"#252d1f","sub":"ANCIENT BIOSPHERE"},"7":{"name":"原始生命圏","base":"#081328","top":"#243674","light":"#6fe1cf","accent":"#a8d2ea","line":"#586b9e","panel":"#15223c","sub":"PRIMORDIAL LIFE"},"8":{"name":"起源層","base":"#0c0b1f","top":"#332a61","light":"#a9edec","accent":"#e4caed","line":"#766693","panel":"#211c33","sub":"ORIGIN STRATUM"}};
let identity=null,lastLevel=null,displayTimer=null,raf=null;
const clean=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const hexRGB=s=>[1,3,5].map(i=>parseInt(s.slice(i,i+2),16)).join(', ');
function ensure(){
 if(!document.getElementById('rinne-depth-background')){
  const node=document.createElement('div');node.id='rinne-depth-background';node.setAttribute('aria-hidden','true');document.body.prepend(node);
 }
 if(!document.getElementById('rinne-depth-arrival')){
  const node=document.createElement('div');node.id='rinne-depth-arrival';node.setAttribute('role','status');node.setAttribute('aria-live','polite');node.className='depth-arrival';document.body.append(node);
 }
}
function apply(level){
 const t=themes[level]||themes[1],style=document.documentElement.style;
 style.setProperty('--depth-base',t.base);style.setProperty('--depth-panel',t.panel);style.setProperty('--depth-panel-rgb',hexRGB(t.panel));
 style.setProperty('--depth-line',t.line);style.setProperty('--depth-accent',t.accent);style.setProperty('--depth-glow',t.light);
 style.setProperty('--depth-scene',`url("${window.RINNE_DEPTH_IMAGES?.[level]||`assets/depths/L${level}.svg`}")`);
 document.body.dataset.depth=String(level);
 const meta=document.querySelector('meta[name=theme-color]');if(meta)meta.content=t.base;
}
function update(room){
 if(!room?.players?.[0])return reset();
 const p=room.players[0],lv=Math.max(0,Math.min(8,Number(p.level)||0));ensure();
 document.body.classList.add('depth-active');
 const key=String(room.code||'local')+'|'+String(room.created||'');
 const changed=identity===key&&lastLevel!==null&&lastLevel!==lv,previous=lastLevel;
 apply(lv);identity=key;lastLevel=lv;
 if(changed){
  const node=document.getElementById('rinne-depth-arrival');
  const direction=lv>previous?(p.returning?'深い階層へ':'降下'):'帰還';
  node.innerHTML=`<span>${clean(direction)} · L${previous} → ${lv===0?'地上':'L'+lv}</span><strong>${clean(themes[lv].name)}</strong>`;
  clearTimeout(displayTimer);cancelAnimationFrame(raf);node.classList.remove('visible');
  raf=requestAnimationFrame(()=>{node.classList.add('visible');displayTimer=setTimeout(()=>node.classList.remove('visible'),1600);});
 }
}
function suspend(){document.body.classList.remove('depth-active');clearTimeout(displayTimer);cancelAnimationFrame(raf);document.getElementById('rinne-depth-arrival')?.classList.remove('visible');}
function reset(){identity=null;lastLevel=null;suspend();apply(1);}
function locationMarkup(p){
 const lv=Math.max(0,Math.min(8,Number(p.level)||0)),t=themes[lv];
 return `<div class="depth-location"><div><span>あなたの現在地 · ${p.returning?'帰還中':'降下中'}</span><strong>${lv===0?'地上':`LEVEL ${lv}`} <em>${clean(t.name)}</em></strong></div><div class="depth-scale" role="img" aria-label="${lv===0?'地上':`全8階層のLEVEL${lv}`}" >${Array.from({length:8},(_,i)=>`<i class="${i+1===lv?'here':i+1<lv?'above':''}"></i>`).join('')}<b>${lv===0?'0':String(lv).padStart(2,'0')} / 08</b></div></div>`;
}
window.RinneDepth={update,reset,suspend,locationMarkup,themes};
})();
