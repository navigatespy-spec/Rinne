'use strict';
(() => {
 const KEY='rinne-start-video-v1',POSTER='assets/start_world_work137.jpeg';
 let current=null;
 const motion=window.matchMedia?.('(prefers-reduced-motion: reduce)');
 const mobile=window.matchMedia?.('(max-width: 700px)');
 const connection=navigator.connection;
 function preference(){try{return localStorage.getItem(KEY)!=='off';}catch{return true;}}
 function stop(s,unload=false){s.request++;s.root.classList.remove('is-video-playing');s.video.pause();if(unload&&s.video.getAttribute('src')){s.video.removeAttribute('src');s.video.load();}}
 function reset(){const s=current;if(!s)return;current=null;s.observer?.disconnect();for(const [obj,type,fn] of s.listeners)obj.removeEventListener?.(type,fn);stop(s,true);s.video.remove();s.button.remove();}
 function mount(root){
  reset();if(!root)return;
  const video=document.createElement('video'),button=document.createElement('button');
  video.className='start-world-video';video.muted=true;video.defaultMuted=true;video.loop=true;video.playsInline=true;video.preload='none';video.poster=POSTER;video.disablePictureInPicture=true;
  video.setAttribute('muted','');video.setAttribute('playsinline','');video.setAttribute('webkit-playsinline','');video.setAttribute('aria-hidden','true');video.tabIndex=-1;
  button.type='button';button.className='btn ghost start-video-toggle';
  root.prepend(video);(root.querySelector('.landing-box')||root).append(button);
  const s={root,video,button,enabled:preference(),failed:false,request:0,listeners:[],observer:null};current=s;
  const listen=(obj,type,fn)=>{if(obj?.addEventListener){obj.addEventListener(type,fn);s.listeners.push([obj,type,fn]);}};
  const fail=()=>{if(current!==s||!video.getAttribute('src'))return;s.failed=true;sync();};
  function sync(){
   if(current!==s)return;if(!root.isConnected){reset();return;}
   const blocked=motion?.matches===true||connection?.saveData===true;
   button.disabled=blocked;button.textContent=blocked?'背景：静止画':s.failed?'背景動画を再生':s.enabled?'背景動画：ON':'背景動画：OFF';button.setAttribute('aria-pressed',String(s.enabled&&!blocked&&!s.failed));
   if(blocked||!s.enabled||s.failed||document.hidden){stop(s,blocked||!s.enabled||s.failed);return;}
   if(!video.getAttribute('src')){video.src=mobile?.matches?'assets/start_world_work158_mobile.mp4':'assets/start_world_work158.mp4';video.load();}
   const request=++s.request;try{const pending=video.play();pending?.catch(()=>{if(current===s&&s.request===request)fail();});}catch{fail();}
  }
  listen(video,'playing',()=>{if(current===s&&s.enabled&&!s.failed&&!document.hidden&&!motion?.matches&&!connection?.saveData)root.classList.add('is-video-playing');});
  listen(video,'error',fail);listen(document,'visibilitychange',sync);listen(motion,'change',sync);listen(connection,'change',sync);
  listen(button,'click',()=>{if(button.disabled)return;if(s.failed){s.failed=false;s.enabled=true;}else s.enabled=!s.enabled;try{localStorage.setItem(KEY,s.enabled?'on':'off');}catch{}sync();});
  const app=document.getElementById('app');if(app&&window.MutationObserver){s.observer=new MutationObserver(()=>{if(!root.isConnected)reset();});s.observer.observe(app,{childList:true});}
  sync();
 }
 window.RinneStartBackground={mount,reset};
})();
