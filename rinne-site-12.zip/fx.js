'use strict';
(() => {
 const KEY='rinne-fx-enabled-v1';
 let previous=null,timer=null,layer=null,enabled=true;
 try{enabled=localStorage.getItem(KEY)!=='off';}catch{}
 const reduced=()=>window.matchMedia?.('(prefers-reduced-motion: reduce)').matches===true;
 const owned=p=>[p.main,...p.support,...p.hand,...p.deck,...p.discard].filter(Boolean);
 function snapshot(r){return {key:String(r.code)+':'+String(r.created),revision:r.revision||0,phase:r.phase,winner:r.winner,players:r.players.map(p=>({seat:p.seat,name:p.name,level:p.level,returning:p.returning,guardian:Object.fromEntries(Object.entries(p.guardian||{}).map(([l,g])=>[l,{status:g.status,id:g.id}])),owned:p.seat===0?owned(p):[]})),explore:r.explore?.owner===0?{ids:[...r.explore.ids]}:null};}
 function collect(before,r){
  if(!before||before.key!==String(r.code)+':'+String(r.created)||(r.revision||0)<=before.revision)return [];
  if(r.phase==='FINISHED'&&before.phase!=='FINISHED')return [{kind:'victory',seat:r.winner,mode:r.mode,name:r.players[r.winner]?.name||''}];
  const p=r.players[0],old=before.players[0];if(!p||!old)return [];
  for(const [level,g] of Object.entries(p.guardian||{})){if(old.guardian[level]?.status==='waiting'&&['captured','forced'].includes(g.status))return [{kind:'guardian',seat:0,level:Number(level),next:p.level,returning:p.returning,method:g.status==='captured'?'CAPTURE':'FORCE'}];}
  if(p.level!==old.level)return [{kind:'level',seat:0,level:p.level,direction:p.level>old.level?'DESCEND':'ASCEND'}];
  const events=(r.effectEvents||[]).filter(e=>e.revision>=before.revision&&e.revision<(r.revision||0)&&e.seat===0);
  const capture=events.find(e=>e.type==='EXPLORE_COMPLETED'&&['META','CAPTURE'].includes(e.action));
  if(capture){const now=owned(p),id=before.explore?.ids.find(id=>now.includes(id)&&!old.owned.includes(id));return [{kind:capture.action==='META'?'meta':'capture',seat:0,id}];}
  return [];
 }
 function clear(){clearTimeout(timer);timer=null;layer?.remove();layer=null;}
 const labels={capture:['CAPTURE','新しい仲間を獲得'],meta:['EVOLUTION','生命が、次の姿へ'],guardian:['GUARDIAN BREAK','深層への道が開いた'],level:['DEEPER','新たな階層へ'],victory:['ORIGIN CLEAR','起源へ到達']};
 function play(effect){
  clear();if(!enabled||document.hidden)return;
  if(window.RinneSymbols?.isActive()&&((effect.kind==='level'&&effect.direction==='DESCEND')||effect.kind==='guardian'))return;
  const data=labels[effect.kind];if(!data)return;
  layer=document.createElement('div');layer.className='rinne-fx rinne-fx--'+effect.kind+(reduced()?' rinne-fx--still':'');layer.setAttribute('aria-hidden','true');
  const aura=document.createElement('div');aura.className='rinne-fx-aura';layer.append(aura);
  if(!reduced())for(let i=0;i<12;i++){const spark=document.createElement('i');spark.className='rinne-fx-spark';const angle=i*Math.PI/6;spark.style.setProperty('--dx',Math.round(Math.cos(angle)*140)+'px');spark.style.setProperty('--dy',Math.round(Math.sin(angle)*110)+'px');spark.style.setProperty('--delay',(i%3)*30+'ms');layer.append(spark);}
  const panel=document.createElement('div');panel.className='rinne-fx-panel';
  const kicker=document.createElement('span');kicker.className='rinne-fx-kicker';kicker.textContent=effect.kind==='level'?(effect.direction==='ASCEND'?'ASCEND':'DESCEND'):effect.kind==='victory'?(effect.mode==='RETURN'?'RETURN CLEAR':'ORIGIN CLEAR'):data[0];
  const title=document.createElement('strong');title.textContent=effect.kind==='guardian'?'L'+effect.level+' GUARDIAN 突破':effect.kind==='level'?(effect.level===0?'地上へ帰還':'LEVEL '+effect.level):effect.kind==='victory'?(effect.seat===0?'あなたの勝利！':'CPUの勝利'):data[1];
  const detail=document.createElement('span');detail.className='rinne-fx-detail';const E=window.RINNE,card=effect.id&&E?.C[E.P[effect.id]?.card_id];detail.textContent=card?.name||(effect.kind==='guardian'?effect.method+' · '+(effect.returning?'帰還開始':effect.next===8?'起源層へ':('LEVEL '+effect.next)):effect.kind==='victory'?effect.name:'RINNE');
  panel.append(kicker,title,detail);layer.append(panel);document.body.append(layer);
  timer=setTimeout(clear,effect.kind==='victory'?1200:1800);
 }
 function guardianEntrance(effect){try{
  clear();if(!enabled||document.hidden||window.RinneSymbols?.isActive())return;
  const E=window.RINNE,card=effect?.id&&E?.C[E.P[effect.id]?.card_id];if(!card||card.kind!=='GUARDIAN')return;
  layer=document.createElement('div');layer.className='rinne-fx rinne-guardian-entrance'+(reduced()?' rinne-guardian-entrance--still':'');layer.setAttribute('aria-hidden','true');
  const panel=document.createElement('div');panel.className='rinne-guardian-entrance-panel';
  const kicker=document.createElement('span');kicker.className='rinne-guardian-entrance-kicker';kicker.textContent='GUARDIAN APPROACHES';
  const art=document.createElement('img');art.className='rinne-guardian-entrance-art';art.alt='';art.src=effect.imageUrl||window.RINNE_CARD_IMAGE_OVERRIDES?.[card.id]||`assets/cards_v094/${card.id}.webp`;art.onerror=()=>art.remove();
  const name=document.createElement('strong');name.textContent=card.name;
  const detail=document.createElement('span');detail.className='rinne-guardian-entrance-level';detail.textContent='LEVEL '+card.level+' · 深層の守護者';
  panel.append(kicker,art,name,detail);layer.append(panel);document.body.append(layer);timer=setTimeout(clear,1800);
 }catch(e){clear();console.warn('RINNE guardian entrance skipped',e.message);}}
 function observe(r){try{if(!r){reset();return;}const effects=collect(previous,r);previous=snapshot(r);if(effects.length)play(effects[0]);}catch(e){clear();try{previous=snapshot(r);}catch{previous=null;}console.warn('RINNE effect skipped',e.message);}}
 function reset(){window.RinneSymbols?.reset();previous=null;clear();}
 function setEnabled(value){enabled=Boolean(value);clear();window.RinneSymbols?.clear();try{localStorage.setItem(KEY,enabled?'on':'off');}catch{}return enabled;}
 function preview(kind){try{if(kind==='guardian_entry'){const E=window.RINNE,g=E?.physical?.find(x=>E.C[x.card_id]?.kind==='GUARDIAN');guardianEntrance({id:g?.physical_id});return;}play({kind,seat:0,level:4,next:5,method:'FORCE',direction:'DESCEND',mode:'ORIGIN',name:'あなた'});}catch(e){clear();console.warn('RINNE effect skipped',e.message);}}
 document.addEventListener?.('visibilitychange',()=>{if(document.hidden)clear();});
 window.RinneFx={observe,reset,setEnabled,isEnabled:()=>enabled,preview,snapshot,collect,guardianEntrance};
})();
