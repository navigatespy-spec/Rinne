'use strict';
const Bot = (()=>{
const E=()=>window.RINNE;
const D=()=>E()?.evaluationRoom?.()||window.gameRoom;
const m=id=>E().C[E().P[id]?.card_id]||{};
const species=id=>m(id).species||'';
const isCreature=id=>['STARTER','WILD','GUARDIAN'].includes(m(id).kind);
const a=(seat,type,other={})=>{const action={type,...other};if(action.eventCopy===undefined&&E().handEventOptions){const options=E().handEventOptions(D(),seat,action);if(options.length){const reserve=new Set(campKeep(D().players[seat])),o=options.find(o=>!reserve.has(o.handId));if(o)action.eventCopy={handId:o.handId,sourceId:o.sourceId};}}return E().apply(D(),seat,action);};
const countKeyword=(p,word)=>[p.main,...p.support].filter(Boolean).filter(x=>(m(x).keyword||'').includes(word)).length;
function campChoice(p){
 const sources=(p.support||[]).filter(id=>!p.disabledSupportIds?.includes(id)&&['C130','C006','C081'].includes(m(id)?.id));
 const source=sources.find(id=>m(id)?.id==='C130')||sources[0];
 const status=['PARASITE','POISON','FEAR'].find(x=>(p.status||[]).includes(x));
 return source&&status?{id:source,status}:null;
}
function differentSpecies(a,b){return a.size>0&&b.size>0&&![...a].some(sp=>b.has(sp));}
function supportSyn(main,s,p=null){p??=D()?.players?.find(q=>q.main===main&&q.support.includes(s))||{main,support:[s],status:[]};let c=m(s),txt=c.support||'';
 if(!main||!c.synergy||!txt)return false;
 let sp=species(main),mainSet=mainSpeciesSet(p),selfSet=effectiveSpecies(p,s);
 if(/MAINと異なる種族|MAINが異なる種族/.test(txt))return differentSpecies(selfSet,mainSet);
 if(/MAINと同じ種族/.test(txt))return [...selfSet].some(x=>mainSet.has(x));
 let match=txt.match(/MAINが([^、。]+?)なら/);
 if(match){const cond=match[1];if(cond.includes('異なる'))return differentSpecies(selfSet,mainSet);if(cond.includes('同じ'))return [...selfSet].some(x=>mainSet.has(x));return cond.split('か').some(x=>mainSet.has(x));}
 if(/MAINの捕獲力を\+1/.test(txt)||/MAINのPOWERを\+1/.test(txt))return true;
 return false;
}
function synCount(p){return p.support.filter(id=>!p.disabledSupportIds?.includes(id)&&supportSyn(p.main,id,p)).length;}
// Shared species order: printed -> live START -> one simultaneous constant layer.
// Constant grants/replacements read only the pre-constant snapshot, never each other.
function speciesSnapshot(p){
 const team=[p?.main,...(p?.support||[])].filter(Boolean),pre=new Map(),out=new Map(),turn=D()?.effectTurn||0;
 const add=(set,sp)=>{if(sp&&sp!=='―')set.add(sp);};
 for(const id of team){const set=new Set(),chosen=p.startSpecies?.card===id&&p.startSpecies.turn===turn?p.startSpecies:null;
  if(!chosen?.replace)add(set,species(id));if(chosen)for(const sp of chosen.speciesList||[chosen.species])add(set,sp);
  if(p.startSupportSpecies?.card===id&&p.startSupportSpecies.turn===turn)add(set,'蟲種');pre.set(id,set);out.set(id,new Set(set));
 }
 if(!p?.main)return out;const mainBase=pre.get(p.main),support=p.support||[];
 for(const id of support)if(['C151','C177'].includes(m(id).id)&&!p.disabledSupportIds?.includes(id))out.set(id,new Set(mainBase));
 const profile=E().mainProfile?.(D(),p,['C157','C186','C200']);
 if(profile){
  const groups=support.map(id=>pre.get(id)),different=groups.length===2&&groups.every(g=>g.size)&&![...groups[0]].some(sp=>groups[1].has(sp));
  if(profile.code==='C200'||profile.code==='C157'&&different)for(const g of groups)for(const sp of g)out.get(p.main).add(sp);
  if(profile.code==='C186'&&support.length===2)for(const id of support)for(const sp of mainBase)out.get(id).add(sp);
 }
 // A borrowed HAND ability belongs to the physical HAND card for this check.
 if(p.handCopyCheck?.code==='C186'&&support.length===2)for(const id of support)add(out.get(id),m(p.handCopyCheck.handId).species);
 return out;
}
function mainSpeciesSet(p){return speciesSnapshot(p).get(p?.main)||new Set();}
function effectiveSpecies(p,id){return speciesSnapshot(p).get(id)||new Set([species(id)].filter(sp=>sp&&sp!=='―'));}
function teamDistinct(p){const groups=[p.main,...p.support].filter(Boolean).map(id=>effectiveSpecies(p,id));return groups.length===3&&groups.every((a,i)=>a.size>0&&groups.every((b,j)=>i===j||differentSpecies(a,b)));}
function speciesCondMatch(text,p,sid=null){
 const mainSet=mainSpeciesSet(p),mainSp=species(p.main),selfSp=sid?species(sid):'';
 if(/MAINと異なる種族なら/.test(text))return !!p.main&&differentSpecies(effectiveSpecies(p,sid),mainSet);
 if(/MAINと同じ種族なら/.test(text))return !!p.main&&[...effectiveSpecies(p,sid)].some(sp=>mainSet.has(sp));
 const mm=String(text).match(/MAINが([^、。]+?)なら/);
 if(mm){const cond=mm[1];if(cond.includes('異なる'))return differentSpecies(mainSet,effectiveSpecies(p,sid));if(cond.includes('同じ'))return mainSp===selfSp;return cond.split('か').some(x=>mainSet.has(x));}
 return true;
}
function opponentsOf(p){const r=D();return r?.players?.filter(q=>Number.isInteger(p.seat)?q.seat!==p.seat:q!==p)||[];}
function opponentHasStatus(p,status=null){return opponentsOf(p).some(q=>status?(q.status||[]).includes(status):(q.status||[]).length>0);}
function effectiveTeamSpecies(p){
 const out=new Set();if(!p)return out;for(const sp of mainSpeciesSet(p))if(sp&&sp!=='―')out.add(sp);for(const id of p.support||[])for(const sp of effectiveSpecies(p,id))if(sp&&sp!=='―')out.add(sp);return out;
}
function teamSpeciesCount(p){return effectiveTeamSpecies(p).size+(p?.main?(p.support||[]).filter(id=>m(id).id==='C200'&&!p.disabledSupportIds?.includes(id)).length:0);}
function targetMainCaptureBonus(cid,target,p=null){
 if(cid==='C066'){const e=D()?.explore;return !!target&&!!p&&(p.stray?.includes(target)||e?.owner===p.seat&&e.source==='stray'&&e.strayId===target&&e.ids.includes(target))?2:0;}
 const speciesById={C004:'蟲種',C018:'胞子種',C022:'樹種',C034:'蟲種',C094:'水棲種'};
 if(cid!=='C028'&&!speciesById[cid])return null;
 if(!target||!isCreature(target))return 0;
 if(cid==='C028'){const pow=Number(m(target).pow);return Number.isFinite(pow)&&pow<=2?1:0;}
 return species(target)===speciesById[cid]?1:0;
}
function lineupMainBonuses(p,cid){
 const powerSpecies={C023:['蟲種'],C041:['蟲種','樹種'],C050:['鱗種'],C096:['鱗種','水棲種'],C102:['鱗種','蟲種'],C145:['鱗種'],C190:['蟲種']};
 const differentPower=['C111','C131','C155'].includes(cid);
 if(!['C033','C128','C164','C180','C185','C191','C007','C026','C021','C153','C192','G03','C003','C020','C200'].includes(cid)&&!powerSpecies[cid]&&!differentPower)return null;
 if(['C003','C020'].includes(cid))return {power:p.support.some(id=>effectiveSpecies(p,id).has('蟲種'))?1:0,capture:0};
 if(cid==='C192')return {power:0,capture:p.status.length===0?1:0};
 if(['C007','C026'].includes(cid))return {power:0,capture:p.support.some(id=>effectiveSpecies(p,id).has('胞子種'))?1:0};
 if(['C021','C153'].includes(cid))return {power:0,capture:p.support.some(id=>differentSpecies(effectiveSpecies(p,id),mainSpeciesSet(p)))?1:0};
 if(cid==='C185')return p.support.length===0?{power:12,capture:2}:{power:0,capture:0};
 if(p.support.length!==2)return {power:0,capture:0};
 const groups=p.support.map(id=>new Set([...effectiveSpecies(p,id)].filter(sp=>sp&&sp!=='―')));
 const valid=groups.every(g=>g.size>0),common=[...groups[0]].some(sp=>groups[1].has(sp));
 if(powerSpecies[cid])return {power:valid&&groups.every(g=>[...g].some(sp=>powerSpecies[cid].includes(sp)))?(cid==='C190'?3:2):0,capture:0};
 if(differentPower)return {power:valid&&!common?2:0,capture:0};
 if(cid==='G03')return {power:0,capture:valid&&!common?1:0};
 if(cid==='C200')return {power:valid&&!common?3:0,capture:0};
 if(cid==='C180')return common?{power:2,capture:0}:valid?{power:0,capture:2}:{power:0,capture:0};
 return valid&&!common?{power:cid==='C191'?2:1,capture:1}:{power:0,capture:0};
}
function staticMainPowerBonus(p,sourceCard=null,independent=false){
 if(!p?.main||!independent&&(p.status?.includes('STUN')||p.status?.includes('SLEEP')))return 0;
 const source=sourceCard||m(p.main),t=String(source.main||'');let mt;
 if(source.id==='C158')return p.creatureDiscardTurn===(D()?.effectTurn||0)?2:0;
 const lineup=lineupMainBonuses(p,source.id);if(lineup)return lineup.power;
 if(source.id==='C137')return opponentHasStatus(p,'PARASITE')?2:0;
 if(['C168','C193'].includes(source.id))return opponentHasStatus(p,'PARASITE')?(source.id==='C193'?3:2):1;
 // These are "current board state" bonuses only. Event/attack-only bonuses are written into turnPowerBonus by the engine.
 if((mt=t.match(/SUPPORTがいなければ[^。]*合計POWERを\+(\d+)/))&&p.support.length===0)return Number(mt[1]);
 if((mt=t.match(/SUPPORT2体が異なる種族なら、合計POWERを\+(\d+)/))&&p.support.length===2&&differentSpecies(effectiveSpecies(p,p.support[0]),effectiveSpecies(p,p.support[1])))return Number(mt[1]);
 if((mt=t.match(/SUPPORT2体がどちらも([^、。]+?)なら、合計POWERを\+(\d+)/))&&p.support.length===2&&p.support.every(x=>effectiveSpecies(p,x).has(mt[1])))return Number(mt[2]);
 if((mt=t.match(/SUPPORT2体がそれぞれ([^、。]+?)なら、合計POWERを\+(\d+)/))&&p.support.length===2){const allow=mt[1].split('か');if(p.support.every(x=>[...effectiveSpecies(p,x)].some(sp=>allow.includes(sp))))return Number(mt[2]);}
 if((mt=t.match(/SUPPORT2体が([^、。]+?)なら、合計POWERを\+(\d+)/))&&p.support.length===2){const allow=mt[1].split('か');if(p.support.every(x=>[...effectiveSpecies(p,x)].some(sp=>allow.includes(sp))))return Number(mt[2]);}
 if((mt=t.match(/SUPPORT2体がいれば、合計POWERを\+(\d+)/))&&p.support.length===2)return Number(mt[1]);
 if((mt=t.match(/SUPPORT2体に共通する種族があれば、合計POWERを\+(\d+)/))&&p.support.length===2&&species(p.support[0])!=='―'&&species(p.support[0])===species(p.support[1]))return Number(mt[1]);
 if((mt=t.match(/([^、。]+?種)のSUPPORTがいれば、(?:自分の)?合計POWERを\+(\d+)/))&&p.support.some(x=>effectiveSpecies(p,x).has(mt[1])))return Number(mt[2]);
 if((mt=t.match(/PARASITE状態の相手がいれば、合計POWERを\+(\d+)/))&&opponentHasStatus(p,'PARASITE'))return Number(mt[1]);
 if((mt=t.match(/(?:POISON|FEAR|SLEEP|STATUS)状態の相手(?:MAIN)?がいれば(?:自分の)?合計POWERを\+(\d+)/))){const st=t.match(/(POISON|FEAR|SLEEP|STATUS)状態/)[1];if(st==='STATUS'?opponentHasStatus(p):opponentHasStatus(p,st))return Number(mt[1]);}
 // Deliberately exclude conditional/event words from the general fallback.
 if(!/なら|いれば|いなければ|成功後|状態|このターン|解除した後|捨てていれば|低下を受ける時|妨害/.test(t)&&(mt=t.match(/合計POWERを\+(\d+)/)))return Number(mt[1]);
 return 0;
}
function staticSupportPowerBonus(p,sid){
 if(!p?.main)return 0;const t=String(m(sid).support||'');if(!t||/成功後/.test(t))return 0;let mt;
 // Context-specific interference bonuses are not part of the idle/current POWER HUD.
 if(/妨害する時|POWERを比較する妨害|その判定中|担当GUARDIANへの挑戦でFORCEを選んだCHECK時/.test(t))return 0;
 if((mt=t.match(/もう1体のSUPPORTが、このカードと異なる種族なら、合計POWERを\+(\d+)/))){const other=(p.support||[]).find(x=>x!==sid);return other&&differentSpecies(effectiveSpecies(p,other),effectiveSpecies(p,sid))?Number(mt[1]):0;}
 if((mt=t.match(/STATUS状態の相手(?:MAIN)?がいれば(?:、)?(?:自分の)?合計POWERを\+(\d+)/)))return opponentHasStatus(p)?Number(mt[1]):0;
 for(const st of ['POISON','PARASITE','FEAR','SLEEP','STUN']){const re=new RegExp(st+'状態の相手(?:MAIN)?がいれば(?:、)?(?:自分の)?合計POWERを\\+(\\d+)');const x=t.match(re);if(x)return opponentHasStatus(p,st)?Number(x[1]):0;}
 if(!/MAINが[^、。]*以外なら|MAINがSTATUS状態なら/.test(t)&&!speciesCondMatch(t,p,sid))return 0;
 if(t.includes('MAINがSTATUS状態なら')&&!p.status?.length)return 0;
 if(/MAINが[^、。]*以外なら/.test(t)){const mm=t.match(/MAINが([^、。]*?)以外なら/);if(mm&&mainSpeciesSet(p).has(mm[1]))return 0;}
 if((mt=t.match(/合計POWERを\+(\d+)/)))return Number(mt[1]);
 return 0;
}
function guardianAssist(p,g,route){
 const rule=String(m(g.id).guardian_rule||'');if(route==='FORCE'&&!rule.includes('このGUARDIANへのFORCE判定'))return 0;if(route==='CAPTURE'&&!rule.includes('このGUARDIANへのCAPTURE判定'))return 0;
 const team=[p.main,...p.support].filter(Boolean);
 const grantsAdaptation=(id,word)=>String(m(id).keyword||'').includes(word)||(!p.disabledSupportIds?.includes(id)&&String(m(id).support||'').includes(`「${word}」を与える`));
 if(rule.includes('適応：地下海')&&!team.some(id=>grantsAdaptation(id,'適応：地下海')))return 0;
 if(rule.includes('適応：灼熱')&&!team.some(id=>grantsAdaptation(id,'適応：灼熱')))return 0;
 if(rule.includes('有効な種族が2種類以上')&&teamSpeciesCount(p)<2)return 0;
 return /\+1する/.test(rule)?1:0;
}
function forceSupportBonus(p,g){return (p.support||[]).some(id=>!p.disabledSupportIds?.includes(id)&&m(id).id==='C172')&&g?.status==='waiting'&&p.guardian?.[String(p.level)]?.id===g.id&&Number(E().C[g.id]?.level||m(g.id).level)===Number(p.level)?2:0;}
function adapted(p){return E().adaptCount(p);}
function power(p,extraPower=0){
 if(!p?.main)return 0;let score=[p.main,...(p.support||[])].filter(Boolean).reduce((n,id)=>n+(Number(m(id).pow)||0),0);
 if(!p.mainAbilityDisabled)score+=staticMainPowerBonus(p);for(const sid of p.support||[])if(!p.disabledSupportIds?.includes(sid))score+=staticSupportPowerBonus(p,sid);
 score+=(E().copyMainBonus?.(D(),p,'STATIC_POWER')||0);score+=(p.turnPowerBonus||0)-(p.turnPowerPenalty||0);if((p.status||[]).includes('POISON'))score-=1;return Math.max(0,score+extraPower);
}
function capScore(p,target){
 let n=1;if(!p?.main)return n;const main=m(p.main),text=String(main.main||'');
 if(!p.mainAbilityDisabled&&!p.status?.includes('STUN')&&!p.status?.includes('SLEEP')){const lineup=lineupMainBonuses(p,main.id),targetBonus=targetMainCaptureBonus(main.id,target,p);if(lineup)n+=lineup.capture;if(targetBonus!==null)n+=targetBonus;let mt;if(!lineup&&((mt=text.match(/SUPPORTがいなければ[^。]*捕獲力を\+(\d+)/))&&p.support.length===0))n+=Number(mt[1]);
   // C160: three different species, including MAIN, are required for the extra CAPTURE point.
   if(main.id==='C160'&&p.support.length===2&&teamDistinct(p))n+=1;
   if(!lineup&&targetBonus===null&&(mt=text.match(/捕獲力を\+(\d+)/))&&!text.includes('SUPPORTがいなければ')&&main.id!=='C160'&&!/成功した後|成功後|解除した後|使用した後|捨てた後|低下した後|このターン|START時/.test(text)){let ok=true;const restricted=text.match(/(蟲種|樹種|胞子種|獣種|鱗種|水棲種|鳥種|始原種|未知種)を捕獲する時|同種への捕獲力|遊動個体への捕獲力/);if(restricted?.[1])ok=species(target)===restricted[1];if(text.includes('同種への捕獲力'))ok=species(target)===species(p.main);if(text.includes('遊動個体への捕獲力'))ok=false;if(main.id==='C110'&&!(Number.isInteger(p.creatureCostTurn)&&p.creatureCostTurn===(D()?.effectTurn||0)))ok=false;if(ok)n+=Number(mt[1]);}}
 for(const sid of p.support||[]){if(p.disabledSupportIds?.includes(sid))continue;const t=String(m(sid).support||'');if(!speciesCondMatch(t,p,sid))continue;const mt=t.match(/捕獲力を\+(\d+)/);if(!mt)continue;
  // Event-triggered bonuses require engine-maintained state; never grant them permanently.
  if(/成功した後|成功後|解除した後|使用した後|捨てた後|低下した後|このターン/.test(t))continue;
  if(t.includes('SLEEP状態の相手がいれば')&&!opponentHasStatus(p,'SLEEP'))continue;
  if(t.includes('PARASITE状態の相手がいれば')&&!opponentHasStatus(p,'PARASITE'))continue;
  if(t.includes('STATUS状態の相手がいれば')&&!opponentHasStatus(p))continue;
  if(t.includes('MAINが未知種なら')&&!mainSpeciesSet(p).has('未知種'))continue;
  if(t.includes('MAINと異なる種族なら')&&!speciesCondMatch(t,p,sid))continue;
  let ok=true;const tc=t.match(/(蟲種|樹種|胞子種|獣種|鱗種|水棲種|鳥種|始原種|未知種)への捕獲力/);if(tc)ok=species(target)===tc[1];if(ok)n+=Number(mt[1]);}
 n+=(E().copyMainBonus?.(D(),p,'STATIC_CAPTURE',target)||0);n+=(p.turnCaptureBonus||0);
 if(p.level===2&&synCount(p)>0)n++;
 if(p.level===4&&p.main&&!(String(m(p.main).keyword||'').includes('適応：地下海')||(p.support||[]).some(id=>!p.disabledSupportIds?.includes(id)&&String(m(id).support||'').includes('「適応：地下海」を与える'))))n=Math.max(0,n-1);
 return n;
}
function guardianConditionText(g,route){
 return String(m(g.id).guardian_rule||'').split('。').filter(text=>route==='FORCE'?!text.includes('CAPTURE判定時'):!text.includes('FORCE判定時')).join('。');
}
function canForce(p,g,copyPower=0){
 const rule=guardianConditionText(g,'FORCE'),need=Number(m(g.id).force||0),value=power(p,copyPower+guardianAssist(p,g,'FORCE')+forceSupportBonus(p,g));if(value<need)return false;
 if(rule.includes('MAINがFEAR')&&p.status.includes('FEAR'))return false;if(rule.includes('MAINがPOISON')&&p.status.includes('POISON'))return false;if(rule.includes('MAINがSTUN')&&p.status.includes('STUN'))return false;
 if(rule.includes('仲間に異なる2種族以上')&&teamSpeciesCount(p)<2)return false;if(rule.includes('蟲種のSUPPORT')&&!p.support.some(id=>effectiveSpecies(p,id).has('蟲種')))return false;if(rule.includes('MAINとSUPPORT2体が必要')&&(!p.main||p.support.length<2))return false;return true;
}
function canCaptureGuardian(p,g,bonus=0,fixed=false){
 const rule=guardianConditionText(g,'CAPTURE'),threshold=Number(m(g.id).cap||0),base=fixed?5:capScore(p,g.id)+guardianAssist(p,g,'CAPTURE');if(base+bonus<threshold)return false;
 if(rule.includes('MAINがSLEEP')&&p.status.includes('SLEEP'))return false;if(rule.includes('MAINがPARASITE')&&p.status.includes('PARASITE'))return false;if(rule.includes('MAINがFEAR')&&p.status.includes('FEAR'))return false;if(rule.includes('MAINにSTATUSがあれば')&&p.status.length)return false;
 if(rule.includes('異なる2種族以上')&&teamSpeciesCount(p)<2)return false;if(rule.includes('MAINとSUPPORT2体が必要')&&(!p.main||p.support.length<2))return false;return true;
}
function netValue(id,t){const x=m(id);if(x.id==='SI02')return 1;if(x.id==='I08')return 2;if(x.id==='I09')return 3;if(x.id==='I12'&&['獣種','鱗種'].includes(species(t)))return 3;if(x.id==='I11'&&Number(m(t).pow)>=4)return 3;if(x.id==='I13'&&Number(m(t).cap)>=5)return 5;return 0;
}
function chooseNets(p,t,need,maxCount=6){const xs=p.hand.filter(id=>netValue(id,t)>0&&m(id).timing==='FREE').sort((a,b)=>netValue(a,t)-netValue(b,t));let arr=[],n=0;for(const x of xs){if(n>=need||arr.length>=maxCount)break;arr.push(x);n+=netValue(x,t);}return n>=need?arr:null;}
function captureRecipe(p,target,base){const required=Number(m(target).cap||1),need=Math.max(0,required-base),nets=chooseNets(p,target,need);
 const fixed=p.hand.find(id=>m(id).id==='I14');if(fixed&&required<=5&&need>0&&(!nets||nets.length>1))return {items:[fixed],fixed:true,bonus:0,base:5};
 return nets?{items:nets,fixed:false,bonus:nets.reduce((n,id)=>n+netValue(id,target),0),base}:null;
}
// A public-board forecast only. An actual attack may be defended; after it,
// tryGuardian re-checks real POWER/conditions instead of assuming this bonus.
function guardianPowerupPlan(p){
 const r=D(),code=m(p.main)?.id,bonus=code==='C172'?1:code==='C197'?2:0;
 const g=p.guardian?.[String(p.level)];
 if(!r||r.seat!==p.seat||!bonus||p.returning||p.moved||p.didInterfere||!g||g.status!=='waiting'||p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st))||canForce(p,g))return null;
 if(!canForce({...p,turnPowerBonus:(p.turnPowerBonus||0)+bonus},g))return null;
 const virtual={...r,phase:'ACTIONS',actionPoints:2,players:r.players.map(q=>q.seat===p.seat?p:q)},text=String(m(p.main).main);
 const targets=E().interferenceTargets(virtual,p.seat,text).filter(q=>!q.equip.some(id=>['I18','I21'].includes(m(id).id))).filter(q=>q.mainAbilityDisabled||q.status.some(st=>['SLEEP','STUN'].includes(st))||!['G10','C188'].includes(m(q.main).id));
 targets.sort((x,y)=>power(x)-power(y)||x.seat-y.seat);
 return targets.length?{target:targets[0].seat,bonus,source:code}:null;
}
function doGuardianPowerup(r,s){const p=r.players[s];if(r.phase!=='ACTIONS'||r.seat!==s||r.actionPoints<2||r.explore)return false;const plan=guardianPowerupPlan(p);if(!plan)return false;a(s,'interfere',{target:plan.target});return true;}
// When no replacement SUPPLY remains, acquisition must be viable without nets.
// Immediate guardian routes keep their higher priority. Use public pile counts only.
function comboScore(p,main,support){const tmp={...p,main,support};let n=power(tmp)*5+capScore(tmp,main)*2+synCount(tmp)*1.5;if(p.level===1)n+=support.length*6;else if(!p.returning&&p.level>=2)n+=power(tmp)*4;if(p.level===4)n+=adapted(tmp)*3;if(p.level===7)n+=new Set([main,...support].filter(Boolean).map(species)).size;
 const g=p.guardian?.[String(p.level)];if(g?.status==='waiting'&&!p.returning){
 if(canForce(tmp,g))n+=10000;else{const target=g.id,needed=Math.max(0,Number(m(target).cap||0)-capScore(tmp,target)-guardianAssist(tmp,g,'CAPTURE')),nets=chooseNets(tmp,target,needed);
 if(nets&&canCaptureGuardian(tmp,g,nets.reduce((v,id)=>v+netValue(id,target),0)))n+=9000;else if(guardianPowerupPlan(tmp))n+=8500;else {const exhausted=D()?.market?.length===0&&D()?.supply?.length===0;const recoveryCapture=exhausted?Math.max(capScore(tmp,target),...(p.stray||[]).map(id=>capScore(tmp,id))):capScore(tmp,target);n+=recoveryCapture*(exhausted?80:20);}}
 }return n;
}
function bestLineup(p,pool=null){
 pool??=[...new Set([p.main,...p.support,...p.hand.filter(isCreature)].filter(Boolean))];
 let best={score:-Infinity,ids:[p.main,...p.support].filter(Boolean)};
 for(const x of pool)for(const y of [null,...pool.filter(z=>z!==x)])for(const z of [null,...pool.filter(k=>k!==x&&k!==y)]){
  if(y===null&&z!==null)continue;const support=[y,z].filter(Boolean),score=comboScore(p,x,support);
  if(score>best.score)best={score,ids:[x,...support]};
 }
 return best;
}
function arrange(r,seat){const p=r.players[seat],best=bestLineup(p);if(!best.ids.length)return;
 if(best.ids.join(',')!==[p.main,...p.support].filter(Boolean).join(','))a(seat,'rearrange',{ids:best.ids});
}
function captureImprovesLineup(p,target,spent,currentScore=null){
 if(!spent?.length||p.returning||p.level<2||p.guardian?.[String(p.level)]?.status!=='waiting')return true;
 const next={...p,hand:[...p.hand.filter(id=>!spent.includes(id)),target]};
 return bestLineup(next).score>(currentScore??bestLineup(p).score);
}
function metaResultScore(p,target,plan){
 const spent=new Set([...plan.materials,...plan.metaItems]);
 const next={...p,main:spent.has(p.main)?null:p.main,support:p.support.filter(id=>!spent.has(id)),hand:[...p.hand.filter(id=>!spent.has(id)),target]};
 return bestLineup(next).score;
}
function handMetaUpgrade(p,target,plan){return plan.materials.length>=2&&plan.materials.every(id=>p.hand.includes(id))&&Number(m(target).pow||0)>Math.max(...plan.materials.map(id=>Number(m(id).pow||0)));}
function metaImprovesLineup(p,target,plan,currentScore=null){
 if(p.returning||p.level<2||p.guardian?.[String(p.level)]?.status!=='waiting')return true;
 return metaResultScore(p,target,plan)>(currentScore??bestLineup(p).score)||handMetaUpgrade(p,target,plan);
}
function campKeep(p){
 if(p.returning||p.level<2)return [];
 const g=p.guardian?.[String(p.level)];if(g?.status!=='waiting')return [];
 const need=Math.max(0,Number(m(g.id).cap||0)-capScore(p,g.id)-guardianAssist(p,g,'CAPTURE'));if(!need||canForce(p,g))return [];
 const nets=p.hand.filter(id=>netValue(id,g.id)>0&&m(id).timing==='FREE').sort((x,y)=>netValue(y,g.id)-netValue(x,g.id));
 let total=0;const keep=[];for(const id of nets){if(total>=need||keep.length>=3)break;keep.push(id);total+=netValue(id,g.id);}
 // Preserve a feasible, improving META recipe using only our cards and the public catalogue.
 // Never inspect a hidden wild pile or another player's hand/deck.
 if(keep.length<3){
  const knownOwn=new Set([p.main,...p.support,...p.hand,...p.deck,...p.discard].filter(Boolean));
  const publicElsewhere=new Set((D()?.players||[]).filter(q=>q.seat!==p.seat).flatMap(q=>[q.main,...q.support,...q.stray].filter(Boolean)));
  const current=bestLineup(p).score;let best=null;
  for(const card of E().cards.filter(c=>c.kind==='WILD'&&Number(c.level)===Number(p.level))){
   const target=E().physical.find(x=>x.card_id===card.id)?.physical_id;
   if(!target||knownOwn.has(target)||publicElsewhere.has(target))continue;
   const plan=metaPlan(p,target);if(!plan)continue;
   const reserve=[...new Set([...plan.materials.filter(id=>p.hand.includes(id)),...plan.metaItems])];
   const combined=[...new Set([...keep,...reserve])];if(!reserve.length||combined.length>3)continue;
   const gain=Math.max(metaResultScore(p,target,plan)-current,handMetaUpgrade(p,target,plan)?Number(m(target).pow||0)-Math.max(...plan.materials.map(id=>Number(m(id).pow||0))):0);if(gain<=0)continue;
   if(!best||gain>best.gain||gain===best.gain&&combined.length<best.ids.length)best={gain,ids:combined};
  }
  if(best)return best.ids;
 }
 return keep;
}
function moveAllowed(p){if(p.returning)return p.level>=1;if(p.level===1)return !!p.main&&p.support.length===2;return false;
}
function doMove(r,s){const p=r.players[s];if(p.moved||!moveAllowed(p))return false;a(s,'move',{});return true;
}
function metaPlan(p,target){
 const goal=m(target);if(goal.kind==='GUARDIAN')return null;
 const pool=[...new Set([...p.hand,p.main,...p.support].filter(id=>id&&isCreature(id)&&Number.isFinite(Number(m(id).meta))&&species(id)===goal.species))];
 const items=p.hand.filter(id=>['I22','I23','I24','I25'].includes(m(id).id)&&(m(id).id!=='I23'||['樹種','胞子種'].includes(goal.species))&&(m(id).id!=='I24'||goal.species==='蟲種'));
 let best=null;
 for(let mask=1;mask<2**pool.length;mask++){
  const materials=pool.filter((_,i)=>mask&(2**i));if(materials.length<2)continue;
  if(materials.some(id=>Number(m(id).pow||0)>Number(goal.pow||0)))continue;
  const sum=materials.reduce((n,id)=>n+Number(m(id).meta||0),0);
  for(let im=0;im<2**items.length;im++){
   const metaItems=items.filter((_,i)=>im&(2**i)),bonus=metaItems.reduce((n,id)=>n+(m(id).id==='I22'?1:2),0);
   if(sum+bonus<Number(goal.meta||0))continue;
   const board=materials.filter(id=>id===p.main||p.support.includes(id)).length;
   const cost=materials.length+board*4+metaItems.length*1.5+materials.reduce((n,id)=>n+Number(m(id).pow||0)*.2,0);
   if(!best||cost<best.cost)best={materials,metaItems,cost};
  }
 }
 return best;
}
function tryExploreRecovery(r,s){const p=r.players[s],e=r.explore;if(e?.owner!==s)return false;
 const options=E().exploreTimingOptions(r,s);
 const more=options.filter(o=>o.kind==='more'&&o.item&&o.ready).sort((x,y)=>y.amount-x.amount)[0];
 if(more){a(s,'explore_more',{sourceId:more.id});return true;}
 const redraw=options.filter(o=>(o.kind==='redraw'||o.kind==='copy_hand_redraw')&&o.ready&&(o.kind!=='copy_hand_redraw'||!campKeep(p).includes(o.id))).sort((x,y)=>Number(x.item)-Number(y.item));
 for(const o of redraw){let tribe;
  if(m(o.id).id==='I02'){
   tribe=e.redrawSpecies?.[o.id];if(!tribe){const seen=new Set(e.ids.map(species));const known=[p.main,...p.support,...p.hand.filter(isCreature)].filter(Boolean).map(species);const all=[...new Set(E().cards.filter(c=>c.kind==='WILD').map(c=>c.species))];tribe=all.filter(sp=>!seen.has(sp)).sort((x,y)=>known.filter(sp=>sp===y).length-known.filter(sp=>sp===x).length)[0];}
   if(!tribe||e.ids.some(id=>species(id)===tribe))continue;
  }
  if(!e.ids.length)return false;
  const target=[...e.ids].sort((x,y)=>Number(m(x).pow||0)-Number(m(y).pow||0)||Number(m(y).cap||0)-Number(m(x).cap||0))[0];
  a(s,'explore_redraw',{sourceId:o.id,id:target,...(tribe?{species:tribe}:{}),...(o.kind==='copy_hand_redraw'?{copyHandId:o.id,copySourceId:o.copySourceId}:{})});return true;
 }
 return false;
}
function exploreChoose(r,s){const p=r.players[s],e=r.explore;if(!e||e.owner!==s)return false;
 const extra=E().exploreTimingOptions(r,s).find(o=>o.kind==='more'&&!o.item&&o.ready&&o.amount>0);
 if(extra){a(s,'explore_more',{sourceId:extra.id});return true;}
 // Only use verified, available exploration COPY sources. One use per exploration.
 const copyOptions=E().exploreTimingOptions(r,s).filter(o=>['copy_more','copy_hand_more'].includes(o.kind)&&o.ready&&(o.amount>0||o.kind==='copy_hand_more'&&o.amount===0&&(p.deck.length||p.discard.length)&&!campKeep(p).includes(o.id)));
 if(copyOptions.length){
  copyOptions.sort((x,y)=>y.amount-x.amount||String(x.copySourceId).localeCompare(String(y.copySourceId)));
  const choice=copyOptions[0];
  a(s,'explore_more',{sourceId:choice.id,copySourceId:choice.copySourceId,...(choice.kind==='copy_hand_more'?{copyHandId:choice.id}:{})});
  return true;
 }

 // 探索能力全414欄の完全な自動処理は行わない。ここでは捕獲の基礎補正だけ確認。
 const captureCopies=[];
 if(p.main&&['C079','C122','C149','C154','C181'].includes(m(p.main)?.id)&&!e.copyCaptureUsed){
  for(const x of E().copyTargetCandidates(r,s,m(p.main).id,'MAIN')){
   const pre=E().copyActivationPreflight(r,s,p.main,x.physicalId,'MAIN');
   if(pre.ok)captureCopies.push({id:x.physicalId,execution:pre.execution,mode:'MAIN'});
  }
 }
 if(!p.actedHand){
  for(const handId of p.hand.filter(x=>['C079','C154','C181'].includes(m(x)?.id))){
   for(const x of E().copyTargetCandidates(r,s,m(handId).id,'HAND')){
    const pre=E().copyActivationPreflight(r,s,handId,x.physicalId,'HAND');
    if(pre.ok)captureCopies.push({handId,id:x.physicalId,execution:pre.execution,mode:'HAND',costCaptureBonus:E().creatureCostCaptureBonus(r,p)});
   }
  }
 }
 const currentLineupScore=bestLineup(p).score;
 let options=e.ids.map(id=>{let t=m(id),base=capScore(p,id),needed=Math.max(0,Number(t.cap||1)-base);const recipe=captureRecipe(p,id,base);let nets=recipe?.items||null;let netBonus=recipe?.bonus||0;if(recipe?.fixed)base=5;
 let useCopy=null;
 if(base+netBonus<Number(t.cap||1)){
  const choices=captureCopies.filter(c=>c.mode==='HAND'||!E().copyMainBonus(r,p,'STATIC_CAPTURE',id)).map(c=>({...c,amount:c.mode==='HAND'?E().copyCaptureAmount(r,p,c.execution,id,true,c.handId):E().copyCaptureAmount(r,p,c.execution,id)})).filter(c=>c.amount>0||c.mode==='HAND'&&c.execution?.sourceCard?.id==='C186'&&p.support.length===2);
  choices.sort((a,b)=>(a.mode==='MAIN'?0:1)-(b.mode==='MAIN'?0:1)||b.amount-a.amount);
  for(const c of choices){
   const assisted=captureRecipe(p,id,base+c.amount+(c.costCaptureBonus||0));
   if(assisted&&!assisted.fixed&&base+c.amount+(c.costCaptureBonus||0)+assisted.bonus>=Number(t.cap||1)){
    useCopy=c;nets=assisted.items;netBonus=assisted.bonus;break;
   }
  }
 }
 let feasible=base>=Number(t.cap||1)||!!nets||!!useCopy;
 if(feasible&&nets?.length&&!captureImprovesLineup(p,id,nets,currentLineupScore))feasible=false;
 let val= 6 + Number(t.pow||0)*(p.level>=3?3.5:.5) +(p.level===4&&((t.keyword||'')+' '+(t.support||'')).includes('適応：地下海')?16:0)+(p.level===2&&t.synergy?10:0)+(p.level===5&&(t.keyword||t.support||'').includes('適応：灼熱')?3:0)+(p.level===7&&!new Set([p.main,...p.support].filter(Boolean).map(species)).has(t.species)?4:0);
 if(feasible)val+=7; else val-=20;
 // Prefer an acquisition that improves the next START lineup, including capture synergies.
 if(feasible){const next={...p,hand:[...p.hand.filter(x=>!(nets||[]).includes(x)),id]};val+=Math.max(0,bestLineup(next).score-currentLineupScore);}
 val-=(nets?.length||0)*2;return {id,base,need:needed,nets,val,feasible,useCopy};});
 options.sort((x,y)=>y.val-x.val);
 let choice=options.find(o=>o.feasible);
 const evolves=options.map(o=>({o,plan:metaPlan(p,o.id)})).filter(x=>x.plan&&metaImprovesLineup(p,x.o.id,x.plan,currentLineupScore)).map(x=>({...x,value:x.o.val+(x.o.feasible?0:27)+(x.o.nets?.length||0)*2-x.plan.cost})).sort((x,y)=>y.value-x.value);
 const evo=evolves[0];
 if(evo&&(!choice||evo.value>choice.val)){a(s,'explore_resolve',{method:'META',id:evo.o.id,materials:evo.plan.materials,metaItems:evo.plan.metaItems});return true;}
 if(choice){a(s,'explore_resolve',{method:'CAPTURE',id:choice.id,captureItems:choice.nets||[],...(choice.useCopy?{copySourceId:choice.useCopy.id,...(choice.useCopy.mode==='HAND'?{copyHandId:choice.useCopy.handId}:{})}:{}),directSupport:p.level===1&&!p.returning&&p.l1CaptureCount<2&&p.support.length<2});return true;}
 if(tryExploreRecovery(r,s))return true;
 const v=options[0];if(v){a(s,'explore_resolve',{method:'CAPTURE',id:v.id,awaitCaptureAid:true,directSupport:p.level===1&&!p.returning&&p.l1CaptureCount<2&&p.support.length<2});return true;}
 a(s,'explore_resolve',{method:'SKIP'});return true;
}
// Public own strays remain legal acquisitions after the wild and supply run dry.
// Evaluate the real target: C066's printed bonus is target-specific.
function strayRecoveryTarget(p){const r=D(),g=p.guardian?.[String(p.level)];if(!r||p.returning||!g||g.status!=='waiting'||r.market.length||r.supply.length||!p.stray?.length)return null;
 let best=null;for(const id of p.stray){const recipe=captureRecipe(p,id,capScore(p,id)),plan=metaPlan(p,id),capture=!!recipe&&(!recipe.items.length||captureImprovesLineup(p,id,recipe.items)),evolve=!!plan&&metaImprovesLineup(p,id,plan);if(!capture&&!evolve)continue;const next={...p,hand:[...p.hand,id],stray:p.stray.filter(x=>x!==id)},value=Math.max(capture?bestLineup(next).score:-Infinity,evolve?metaResultScore(p,id,plan):-Infinity);if(!best||value>best.value)best={id,value};}return best?.id||null;
}
function chooseMarket(r,s){const p=r.players[s];let options=r.market.map(id=>({id,cost:Number(m(id).cost||0),value:/捕獲力を\+/.test(m(id).effect||'')?([3,6,8].includes(p.level)?24:8):/追加で[１２12]/.test(m(id).effect||'')?4:1})).filter(x=>x.cost>=1&&p.hand.length>=x.cost);
 if(!options.length)return false;options.sort((a,b)=>b.value-a.value||a.cost-b.cost);let take=options[0];if(take.value<4&&p.hand.length<4)return false;
 if(tryEventCopy(r,s,'BUY'))return true;
 a(s,'buy',{id:take.id,pay:p.hand.slice(0,take.cost)});return true;
}
function tryGuardian(r,s){const p=r.players[s];if(p.returning||p.moved||p.level<2||p.level>8)return false;const g=p.guardian[String(p.level)];if(!g||g.status!=='waiting')return false;if(canForce(p,g)){a(s,'guardian_challenge',{method:'FORCE'});return true;}for(const o of E().handPowerOptions?.(r,s)||[]){const trial={...p,turnPowerBonus:(p.turnPowerBonus||0)+o.costPowerBonus,creatureDiscardTurn:r.effectTurn||0};if(canForce(E().handCheckPlayer(trial,o),g,o.amount)){a(s,'guardian_challenge',{method:'FORCE',copyHandId:o.handId,copySourceId:o.sourceId});return true;}}const recipe=captureRecipe(p,g.id,capScore(p,g.id)+guardianAssist(p,g,'CAPTURE'));if(recipe&&canCaptureGuardian(p,g,recipe.bonus,recipe.fixed)){a(s,'guardian_challenge',{method:'CAPTURE',captureItems:recipe.items});return true;}for(const copy of E().guardianCopyOptions(r,s).sort((x,y)=>y.amount-x.amount)){const trial=E().handCheckPlayer({...p,turnCaptureBonus:(p.turnCaptureBonus||0)+copy.costCaptureBonus},copy),bonus=copy.compound?0:copy.amount,assisted=captureRecipe(p,g.id,capScore(trial,g.id)+guardianAssist(trial,g,'CAPTURE')+bonus);if(assisted&&!assisted.fixed&&canCaptureGuardian(trial,g,assisted.bonus+bonus,false)){a(s,'guardian_challenge',{method:'CAPTURE',captureItems:assisted.items,copyHandId:copy.handId,copySourceId:copy.sourceId});return true;}}return false;
}
function resolvePendingCpu(){
 const interrupt=D()?.interruptPending;
 if(interrupt){const e=interrupt.window;if(e.owner===0)return false;const r=D(),p=r.players[e.owner];let ids=[];
  if(e.kind==='C055_TARGET'){ids=[[...e.candidates].sort((x,y)=>Number(r.players[x].status.includes('PARASITE'))-Number(r.players[y].status.includes('PARASITE'))||power(r.players[y])-power(r.players[x])||x-y)[0]];}
  else if(e.kind==='C055_DEFENSE'){const o=[...e.options].sort((x,y)=>Number(x.asMainCost)-Number(y.asMainCost)||(['I19','I17','I15'].indexOf(m(x.id).id)-['I19','I17','I15'].indexOf(m(y.id).id)))[0];if(o)ids=[o.key];}
  else if(e.kind==='HAND_COPY'){const reserve=new Set(campKeep(p)),o=e.options.find(o=>!reserve.has(o.handId));if(o)ids=[o.key];}
  else if(e.kind==='ORDER')ids=[...e.candidates].sort((a,b)=>(isCreature(b)?Number(m(b).pow||0)*3:Number(m(b).cost||0))-(isCreature(a)?Number(m(a).pow||0)*3:Number(m(a).cost||0)));
  else if(e.required)ids=e.candidates.slice(0,1);
  else if(e.kind==='ITEM_HAND')ids=e.candidates.slice(0,1);
  else if(e.kind==='INTERFERENCE_RESCUE'&&e.owner!==e.source)ids=e.candidates.slice(0,1);
  else if(e.kind==='CAPTURE_FAILURE')ids=[e.candidates.find(id=>m(id).id==='I10')||e.candidates[0]];
  else if(e.kind==='CAPTURE_AID'){const q=r.players[e.target];if(p.level>q.level&&!q.returning&&q.level<8){const need=Math.max(0,(e.required||0)-(e.base||0));ids=e.candidates.slice(0,Math.ceil(need/2));}}
  else if(e.kind==='POWER_RESCUE'&&e.owner!==e.source){const source=r.players[e.source],target=r.players[e.target];if(source.level>=target.level)ids=e.candidates.slice(0,1);}
  a(e.owner,'interrupt_reply',{ids});return true;
 }
 const r=D();if(!r)return false;
 if(r.targetEffectPending){const e=r.targetEffectPending;if(e.owner===0)return false;const candidates=E().targetEffectCandidates(r,e);if(!candidates.length)throw Error('効果の対象候補がありません');let choice=candidates[0];
 if(e.mode==='POWER_LOSS')choice=[...candidates].sort((x,y)=>power(r.players[y])-power(r.players[x])||x-y)[0];
 else if(e.mode==='HAND_DISCARD')choice=[...candidates].sort((x,y)=>Number(isCreature(x))-Number(isCreature(y))||Number(m(x).pow||0)-Number(m(y).pow||0))[0];
 else if(['SUPPORT_DISCARD','SUPPRESS_SUPPORT','STRAY_TAKE'].includes(e.mode))choice=[...candidates].sort((x,y)=>Number(m(y).pow||0)-Number(m(x).pow||0)||x.localeCompare(y))[0];
 a(e.owner,'target_effect_reply',{choice});return true;}
 if(r.pendingAttack&&!r.supportDisablePending&&!r.statusSacrificePending&&!r.statusCleansePending&&!r.effectPending&&!r.fieldDiscardPending){
  const seat=r.pendingAttack.target;if(seat===0)return false;
  const p=r.players[seat],g=p.guardian?.[String(p.level)];
  const choices=E().reactionOptions(r,seat).map(o=>({...o,value:(o.asMainCost?0:100)+(isCreature(o.id)?Number(m(o.id).pow||0)*5:0)+(g?netValue(o.id,g.id)*20:0)+(['I15','I17','I19','I20'].includes(m(o.id).id)?10:0)}));
  choices.sort((x,y)=>x.value-y.value);const choice=choices[0];a(seat,'reaction_reply',choice?{id:choice.id,asMainCost:choice.asMainCost}:{});return true;
 }

 if(r.supportDisablePending){const e=r.supportDisablePending;if(e.owner===0)return false;a(e.owner,'support_disable_reply',{id:e.candidates[0]});return true;}
 if(r.statusSacrificePending){const e=r.statusSacrificePending;if(e.owner===0)return false;a(e.owner,'status_sacrifice_reply',{use:true});return true;}
 if(r.statusCleansePending){const e=r.statusCleansePending;if(e.owner===0)return false;const p=r.players[e.owner];const status=['STUN','SLEEP','PARASITE','POISON','FEAR'].find(st=>e.statuses.includes(st)&&p.status.includes(st));a(e.owner,'status_cleanse_reply',status?{status}:{});return true;}
 const pending=r.effectPending;
 if(!pending&&r.fieldDiscardPending){const e=r.fieldDiscardPending;if(e.owner===0)return false;const p=r.players[e.owner];a(e.owner,'field_discard',{id:p.hand.find(id=>!isCreature(id))||p.hand.at(-1)});return true;}
 if(!pending||pending.owner===0)return false;
 const p=r.players[pending.owner];
 if(!p)return false;
 const d=p.hand.find(id=>!isCreature(id))||p.hand[p.hand.length-1];
 if(!d)throw Error('CPUの誘発後破棄が未解決');
 a(pending.owner,'resolve_effect',{id:d});
 return true;
}
// Bind an event passive only once an existing policy has selected a real action.
// Never spend an ACTION, replace a binding, or acquire a used ITEM trigger.
function tryEventCopy(r,s,event){const p=r.players[s];
 if(r.phase!=='ACTIONS'||r.seat!==s||r.actionPoints<1||r.explore||!p.main||p.mainCopy)return false;
 const codes=event==='HAND_CYCLE'?['S12','C011']:event==='EXPLORE'?['C074','C124','C176']:event==='STATUS_REMOVE'?['C182']:event==='ITEM'?['S14','C067','C140']:['S04','C103'];
 if(event==='EXPLORE'&&!(r.wild[String(p.level)]?.length||r.wildDiscard[String(p.level)]?.length))return false;
 if(event==='ITEM'&&(r.abilityUsage?.[String(s)]?.[p.main+':COPY_ITEM']||!p.deck.length&&!p.discard.length))return false;
 const targets=E().copyTargetCandidates(r,s,m(p.main).id,'MAIN').filter(x=>codes.includes(m(x.physicalId)?.id)).filter(x=>{
  const pre=E().copyActivationPreflight(r,s,p.main,x.physicalId,'MAIN');
  return pre.ok&&pre.execution?.kind==='COPIED_PROFILE';
 }).sort((x,y)=>String(x.physicalId).localeCompare(String(y.physicalId)));
 if(!targets.length)return false;
 a(s,'copy_main',{sourceId:targets[0].physicalId});return true;
}
function useUtilityItem(r,s,action){if(!(action.status&&tryEventCopy(r,s,'STATUS_REMOVE'))&&!tryEventCopy(r,s,'ITEM'))a(s,'use_item',action);return true;}
function doUtilityItem(r,s){const p=r.players[s];
 const status=['SLEEP','STUN','POISON','FEAR','PARASITE'].find(st=>p.status.includes(st));
 const heal=p.hand.find(id=>['SI04','I16'].includes(m(id).id));if(status&&heal){useUtilityItem(r,s,{id:heal,status});return true;}
 if(p.main&&!p.equip.length){const equip=p.hand.find(id=>['I18','I21'].includes(m(id).id));if(equip){useUtilityItem(r,s,{id:equip});return true;}}
 const recycle=p.hand.find(id=>m(id).id==='I35');if(recycle){const g=p.guardian?.[String(p.level)],used=r.removedItems.filter(id=>r.usedItemOwners?.[id]===s&&m(id).id!=='I35');
  const useful=used.map(id=>({id,value:(g&&netValue(id,g.id)>0?20+netValue(id,g.id):0)+(status&&['SI04','I16'].includes(m(id).id)?15:0)+(['I33','I34','I32'].includes(m(id).id)?5:0)})).filter(x=>x.value>0).sort((x,y)=>y.value-x.value)[0];
  if(useful){useUtilityItem(r,s,{id:recycle,card:useful.id});return true;}}
 const drawItem=p.hand.find(id=>['I33','I34'].includes(m(id).id));if(drawItem){useUtilityItem(r,s,{id:drawItem});return true;}
 const exchange=p.hand.find(id=>m(id).id==='I32');if(exchange){const reserve=new Set(campKeep(p));const pay=p.hand.filter(id=>id!==exchange&&!reserve.has(id)).sort((x,y)=>Number(isCreature(x))-Number(isCreature(y))||Number(m(x).pow||0)-Number(m(y).pow||0)).slice(0,2);if(pay.length){useUtilityItem(r,s,{id:exchange,pay});return true;}}
 const thin=p.hand.find(id=>m(id).id==='I36'),trash=p.hand.find(id=>m(id).id==='SI01');if(thin&&trash){useUtilityItem(r,s,{id:thin,card:trash});return true;}
 return false;
}
function doMainStatusCleanse(r,s){
 const p=r.players[s];if(r.phase!=='ACTIONS'||r.seat!==s||r.actionPoints<1||r.explore||!p.main||p.mainAbilityDisabled||!E().mainStatusCleanseSource(r,p)||p.status.some(st=>['SLEEP','STUN'].includes(st)))return false;
 const g=p.guardian?.[String(p.level)],rule=g?.status==='waiting'?String(m(g.id).guardian_rule||''):'';
 const blocked=['FEAR','PARASITE','POISON'].find(st=>p.status.includes(st)&&rule.includes('MAINが'+st));
 const status=blocked||['POISON','FEAR','PARASITE'].find(st=>p.status.includes(st));if(!status)return false;
 a(s,'main_status_cleanse',{status});return true;
}
// Use a spare ACTION only as recovery when the current wild piles are empty.
// Do not spend an exploration ACTION proactively or read hidden deck contents.
function doMainHandCycle(r,s){const p=r.players[s];
 if(r.phase!=='ACTIONS'||r.seat!==s||r.actionPoints<2||r.explore||p.returning||!p.main||p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st))||!p.deck.length)return false;
 if(r.wild[String(p.level)]?.length||r.wildDiscard[String(p.level)]?.length)return false;
 const reserve=new Set(campKeep(p)),id=p.hand.find(id=>m(id).id==='SI01'&&!reserve.has(id));if(!id)return false;
 if(!E().mainHandCycleSource(r,p))return tryEventCopy(r,s,'HAND_CYCLE');
 a(s,'main_hand_cycle',{id});return true;
}
// Use supported FREE interference ITEMs to realize an available success DRAW.
// Target selection reads public field/status/POWER only, never enemy HAND.
function successDrawItemChoices(r,p){const s=p.seat;
 const choices=[];
 for(const id of p.hand){const code=m(id).id;if(!['I27','I30','I31'].includes(code))continue;
  for(const q of r.players){if(q.seat===s||q.level!==p.level||!q.main)continue;
   if(code==='I27'&&q.status.includes('STUN')||code==='I30'&&q.status.includes('FEAR')||code==='I31'&&power(q)<=0)continue;
   if(q.equip.some(id=>['I18','I21'].includes(m(id).id)))continue;
   choices.push({id,target:q.seat});
  }
 }
 return choices;
}
function successDrawCopyValue(r,p,execution){const code=execution?.sourceCard?.id;if(!['C133'].includes(code)||!p.deck.length&&!p.discard.length||r.abilityUsage?.[String(p.seat)]?.[p.main+':COPY_SUCCESS_'+code]||!successDrawItemChoices(r,p).length)return 0;return code==='C133'&&p.support.some(id=>effectiveSpecies(p,id).has('胞子種'))?7:3;}
function doSuccessDrawItem(r,s){const p=r.players[s];
 if(r.phase!=='ACTIONS'||r.seat!==s||r.actionPoints<1||r.explore||!p.main||p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st))||!p.deck.length&&!p.discard.length)return false;
 const choices=successDrawItemChoices(r,p);
 if(!choices.length)return false;
 const profile=E().interferenceSuccessDrawProfile(r,p);
 if(profile){if(!profile.available)return false;a(s,'use_item',choices[0]);return true;}
 if(p.mainCopy||!['C079','C122','C149','C154','C181'].includes(m(p.main).id))return false;
 const targets=E().copyTargetCandidates(r,s,m(p.main).id,'MAIN').filter(x=>{
  const pre=E().copyActivationPreflight(r,s,p.main,x.physicalId,'MAIN'),code=pre.sourceCardId;
  return pre.ok&&['C133'].includes(code)&&!r.abilityUsage?.[String(s)]?.[p.main+':COPY_SUCCESS_'+code];
 }).sort((x,y)=>String(x.physicalId).localeCompare(String(y.physicalId)));
 if(!targets.length)return false;a(s,'copy_main',{sourceId:targets[0].physicalId});return true;
}
function doTargetItem(r,s){const p=r.players[s];if(r.phase!=='ACTIONS'||r.seat!==s||r.explore||r.actionPoints<1)return false;
 for(const id of p.hand){const code=m(id).id;if(!['I28','I29'].includes(code))continue;
 const target=r.players.filter(q=>q.seat!==s&&q.level===p.level&&!q.equip.some(id=>['I18','I21'].includes(m(id).id))).find(q=>code==='I28'?q.stray.length:q.support.some(id=>!q.disabledSupportIds?.includes(id)&&!!m(id).support));
 if(target){a(s,'use_item',{id,target:target.seat});return true;}}
 return false;
}
function doPushback(r,s){const p=r.players[s];if(p.returning||p.didInterfere||r.actionPoints<2)return false;const options=[...E().pushbackTargets(r,s).map(q=>({target:q.seat})),...(E().handPowerPushbackOptions?.(r,s)||[]).flatMap(o=>o.targets.map(target=>({target,copyHandId:o.handId,copySourceId:o.sourceId})))];for(const o of options){if(r.players[o.target].level!==1)continue;const reserve=new Set(campKeep(p)),id=p.hand.filter(id=>isCreature(id)&&id!==o.copyHandId&&!reserve.has(id)).sort((x,y)=>Number(m(x).pow)-Number(m(y).pow))[0];if(!id)continue;a(s,'pushback',{...o,id});return true;}return false;}
function doHandPowerInterference(r,s){const p=r.players[s];if(p.didInterfere)return false;for(const o of E().handPowerAttackOptions?.(r,s)||[]){const q=o.targets.map(seat=>r.players[seat]).find(q=>E().interferenceTargetUseful(E().mainAbilityText(r,p),q));if(q){a(s,'interfere',{target:q.seat,copyHandId:o.handId,copySourceId:o.sourceId});return true;}}return false;}
function doHandAttack(r,s){const p=r.players[s];const options=E().handAttackOptions?.(r,s)||[];for(const o of options){const text=String(m(o.sourceId).main||''),target=o.targets.map(seat=>r.players[seat]).filter(q=>E().interferenceTargetUseful(text,q)).sort((a,b)=>b.level-a.level)[0];if(target){a(s,'hand_copy_attack',{id:o.handId,sourceId:o.sourceId,target:target.seat});return true;}}return false;}
function doHandAbility(r,s){const p=r.players[s];if(p.actedHand)return false;
 // Preserve the MAIN and CAMP/META reservations, but incomplete SUPPORT
 // does not prevent these independent HAND abilities from being useful.
 if(!p.main)return false;
 const reserve=new Set(campKeep(p));
 if(E().handCopyActionOptions){const options=p.hand.flatMap(id=>E().handCopyActionOptions(r,s,id).map(option=>({...option,id}))).filter(o=>['S08','C005'].includes(o.code)||!reserve.has(o.id));options.sort((a,b)=>(['S08','C005'].includes(b.code)?10:b.cost?0:1)-(['S08','C005'].includes(a.code)?10:a.cost?0:1));const o=options[0];if(o?.code==='C012'){const target=r.players.find(q=>q.seat!==s&&q.level===p.level),payId=p.hand.find(id=>id!==o.id&&isCreature(id));a(s,'hand_copy_action',{id:o.id,sourceId:o.sourceId,target:target.seat,payId});return true;}if(o){const status=['SLEEP','STUN','PARASITE','POISON','FEAR'].find(st=>p.status.includes(st));const payId=p.hand.find(id=>id!==o.id&&!isCreature(id))||p.hand.find(id=>id!==o.id);a(s,'hand_copy_action',{id:o.id,sourceId:o.sourceId,...(o.code==='S08'&&!status?{mode:'cycle',payId}:['S08','C005'].includes(o.code)?{status}:['S12','C011'].includes(o.code)?{payId}:{})});return true;}}
 const candidates=p.hand.filter(id=>!reserve.has(id)&&E().handEffects.has(m(id).id));
 for(const id of candidates){if(m(id).id==='C005'){if(!p.status.length)continue;a(s,'hand_use',{id,status:p.status[0]});return true;}if(m(id).id==='C035'){const target=p.discard.filter(isCreature).sort((x,y)=>Number(m(y).pow||0)-Number(m(x).pow||0))[0];if(!target)continue;a(s,'hand_use',{id,target});return true;}a(s,'hand_use',{id});return true;}
 return false;
}
function performOne(){const r=D();const s=r.seat;if(r.phase==='FINISHED'||s===0)return false;const p=r.players[s];
 if(resolvePendingCpu())return true;
 if(r.phase==='ACTIONS'&&!r.explore){for(const id of p.hand){const code=m(id).id;if(code==='I40'||code==='I37'&&p.hand.length>1){const target=r.players.find(q=>q.seat!==s).seat,card=p.hand.find(x=>x!==id);a(s,'use_item',{id,target,card});return true;}}
 if(r.actionPoints>0&&E().mainProfile(r,p,['C012'])&&!r.abilityUsage?.[String(s)]?.[p.main+':'+E().mainProfile(r,p,['C012']).slot]){const target=r.players.find(q=>q.seat!==s&&q.level===p.level),id=p.hand.find(x=>isCreature(x)&&Number(m(x).pow)<2);if(target&&id){a(s,'main_give_creature',{target:target.seat,id});return true;}}}
 if(r.pendingAttack?.target===s){let aId=p.hand.find(id=>['I15','I17'].includes(m(id).id));
 if(!aId&&p.main&&m(p.main)?.id==='C075'&&!p.status.some(st=>['SLEEP','STUN'].includes(st))&&!r.abilityUsage?.[String(s)]?.[p.main+':MAIN'])aId=p.hand[0];a(s,'reaction_reply',aId?{id:aId}:{});return true;}
 if(r.effectPending?.owner===s){let d=p.hand.find(id=>!isCreature(id))||p.hand[p.hand.length-1];if(!d)throw Error('CPUの誘発後破棄が未解決');a(s,'resolve_effect',{id:d});return true;}
 if(r.fieldDiscardPending?.owner===s){const ix=p.hand.find(id=>!isCreature(id))||p.hand[p.hand.length-1];a(s,'field_discard',{id:ix});return true;}
 if(r.phase==='DRAFT'){const offer=r.starterOffer;if(!offer.length)throw Error('STARTER候補がありません');a(s,'draft_pick',{id:offer[Math.floor(Math.random()*offer.length)]});return true;}
 if(r.phase==='START'){
 if(E().startAbilityEligible(r,s,'C173')&&!r.startStatusCleanseUsed?.[String(s)]){const st=r.startSnapshot.status.find(st=>p.status.includes(st));if(st){a(s,'start_status_cleanse',{status:st});return true;}}
 const choice=E().startSpeciesOptions(r,s);if(choice){if(choice.support){let best=choice.candidates[0],score=-Infinity;for(const id of choice.candidates){const tmp={...p,startSupportSpecies:{source:choice.source,card:id,species:'蟲種',turn:r.effectTurn||0}},value=power(tmp)*3+capScore(tmp)*2+synCount(tmp);if(value>score){score=value;best=id;}}a(s,'start_species',{id:best});}else if(choice.code==='C177'){a(s,'start_species',{species:choice.candidates.find(sp=>!r.startSnapshot.support.some(id=>species(id)===sp))||choice.candidates[0]});}else{const selections=choice.count===1?choice.candidates.map(sp=>[sp]):choice.candidates.flatMap((sp,i)=>choice.candidates.slice(i+1).map(other=>[sp,other]));let best=selections[0],score=-Infinity;for(const selected of selections){const tmp={...p,startSpecies:{card:choice.source,species:selected[0],speciesList:selected,replace:choice.replace,turn:r.effectTurn||0}},value=power(tmp)*3+capScore(tmp)*2+synCount(tmp);if(value>score){score=value;best=selected;}}a(s,'start_species',{species:best});}return true;}
 arrange(r,s);a(s,'start_done',{});return true;}

 if(r.phase==='ACTIONS'){
 if(r.explore?.owner===s)return exploreChoose(r,s);
 if(r.actionPoints===0){a(s,'camp',{keep:campKeep(r.players[s]),campCleanse:campChoice(r.players[s])});return true;}
 if(doUtilityItem(r,s))return true;
 if(doHandAbility(r,s))return true;
 if(p.main&&!p.mainCopy&&['C079','C122','C149','C154','C181'].includes(m(p.main)?.id)&&!p.mainAbilityDisabled&&!p.status.some(st=>['SLEEP','STUN'].includes(st))){const targets=E().copyTargetCandidates(r,s,m(p.main).id,'MAIN').map(x=>{const pre=E().copyActivationPreflight(r,s,p.main,x.physicalId,'MAIN');if(!pre.ok||!['STATIC_POWER','STATIC_CAPTURE','EXTRA_EXPLORE','COPIED_PROFILE','COPIED_COST_MAIN','COPIED_ATTACK_MAIN'].includes(pre.execution?.kind))return null;const trial={...p,mainCopy:{copyId:p.main,sourceId:x.physicalId,sourceText:pre.sourceText,execution:pre.execution,owner:s,turn:r.effectTurn||0}};const powerGain=Math.max(0,power(trial)-power(p)),speciesCopy=['C157','C200'].includes(pre.execution.sourceCard?.id),captureGain=speciesCopy?capScore(trial)-capScore(p):E().copyMainBonus(r,trial,'STATIC_CAPTURE'),exploreGain=E().copyMainBonus(r,trial,'EXTRA_EXPLORE')+(speciesCopy?p.support.reduce((n,id)=>n+E().exploreSourceCount(trial,id,r)-E().exploreSourceCount(p,id,r),0):0);return {id:x.physicalId,value:powerGain*5+captureGain*3+exploreGain+E().copyCostValue(r,p,pre.execution)+E().copyAttackValue(r,p,pre.execution)+successDrawCopyValue(r,p,pre.execution)+(E().redrawProfile(r,trial,p.main)&&!E().redrawProfile(r,trial,p.main).reason?1:0)+(['S08','C005'].includes(pre.execution.sourceCard?.id)&&p.status.some(st=>['POISON','FEAR','PARASITE'].includes(st))?6:0)};}).filter(x=>x&&x.value>0);targets.sort((x,y)=>y.value-x.value||String(x.id).localeCompare(String(y.id)));if(targets.length){a(s,'copy_main',{sourceId:targets[0].id});return true;}}
 if(tryGuardian(r,s))return true;
 if(doGuardianPowerup(r,s))return true;
 if(doPushback(r,s))return true;
 if(doHandAttack(r,s))return true;
 if(doHandPowerInterference(r,s))return true;
 if(doSuccessDrawItem(r,s))return true;
 if(doTargetItem(r,s))return true;
 const cycle=E().mainDrawCycleProfile(r,p);if((cycle?.available||E().handEventOptions(r,s,{type:'main_draw_cycle'}).some(o=>o.code==='C186'))&&(p.deck.length||p.discard.length)){a(s,'main_draw_cycle');return true;}
 if(p.mainCopy?.execution?.kind==='COPIED_ATTACK_MAIN'&&!p.didInterfere){const text=E().mainAbilityText(r,p);const targets=E().interferenceTargets(r,s).filter(q=>E().interferenceTargetUseful(text,q)).sort((x,y)=>power(y)-power(x)||x.seat-y.seat);if(targets.length){a(s,'interfere',{target:targets[0].seat});return true;}}
 if(doMove(r,s))return true;
 if(doMainStatusCleanse(r,s))return true;
 if(p.level>=2&&!p.returning&&!p.hand.some(id=>netValue(id,p.guardian[String(p.level)]?.id)>0)){
 const offers=r.market.map(id=>({id,cost:Number(m(id).cost||0),net:/捕獲力を\+/.test(m(id).effect||'')})).filter(o=>o.cost>0&&o.cost<=p.hand.length);
 offers.sort((x,y)=>Number(y.net)-Number(x.net)||x.cost-y.cost);const o=offers[0];
 if(o){const pay=[...p.hand].sort((x,y)=>Number(isCreature(x))-Number(isCreature(y))).slice(0,o.cost);if(tryEventCopy(r,s,'BUY'))return true;a(s,'buy',{id:o.id,pay});return true;}
 }
 if(r.actionPoints>0&&p.main&&!p.status.includes('STUN')&&!p.status.includes('SLEEP')&&(p.level>=3)&&Math.random()<0.08){
 const desc=m(p.main).main||'';if(E().interferenceSupported(desc)){
 const targets=r.players.filter(q=>q.seat!==p.seat&&(q.level===p.level||q.returning!==p.returning&&Math.abs(q.level-p.level)===1));
 targets.sort((x,y)=>x.seat-y.seat);for(const q of targets){try{a(s,'interfere',{target:q.seat});return true;}catch(e){}}
 }
 }
 if(r.actionPoints>0){if(p.level<=8){if(doMainHandCycle(r,s))return true;const stray=strayRecoveryTarget(p);if(stray){a(s,'explore_stray',{id:stray});return true;}try{if(tryEventCopy(r,s,'EXPLORE'))return true;a(s,'explore');return true;}catch(e){}}
 if(chooseMarket(r,s))return true;}
 a(s,'camp',{keep:campKeep(r.players[s]),campCleanse:campChoice(r.players[s])});return true;
 }
 return false;
}
return {differentSpecies,effectiveTeamSpecies,teamSpeciesCount,speciesSnapshot,doPushback,doHandPowerInterference,strayRecoveryTarget,doHandAttack,doTargetItem,targetMainCaptureBonus,lineupMainBonuses,doMainStatusCleanse,bestLineup,captureImprovesLineup,metaImprovesLineup,campKeep,captureRecipe,tryExploreRecovery,metaPlan,doUtilityItem,doHandAbility,mainSpecies:mainSpeciesSet,effectiveSpecies,teamDistinct,speciesCondMatch,copiedMainPower:staticMainPowerBonus,performOne,resolvePendingCpu,capScore,power,synCount,adapted,supportSyn,moveAllowed,chooseNets,canForce,canCaptureGuardian,guardianAssist,forceSupportBonus,doMainHandCycle,guardianPowerupPlan,doGuardianPowerup,doSuccessDrawItem};
})();
window.Bot=Bot;
