/* RINNE Work165. Decorative observer: never writes game state or consumes RNG. */
'use strict';
(() => {
 const names=['RINNE総合紋章','菌糸洞窟','地下森林','捕食圏','地下海','灼熱層','古代生物圏','原始生命圏','起源層'];
 const path=level=>`assets/symbols/rinne_symbol_${level===0?'world':'l'+level}.jpeg`;
 let previous=null,layer=null,timer=null,generation=0,audio=null,sounds=[];
 const enabled=()=>window.RinneFx?.isEnabled?.()!==false;
 const reduced=()=>window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches===true;
 function clear(){for(const n of sounds){try{n.stop();}catch{}}sounds=[];generation++;clearTimeout(timer);timer=null;layer?.remove();layer=null;}
 function reset(){previous=null;clear();}
 function ensureFilter(){
  if(document.getElementById('rinne-symbol-filter'))return;
  // Browser-native colour key: transparent neutral grey, opaque black outlines/colours.
  // The supplied JPEG files remain byte-for-byte intact; no image is redrawn.
  const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.id='rinne-symbol-filter';svg.setAttribute('aria-hidden','true');svg.setAttribute('width','0');svg.setAttribute('height','0');
  svg.innerHTML=`<defs><filter id="rinne-symbol-key" color-interpolation-filters="sRGB"><feColorMatrix in="SourceGraphic" values="1 -1 0 0 0  0 1 -1 0 0  -1 0 1 0 0  0 0 0 0 1" result="positive"/><feColorMatrix in="SourceGraphic" values="-1 1 0 0 0  0 -1 1 0 0  1 0 -1 0 0  0 0 0 0 1" result="negative"/><feComposite in="positive" in2="negative" operator="arithmetic" k2="1" k3="1" result="chroma"/><feColorMatrix in="chroma" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  12 12 12 0 -0.6" result="colourMask"/><feColorMatrix in="SourceGraphic" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  -6.666667 -6.666667 -6.666667 0 11" result="darkMask"/><feComposite in="colourMask" in2="darkMask" operator="arithmetic" k2="1" k3="1" result="mask"/><feComposite in="SourceGraphic" in2="mask" operator="in"/></filter></defs>`;
  document.body.append(svg);
 }
 function unlockAudio(){
  if(!enabled())return;
  try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;audio??=new AC();audio.resume()?.catch?.(()=>{});}catch{}
 }
 function sound(){
  if(!audio||audio.state!=='running'||!enabled()||document.hidden)return;
  try{
   const t=audio.currentTime,osc=audio.createOscillator(),gain=audio.createGain();osc.type='sine';osc.frequency.setValueAtTime(85,t);osc.frequency.exponentialRampToValueAtTime(55,t+.25);gain.gain.setValueAtTime(0,t);gain.gain.linearRampToValueAtTime(.025,t+.04);gain.gain.exponentialRampToValueAtTime(.0001,t+.3);osc.connect(gain);gain.connect(audio.destination);osc.start(t);osc.stop(t+.31);sounds.push(osc);
   const length=Math.ceil(audio.sampleRate*.9),buffer=audio.createBuffer(1,length,audio.sampleRate),data=buffer.getChannelData(0);
   // Local deterministic texture, independent of the game RNG.
   for(let i=0;i<length;i++){const n=Math.sin(i*12.9898)*43758.5453;data[i]=2*(n-Math.floor(n))-1;}
   const wind=audio.createBufferSource(),filter=audio.createBiquadFilter(),volume=audio.createGain();wind.buffer=buffer;filter.type='bandpass';filter.frequency.setValueAtTime(1200,t+.9);filter.frequency.exponentialRampToValueAtTime(450,t+1.68);filter.Q.value=.7;volume.gain.setValueAtTime(.0001,t+.9);volume.gain.linearRampToValueAtTime(.012,t+1.08);volume.gain.exponentialRampToValueAtTime(.0001,t+1.776);wind.connect(filter);filter.connect(volume);volume.connect(audio.destination);wind.start(t+.9);wind.stop(t+1.8);sounds.push(wind);
  }catch{/* Audio is optional when blocked or unavailable. */}
 }
 function show(level){
  clear();if(!Number.isInteger(level)||level<0||level>8||!enabled()||document.hidden)return;
  try{
   ensureFilter();const token=generation,still=reduced();
   layer=document.createElement('div');layer.className='rinne-symbol-overlay'+(still?' is-still':'');layer.dataset.level=String(level);layer.setAttribute('aria-hidden','true');
   const group=document.createElement('div');group.className='rinne-symbol-group';
   const image=document.createElement('img');image.className='rinne-symbol-art';image.alt='';image.width=1254;image.height=1254;image.decoding='async';image.src=path(level);
   const caption=document.createElement('div');caption.className='rinne-symbol-caption';caption.textContent=(level===0?'RINNE':`LEVEL ${level}`)+' · '+names[level];group.append(image,caption);layer.append(group);
   if(!still)for(let i=0;i<16;i++){
    const star=document.createElement('i'),angle=i*Math.PI/8;
    star.className='rinne-symbol-spark'+(i%3===0?' is-dot':'');
    star.style.setProperty('--spark-x',Math.round(Math.cos(angle)*(105+i%3*18))+'px');
    star.style.setProperty('--spark-y',Math.round(Math.sin(angle)*(100+i%4*12))+'px');
    star.style.setProperty('--spark-delay',(100+i%4*90+Math.floor(i/4)*35)+'ms');
    star.style.setProperty('--spark-size',(4+i%3*2)+'px');layer.append(star);
   }
   document.body.append(layer);
   let started=false;
   const start=()=>{if(started||token!==generation||!layer)return;if(document.hidden||!enabled()){clear();return;}started=true;clearTimeout(timer);sound();layer.classList.add('is-playing');timer=setTimeout(clear,1800);};
   image.onload=start;image.onerror=()=>{if(token===generation)clear();};
   if(image.complete&&image.naturalWidth>0)start();else timer=setTimeout(()=>{if(token===generation)clear();},1500);
  }catch(e){clear();console.warn('RINNE symbol skipped',e.message);}
 }
 function observe(r){
  if(!r?.players?.[0])return reset();
  const now={key:String(r.code)+'|'+String(r.created),revision:Number(r.revision)||0,level:Number(r.players[0].level)};
  if(previous&&previous.key===now.key&&now.revision>previous.revision&&now.level>previous.level&&now.level<=8)show(now.level);
  if(previous?.key!==now.key||now.revision<previous.revision)clear();
  previous=now;
 }
 // Decorative API supports the existing settings and explicit non-game preview.
 document.addEventListener('visibilitychange',()=>{if(document.hidden)clear();});
 window.RinneSymbols={observe,reset,clear,preview:show,unlockAudio,isActive:()=>!!layer,path,names};
})();
