const RINNE = (()=> {
'use strict';
const cards = window.RINNE_CARDS;
const physical = window.RINNE_PHYSICAL;
const C = Object.fromEntries(cards.map(x => [x.id, x]));
const P = Object.fromEntries(physical.map(x => [x.physical_id, x]));
let interruptReplay=null;
function randomUnit(){if(!interruptReplay)return Math.random();const x=interruptReplay;const i=x.randomIndex++;if(i<x.randomTape.length)return x.randomTape[i];need(!x.strict,'割り込み保存の乱数記録が不足');const v=Math.random();x.randomTape.push(v);return v;}
const random = n => Math.floor(randomUnit()*n);
const shuffle = a => { const x=[...a]; for(let i=x.length-1;i>0;i--){let j=random(i+1);[x[i],x[j]]=[x[j],x[i]];}return x; };
const cardId = id => P[id]?.card_id;
const type = id => C[cardId(id)]?.kind;
const meta = id => C[cardId(id)];
const creature = id => ['WILD','STARTER','GUARDIAN'].includes(type(id));
const err = msg => { throw Error(msg); };
const need = (cond,msg) => { if(!cond) err(msg); };
const take = (a,id,msg='そのカードは指定した場所にありません') => {const i=a.indexOf(id);need(i>=0,msg);a.splice(i,1);return id;};
const log = (r,msg) => {r.log.unshift({at:interruptReplay?.time??Date.now(),msg});r.log=r.log.slice(0,100);};
// v2.0 integration seam: bounded internal event trace. No gameplay modifiers are
// applied here; effect triggers must be implemented and tested separately.
const EVENT_TYPES = new Set(['ACTION_COMMITTED','INTERFERE_BLOCKED','INTERFERE_RESOLVED','STATUS_APPLIED','STATUS_REMOVED','POWER_REDUCED','EXPLORE_COMPLETED','META_SUCCEEDED','ITEM_USED','CREATURE_COST_PAID']);
function emitGameEvent(r,event){
 if(!EVENT_TYPES.has(event.type))throw Error('Unknown game event');
 r.effectEvents??=[];
 r.effectEvents.push({type:event.type,seat:event.seat??null,target:event.target??null,action:event.action??null,status:event.status??null,amount:event.amount??null,revision:r.revision??0,turn:r.effectTurn??0});
 if(r.effectEvents.length>120)r.effectEvents.splice(0,r.effectEvents.length-120);
}

const roomCode = () => Array.from({length:6},()=> 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[random(32)]).join('');
const token = () => Array.from({length:24},()=>Math.floor(Math.random()*256).toString(16).padStart(2,'0')).join('');
function baseRoom(name){
 return {setupPreset:'R2',marketSize:3,code:roomCode(),mode:'RETURN',host:0,phase:'LOBBY',seat:0,revision:0,created:Date.now(),players:[makePlayer(name,0)],log:[],winner:null,pendingTrade:null};
}
function makePlayer(name,seat){return {name:name.trim().slice(0,20),seat,token:token(),level:1,returning:false,deck:[],hand:[],discard:[],main:null,support:[],equip:[],stray:[],status:[],guardian:{},final:[false,false,false],l1CaptureCount:0,moved:false,traded:false,actedHand:false,didInterfere:false,usedItemThisTurn:false,turnPowerBonus:0,turnPowerPenalty:0};}
function addPlayer(r,name){need(r.phase==='LOBBY','ゲーム開始済み');need(r.players.length<4,'満員です');let p=makePlayer(name,r.players.length);r.players.push(p);log(r,`${p.name} が参加`);return p;}
function fillSupply(r){const goal=3;r.marketSize=3;while(r.market.length<goal && r.supply.length)r.market.push(r.supply.shift());}
function draw(r,p,n){let count=0;while(n-->0){if(!p.deck.length){if(!p.discard.length)break;p.deck=shuffle(p.discard);p.discard=[];}p.hand.push(p.deck.shift());count++;}return count;}
function setup(r){
 need(r.players.length===4,'4人そろってから開始');need(r.phase==='LOBBY','開始済み');
 r.wild=Object.fromEntries(Array.from({length:8},(_,i)=>[String(i+1),[]]));
 r.wildDiscard=Object.fromEntries(Array.from({length:8},(_,i)=>[String(i+1),[]]));
 const supply=[], starters=[], guardians={2:[],3:[],4:[],5:[],6:[],7:[],8:[]};
 for(const o of physical){const c=C[o.card_id];if(c.kind==='WILD')r.wild[c.level].push(o.physical_id);else if(c.kind==='SUPPLY')supply.push(o.physical_id);else if(c.kind==='STARTER')starters.push(o.physical_id);else if(c.kind==='GUARDIAN')guardians[c.level].push(o.physical_id);}
 Object.keys(r.wild).forEach(k=>r.wild[k]=shuffle(r.wild[k]));
 r.setupPreset='R2';r.marketSize=3;
 r.supply=shuffle(supply);r.market=[];fillSupply(r);r.removedItems=[];r.unusedInitial=[];r.unusedStarters=[];
 r.starterOffer=shuffle(starters).slice(0,6);r.unusedStarters=starters.filter(x=>!r.starterOffer.includes(x));
 for(const level of [2,3,4,5,6,7,8]){const ids=shuffle(guardians[level]);need(ids.length===4,`L${level} GUARDIAN構成不正`);r.players.forEach((p,i)=> p.guardian[String(level)]={id:ids[i],status:'waiting',pending:null});}
 const initial=physical.filter(x=>C[x.card_id].kind==='START ITEM');
 const groups={};for(const x of initial){groups[x.card_id]??=[];groups[x.card_id].push(x.physical_id);}
 const initialMix=[['SI01',2],['SI02',3],['SI03',1],['SI04',1]];
 for(const p of r.players){let deck=[];for(const [id,n] of initialMix){need(groups[id]?.length>=n,'初期ITEM不足');deck.push(...groups[id].splice(0,n));}p.deck=shuffle(deck);draw(r,p,5);}
 r.unusedInitial=Object.values(groups).flat();
 r.draftOrder=[3,2,1,0];r.draftIndex=0;r.phase='DRAFT';r.seat=r.draftOrder[0];r.actionPoints=0;r.explore=null;log(r,`準備完了・${r.mode} MODE・ITEM R2（初期7枚／市場3枚）・L2〜L8 GUARDIAN・STARTERを逆手番順で選択`);
 assertConservation(r);
}
function cycle(r,id){need(creature(id),'CREATUREのみ循環');const kind=type(id),lvl= kind==='STARTER'?'1':String(meta(id).level);need(r.wild[lvl],`戻し先LEVEL不正: ${id}`);if(!r.wild[lvl].length && r.wildDiscard[lvl].length){r.wild[lvl]=shuffle(r.wildDiscard[lvl]);r.wildDiscard[lvl]=[];}r.wild[lvl].push(id);}
function wildDraw(r,lvl,n){const out=[];const d=r.wild[String(lvl)], disc=r.wildDiscard[String(lvl)];while(n-->0){if(!d.length&&disc.length){r.wild[String(lvl)]=shuffle(disc);disc.splice(0);}
 const src=r.wild[String(lvl)];if(!src.length)break;out.push(src.shift());}return out;}
function discardWild(r,id){const k=type(id)==='STARTER'?'1':String(meta(id).level);r.wildDiscard[k].push(id);}
function active(r,seat){need(r.seat===seat,'あなたの手番ではありません');need(['START','ACTIONS','CHECK'].includes(r.phase),'現在のフェーズでは操作不可');return r.players[seat];}
function action(r,seat){const p=active(r,seat);need(r.phase==='ACTIONS','STARTを完了してください');need(r.actionPoints>0,'ACTIONが残っていません');return p;}
function useAction(r,n=1){need(r.actionPoints>=n,'ACTION不足');r.actionPoints-=n;}
function requireNoExplore(r){need(!r.explore,'先に探索を解決してください');}

function captureItemBonus(id,target){
 const i=meta(id),t=meta(target);if(!i||!t||i.timing!=='FREE')return 0;
 switch(i.id){
 case 'SI02':return 1;
 case 'I08':return 2;
 case 'I09':return 3; // 使用時に対象の印字種族を選んだものとして扱う
 case 'I11':return Number(t.pow)>=4?3:0;
 case 'I12':return ['獣種','鱗種'].includes(t.species)?3:0;
 case 'I13':return Number(t.cap)>=5?5:0;
 default:return 0;
 }
}
function conditionalMainExploreCount(p,cid){
 const required={C013:'蟲種',C017:'胞子種',C019:'樹種',C129:'蟲種'};
 if(!required[cid]&&!['C027','C042','C059','C084','C132','C163','C176'].includes(cid))return null;
 if(cid==='C059')return p.stray?.length?1:0;
 const mainKinds=p.main?(window.Bot?.mainSpecies?.(p)||new Set([meta(p.main)?.species])):new Set();
 const groups=(p.support||[]).map(id=>window.Bot?.effectiveSpecies?.(p,id)||new Set([meta(id)?.species]));
 if(required[cid])return groups.some(g=>g.has(required[cid]))?(cid==='C129'?2:1):0;
 const different=!!p.main&&mainKinds.size>0&&groups.some(g=>g.size>0&&![...g].some(sp=>mainKinds.has(sp)));
 if(cid==='C027')return different?1:0;
 if(cid==='C163')return different?3:2;
 return groups.length===2&&groups.every(g=>[...g].some(sp=>sp&&sp!=='―'))&&![...groups[0]].some(sp=>groups[1].has(sp))?(cid==='C176'?1:2):0;
}
function exploreSourceCount(p,id,r=null){
 // v2.0: condition-gated exploration bonuses must never be offered unconditionally.
 const cid=meta(id)?.id;
 if(cid==='I05'&&p.hand.includes(id))return r?.explore&&r.explore.source!=='wild'?0:(p.stray.length?4:1);
 if(cid==='C039'&&id===p.main)return !p.mainAbilityDisabled&&!p.status?.some(st=>['SLEEP','STUN'].includes(st))&&r?.explore?.ids.some(x=>['蟲種','樹種'].includes(meta(x)?.species))&&abilityAvailable(r,p.seat,id,'MAIN')?1:0;
 if(id===p.main&&(p.mainAbilityDisabled||p.status?.some(st=>['SLEEP','STUN'].includes(st))))return 0;
 if(p.support.includes(id)&&p.disabledSupportIds?.includes(id))return 0;
 const mainSpecies=p.main?meta(p.main)?.species:null,mainKinds=window.Bot?.mainSpecies?.(p)||new Set([mainSpecies]);
 const otherHasParasite=!!r?.players?.some(q=>q!==p&&q.status?.includes('PARASITE'));
 if(cid==='C055'&&!mainKinds.has('胞子種')&&!otherHasParasite)return 0;
 if(cid==='C079'&&!mainKinds.has('水棲種'))return 0;
 if(cid==='C083'&&mainKinds.has(meta(id)?.species))return 0;
 if(cid==='C112'&&!mainKinds.has('胞子種'))return 0;
 if(cid==='C137'&&otherHasParasite)return 0;
 if(id===p.main&&r){const copied=copyMainBonus(r,p,'EXTRA_EXPLORE');if(copied)return copied;}
 if(id===p.main){const conditional=conditionalMainExploreCount(p,cid);if(conditional!==null)return conditional;}
 const c=meta(id);if(!c)return 0;
 let description='';
 if(p.main===id)description=c.main||'';
 else if(p.support.includes(id))description=c.support||'';
 else if(p.hand.includes(id)&&['SUPPLY','START ITEM'].includes(type(id))&&c.timing==='FREE')description=c.effect||'';
 else return 0;
 if(/引き直|山札の下へ|一番下へ戻し/.test(description))return 0;
 if(!/探索(時|後)/.test(description)||!/追加で|さらに/.test(description))return 0;
 const matched=description.match(/(?:追加で|さらに)([0-9１２３４一二三四])枚/);
 const n=matched?({一:1,二:2,三:3,四:4,'１':1,'２':2,'３':3,'４':4}[matched[1]]||Number(matched[1])):0;
 if(cid==='C169'&&otherHasParasite)return 2;
 return n>=1&&(n<=3||cid==='I06'&&n===4)?n:0;
}

// v0.8.4: show actionable timing-specific options immediately after a reveal.
// Only a source with a verified engine route can be marked available.
// Batch B: physical actor/slot identity is distinct from the borrowed ability code.
const batchBProfiles=new Set(['C009','C031','C032','C036','C039','C062','C073','C075','C078','C088','C100','C101','C130','C142','C150','C158','C184','C186','C157','C200']);
const batchBTargetAttacks=new Set(['C045','C065','C072']);
function mainProfile(r,p,codes,wasActive=null){
 if(!p?.main||p.mainAbilityDisabled||!(wasActive??!p.status.some(st=>['SLEEP','STUN'].includes(st))))return null;
 const own=meta(p.main)?.id;if(codes.includes(own))return {code:own,id:p.main,slot:'MAIN',copied:false};
 const b=p.mainCopy,code=b?.execution?.sourceCard?.id;
 if(b?.execution?.kind==='COPIED_PROFILE'&&codes.includes(code)&&b.copyId===p.main&&b.owner===p.seat&&b.owner===r.seat&&b.turn===(r.effectTurn||0)&&b.sourceText===String(C[code]?.main))return {code,id:p.main,slot:'COPY_PROFILE_'+code,copied:true};
 return null;
}
function mainDrawCycleProfile(r,p){
 const profile=mainProfile(r,p,['C031','C032','C088']);if(!profile)return null;
 const species={C031:'樹種',C032:'胞子種',C088:'水棲種'}[profile.code];
 return {...profile,available:r.phase==='ACTIONS'&&r.seat===p.seat&&!r.explore&&hasSupportSpecies(p,species)&&abilityAvailable(r,p.seat,profile.id,profile.slot)};
}
function notifyCreatureDiscard(r,p,ids,reason){
 if(!ids.length||['STOW','CAMP','RETURN','META'].includes(reason))return;
 if(ids.some(creature))p.creatureDiscardTurn=r.effectTurn||0;
 for(const q of r.players){const profile=mainProfile(r,q,['C009']);if(!profile||!ids.some(id=>creature(id)&&id!==profile.id))continue;fireLifecycleAbility(r,q,profile.id,profile.slot,{drawCount:1});}
 const profile=mainProfile(r,p,['C100']);if(profile&&p.level===5)fireLifecycleAbility(r,p,profile.id,profile.slot,{drawCount:1});
 const owner=r.seat,activePlayer=r.players[owner],codes=[];if(ids.some(creature))codes.push('C009');if(owner===p.seat&&activePlayer.level===5)codes.push('C100');const hand=reactiveHandCopy(r,owner,{kind:'DISCARD',payer:p.seat,ids:[...ids],reason},codes);if(hand){fireLifecycleAbility(r,activePlayer,hand.handId,'HAND_REACTIVE_EFFECT_'+hand.code,{drawCount:1,limited:false});processEffectQueue(r);}
}
// Batch A: one legality profile for reveal replacement, shared by UI, CPU and executor.
const batchASuccessProfiles=new Set(['C060','C091','C098','C106','C119','C139','C143','C148','C165']);
const batchAAttacks=new Set(['C125','C162','C170','C195']);
const redrawMains=new Set(['S09','S15','C010','C016','C025','C037','C076','C093','C116','C138','C171','C196']);
function redrawProfile(r,p,id,handCode=null){if(cardId(id)==='I28')return null;
 const c=meta(id);if(!c)return null;
 const item=['SUPPLY','START ITEM'].includes(c.kind),copied=id===p.main?activeCopiedProfileCode(r,p):null;
 const source=handCode?C[handCode]:copied&&redrawMains.has(copied)?C[copied]:c;
 const text=String(handCode?source.main:id===p.main?source.main:p.support.includes(id)?c.support:item?c.effect:'');
 if(!/引き直|山札の下へ|一番下へ戻し/.test(text))return null;
 const code=source.id,maximum=code==='I02'||code==='C138'||code==='C171'?2:code==='I03'||code==='C196'?3:1;
 const slot=handCode?'HAND_REDRAW_'+code:copied?'COPY_REDRAW_'+code:'MAIN';
 const used=r.explore?.redrawCount?.[id]||0;let reason='';
 if(used>=maximum)reason='この探索では使用済み';
 else if(!item&&(id===p.main&&(p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st)))||p.disabledSupportIds?.includes(id)))reason='能力は無効';
 else if(code==='C171'&&!used&&!abilityAvailable(r,p.seat,id,slot))reason='このターンでは使用済み';
 else if(['S15','C037'].includes(code)&&r.explore?.ids.some(x=>[...(window.Bot?.mainSpecies?.(p)||new Set([meta(p.main)?.species]))].includes(meta(x)?.species)))reason='MAINと同じ種族が公開済み';
 else if(code==='C025'&&r.explore?.ids.some(x=>meta(x)?.species==='蟲種'))reason='蟲種が公開済み';
 return {code,maximum,slot,used,item,text,reason,copied:!!copied};
}
function exploreTimingOptions(r,seat){
 const p=r.players[seat];if(!p||r.seat!==seat||r.phase!=='ACTIONS'||r.explore?.owner!==seat)return [];
 const e=r.explore;
 const sources=[...Object.keys(e.handRedraw||{}),p.main,...p.support,...p.hand.filter(id=>['SUPPLY','START ITEM'].includes(type(id))||['C079','C154','C181'].includes(meta(id)?.id)),...Object.keys(e.redrawCount||{})].filter(Boolean);
 const ids=[...new Set(sources)];const options=[];
 const wildAvailable=(r.wild[String(e.level)]?.length||0)+(r.wildDiscard[String(e.level)]?.length||0)>0;
 for(const id of ids){
  const c=meta(id);if(!c)continue;
  const inField=p.main===id||p.support.includes(id);
  const item=['SUPPLY','START ITEM'].includes(type(id));
  const prior=e.redrawCount?.[id]||0;
  if(!inField&&!item&&!['C079','C154','C181'].includes(c.id))continue;
  if(item&&!p.hand.includes(id)&&!(prior>0&&['I02','I03'].includes(c.id)&&r.removedItems.includes(id)))continue;
  if(c.id==='I28'){if(e.source==='wild')options.push({id,kind:'pheromone',item:true,amount:2,ready:true,reason:'',label:'最大2枚引き直す／遊動個体を移す',timing:'探索後'});continue;}
  const desc=String(inField?(p.main===id?c.main:c.support):c.effect||'');
  const more=exploreSourceCount(p,id,r);
  if(more>0){
   let reason='';
   if(e.usedExploreSources?.includes(id))reason='この探索では使用済み';
   else if(false)reason='';
   else if(c.id==='I06'&&p.level<6)reason='LEVEL6以降限定';
   else if(e.ids.length+more>12)reason='公開上限12枚';
   else if(!wildAvailable)reason='公開できる野生カードがない';
   options.push({id,kind:'more',item,amount:more,ready:!reason,reason,label:`＋${more}枚公開`,timing:/探索後/.test(desc)?'探索後':'探索時'});
  }
  const replacement=redrawProfile(r,p,id);
  if(replacement){
   let reason=replacement.reason;
   if(item&&prior===0&&!p.hand.includes(id))reason='手札にない';
   if(c.id==='I02'&&prior>0){const tribe=e.redrawSpecies?.[id];if(tribe&&e.ids.some(x=>meta(x)?.species===tribe))reason='指定した種族が出現済み';}
   options.push({id,kind:'redraw',item,amount:1,ready:!reason,reason,label:`公開1枚を引き直す（${prior}/${replacement.maximum}）`,timing:/探索後/.test(replacement.text)?'探索後':'探索時'});
  }
  const continuing=e.handRedraw?.[id];
  if(continuing){const prof=redrawProfile(r,p,id,continuing.code);if(prof)options.push({id,kind:'copy_hand_redraw',copySourceId:continuing.sourceId,item:false,amount:1,ready:!prof.reason,reason:prof.reason,label:`HAND COPY 引き直し（${prof.used}/${prof.maximum}）`,timing:'探索後'});}
  if(p.hand.includes(id)&&['C079','C154','C181'].includes(c.id))for(const target of copyTargetCandidates(r,seat,c.id,'HAND')){
   const pre=copyActivationPreflight(r,seat,id,target.physicalId,'HAND');if(!pre.ok||!redrawMains.has(pre.sourceCardId))continue;
   const prof=redrawProfile(r,p,id,pre.sourceCardId);if(!prof)continue;
   options.push({id,kind:'copy_hand_redraw',copySourceId:target.physicalId,item:false,amount:1,ready:!prof.reason,reason:prof.reason,label:`HAND ${meta(target.physicalId).name}の引き直しをCOPY`,timing:'探索後'});
  }
  // COPY MAIN: offer only source abilities whose printed effect is a simple
  // exploration reveal. Keep source choice separate from the COPY card.
  if(id===p.main&&['C079','C122','C149','C154','C181'].includes(c.id)){
   for(const target of copyTargetCandidates(r,seat,c.id,'MAIN')){
    const pre=copySourcePreflight(r,seat,c.id,target.physicalId,'MAIN');
    if(!pre.ok)continue;
    const amount=copyExploreAmount(r,p,pre.execution);if(amount<=0)continue;
    let reason='';
    if(e.usedExploreSources?.includes(id))reason='この探索ではCOPYを使用済み';
    else if(p.mainAbilityDisabled||p.status?.includes('SLEEP')||p.status?.includes('STUN'))reason='MAIN能力が使用不可';
    else if(e.ids.length+amount>12)reason='公開上限12枚';
    else if(!wildAvailable)reason='公開できる野生カードがない';
    options.push({id,kind:'copy_more',copySourceId:target.physicalId,item:false,
      amount,ready:!reason,reason,label:`${meta(target.physicalId).name}をCOPYして＋${amount}枚公開`,timing:'探索時'});
   }
  }
  // HAND COPY: choose the physical hand card and its legal source separately.
  // The engine consumes HAND only after all source and draw checks succeed.
  if(p.hand.includes(id)&&['C079','C154','C181'].includes(c.id)){
   for(const target of copyTargetCandidates(r,seat,c.id,'HAND')){
    const pre=copySourcePreflight(r,seat,c.id,target.physicalId,'HAND');
    if(!pre.ok)continue;
    const amount=copyExploreAmount(r,p,pre.execution,id);if(amount<=0&&pre.sourceCardId!=='C176')continue;
    let reason='';
    if(p.actedHand)reason='このターンHAND使用済み';
    else if(r.phase!=='ACTIONS'||r.seat!==seat)reason='自分のACTION中のみ';
    else if(e.usedExploreSources?.includes(id))reason='この探索で使用済み';
    else if(e.ids.length+amount>12)reason='公開上限12枚';
    else if(amount>0&&!wildAvailable)reason='公開できる野生カードがない';
    options.push({id,kind:'copy_hand_more',copySourceId:target.physicalId,item:false,
     amount,ready:!reason,reason,label:amount?`HAND ${meta(target.physicalId).name}をCOPYして＋${amount}枚公開（使用カードを捨てる）`:'HAND COPY：探索終了後に1枚引き、1枚捨てる',timing:'探索時'});
   }
  }
  if(item&&c.id==='I07')options.push({id,kind:'item',item:true,amount:1,ready:p.hand.includes(id),reason:p.hand.includes(id)?'':'使用済み',label:'1枚引き、1枚捨てる',timing:'探索後'});
 }
 return options;
}
function hasHeatAdaptation(p){
 if(!p.main)return false;
 if(String(meta(p.main)?.keyword||'').includes('適応：灼熱'))return true;
 return p.support.some(id=>{
  if(p.disabledSupportIds?.includes(id))return false;
  const text=String(meta(id)?.support||'');
  if(!text.includes('「適応：灼熱」を与える'))return false;
  if(text.includes('MAINが胞子種なら')&&meta(p.main)?.species!=='胞子種')return false;
  return true;
 });
}
function expireEquipAtStart(r,p){
 const expired=p.equip.filter(id=>meta(id)?.id==='I21');
 for(const id of expired){take(p.equip,id);r.removedItems.push(id);log(r,`${p.name} の携帯シェルターが次のSTARTに到達し除外`);}
}
function captureStartSnapshot(r){const p=r.players[r.seat];r.startSnapshot={seat:r.seat,turn:r.effectTurn||0,main:p.main,support:[...p.support],status:[...p.status],enabled:!p.mainAbilityDisabled&&!p.status.some(st=>['SLEEP','STUN'].includes(st))};}
function startAbilityEligible(r,seat,cid){const x=r.startSnapshot;return r.phase==='START'&&r.seat===seat&&x?.seat===seat&&x.turn===(r.effectTurn||0)&&x.enabled&&meta(x.main)?.id===cid;}
function validateStartSpecies(r,p){
 const legal=new Set(cards.filter(c=>['WILD','STARTER','GUARDIAN'].includes(c.kind)).map(c=>c.species));
 const validTurn=t=>Number.isInteger(t)&&t>=0&&t<=(r.effectTurn||0);
 if(p.startSpecies){const b=p.startSpecies,code=meta(b.card)?.id,sp=b.speciesList||[b.species];need(['C151','C152','C159','C177'].includes(code)&&validTurn(b.turn)&&Array.isArray(sp)&&sp.length===(code==='C159'?2:1)&&new Set(sp).size===sp.length&&sp.every(x=>legal.has(x))&&b.species===sp[0]&&(b.replace===undefined?code==='C177':b.replace===(code==='C152')),'START種族保存状態が不正');}
 if(p.startSupportSpecies){const b=p.startSupportSpecies;need(meta(b.source)?.id==='C161'&&P[b.card]&&creature(b.card)&&b.species==='蟲種'&&validTurn(b.turn),'START SUPPORT種族保存状態が不正');if(b.turn===(r.effectTurn||0))need(r.startSnapshot?.seat===p.seat&&r.startSnapshot.main===b.source&&r.startSnapshot.support.includes(b.card),'開始時SUPPORT記録と不一致');}
}
function startSpeciesOptions(r,seat){
 const p=r.players[seat],x=r.startSnapshot,code=meta(x?.main)?.id;
 if(!['C151','C152','C159','C161','C177'].includes(code)||!startAbilityEligible(r,seat,code))return null;
 const support=code==='C161',record=support?p.startSupportSpecies:p.startSpecies;
 if(record?.turn===(r.effectTurn||0)&&(support?record.source===x.main:record.card===x.main))return null;
 const candidates=support?[...x.support]:[...new Set(cards.filter(c=>['WILD','STARTER','GUARDIAN'].includes(c.kind)).map(c=>c.species).filter(sp=>sp&&sp!=='―'))];
 if(!candidates.length)return null;
 return {code,source:x.main,count:code==='C159'?2:1,support,replace:code==='C152',candidates};
}
function copyExploreAmount(r,p,execution,physicalCopy=p.main){if(execution?.kind==='EXTRA_EXPLORE')return execution.amount;if(execution?.kind!=='COPIED_PROFILE')return 0;if(execution.sourceCard.id==='C039')return r.explore?.owner===p.seat&&r.explore.ids.some(id=>['蟲種','樹種'].includes(meta(id)?.species))&&abilityAvailable(r,p.seat,physicalCopy,'COPY_EXPLORE_C039')?1:0;const conditional=conditionalMainExploreCount(p,execution.sourceCard.id);if(conditional!==null)return conditional;const parasite=r.players.some(q=>q.seat!==p.seat&&q.status?.includes('PARASITE'));if(['C192','C127','C124'].includes(execution.sourceCard.id))return 2;if(execution.sourceCard.id==='C137')return parasite?0:1;if(execution.sourceCard.id==='C169')return parasite?2:1;return 0;}
function copyCaptureAmount(r,p,execution,target=null,handCost=false,handId=null){if(handCost&&handId&&execution?.sourceCard?.id==='C186'&&p.support.length===2)return (window.Bot?.capScore(handCheckPlayer(p,{code:'C186',handId}),target)||0)-(window.Bot?.capScore(p,target)||0);if(execution?.kind==='STATIC_CAPTURE')return execution.amount;if(execution?.kind==='COPIED_PROFILE'){if(execution.sourceCard.id==='C110')return handCost||Number.isInteger(p.creatureCostTurn)&&p.creatureCostTurn===(r.effectTurn||0)?1:0;const targetBonus=window.Bot?.targetMainCaptureBonus(execution.sourceCard.id,target,p);if(targetBonus!==null&&targetBonus!==undefined)return targetBonus;const bonus=window.Bot?.lineupMainBonuses(p,execution.sourceCard.id);if(bonus)return bonus.capture;}if(execution?.kind==='COPIED_PROFILE'&&execution.sourceCard.id==='C160')return p.support.length===2&&(window.Bot?.teamDistinct?.(p)??new Set([p.main,...p.support].map(id=>meta(id).species)).size===3)?1:0;return 0;}
function mainAbilityText(r,p){const b=p?.mainCopy;if(b?.execution?.kind==='COPIED_ATTACK_MAIN'&&b.turn===(r.effectTurn||0)&&b.owner===r.seat&&p.main===b.copyId&&!p.mainAbilityDisabled&&!p.status.some(st=>['SLEEP','STUN'].includes(st)))return b.sourceText;return String(meta(p?.main)?.main||'');}
function attackContextReady(r,p,q,text){
 if(!q)return false;
 const revised=['C048','C057','C068','C141','C144'].find(code=>String(C[code].main)===text);
 if(revised){if(revised!=='C141'&&q.level!==p.level)return false;if(revised==='C141'&&(!q.main||!q.support.length||Object.values(q.guardian).some(g=>g.pending)))return false;}
 const code=[...batchAAttacks,...batchBTargetAttacks,'C115','C055'].find(code=>String(C[code].main)===text);
 if(!code)return true;
 if(code==='C045')return p.level===q.level&&p.stray.length>0;
 if(code==='C065')return q.hand.length>0;
 if(code==='C072'&&!q.support.length)return false;
 if(['C125','C162'].includes(code)&&!q.status.length)return false;
 if(['C170','C195'].includes(code)&&q.level!==p.level)return false;
 const copied=p.mainCopy?.execution?.sourceCard?.id===code;
 return !['C125','C162','C170','C195','C072','C115','C055'].includes(code)||abilityAvailable(r,p.seat,p.main,copied?'COPY_ATTACK_'+code:'MAIN');
}
function interferenceTargets(r,seat,text=null,extraPower=0){const p=r.players[seat];text??=mainAbilityText(r,p);if(!p||r.phase!=='ACTIONS'||r.seat!==seat||r.actionPoints<1||r.explore||!p.main||p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st))||!interferenceSupported(text))return [];return r.players.filter(q=>q.seat!==seat&&q.main&&attackContextReady(r,p,q,text)&&(q.level===p.level||p.returning!==q.returning&&Math.abs(q.level-p.level)===1)&&(!/(?:自分より|相手より)(?:合計)?POWER/.test(text)||interferenceAttackPower(r,seat,q.seat,text,'MAIN',null,extraPower)>interferenceDefensePower(r,q.seat))&&(!text.includes('相手MAINがPARASITE状態なら')||q.status.includes('PARASITE')));}
function pushbackTargets(r,seat,extraPower=0){if(r.mode!=='RETURN'||r.actionPoints<2)return [];return interferenceTargets(r,seat,null,extraPower).filter(q=>q.returning&&q.level>=1&&q.level<7);}
function commitAttackDeclaration(r,p,text){const code=[...batchAAttacks,'C072','C115','C055'].find(code=>String(C[code].main)===text);if(code)commitAbilityUse(r,p.seat,p.main,p.mainCopy?.execution?.sourceCard?.id===code?'COPY_ATTACK_'+code:'MAIN');}
function pushbackText(text){return '妨害：RETURN押し戻し'+(/(?:自分より|相手より)(?:合計)?POWER/.test(text)?'（合計POWERを比較）':'');}
function interferenceResolvedText(text,target){return text.includes('既にSTATUS状態なら、代わりにSLEEPにする。')&&target?.status?.length?text.replace('STUNにする。既にSTATUS状態なら、代わりにSLEEPにする。','SLEEPにする。'):text;}
function interferenceTargetUseful(text,q){if(text.includes('その相手は手札1枚'))return q.hand.length>0;if(text.includes('SUPPORT1体を捨て札'))return q.support.length>0;if(text.includes('遊動個体1体をその相手'))return true;const resolved=interferenceResolvedText(text,q),status=resolved.match(/(POISON|STUN|SLEEP|FEAR|PARASITE)にする/)?.[1];if(status)return !q.status.includes(status)||['G09','C051','C085','C113','C136','C167'].some(code=>text===String(C[code].main));if(text.includes('MAIN能力をこのターン無効'))return !q.mainAbilityDisabled;if(text.includes('SUPPORT能力1つをこのターン無効'))return (q.support||[]).some(id=>!q.disabledSupportIds?.includes(id)&&!!meta(id)?.support);return (window.Bot?.power(q)||0)>0;}
function copyAttackValue(r,p,execution){if(execution?.kind!=='COPIED_ATTACK_MAIN')return 0;const text=execution.sourceCard.main;return interferenceTargets(r,p.seat,text).some(q=>interferenceTargetUseful(text,q))?3:0;}
function copiedCostMain(r,p){const b=p?.mainCopy;if(!b||b.execution?.kind!=='COPIED_COST_MAIN'||b.turn!==(r.effectTurn||0)||b.owner!==r.seat||p.main!==b.copyId||p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st)))return null;return {code:b.execution.sourceCard.id,slot:'COPY_COST_'+b.execution.sourceCard.id};}
function copyCostValue(r,p,execution){const costTurn=execution?.kind==='COPIED_PROFILE'&&execution.sourceCard.id==='C110';if(!costTurn&&execution?.kind!=='COPIED_COST_MAIN')return 0;if(costTurn&&p.creatureCostTurn===(r.effectTurn||0))return 0;const code=execution.sourceCard.id;if(!costTurn&&!abilityAvailable(r,p.seat,p.main,'COPY_COST_'+code))return 0;const nonCreature=p.hand.filter(id=>!creature(id)).length,willBuy=r.market.some(id=>Number(meta(id).cost)>nonCreature&&Number(meta(id).cost)<=p.hand.length),willCopy=p.hand.some(id=>['C079','C154','C181'].includes(meta(id)?.id))&&guardianCopyOptions(r,p.seat).length>0;if(!willBuy&&!willCopy)return 0;if(costTurn)return 3;return ['C063','C135'].includes(code)?5:2+(code==='C108'&&p.level===5?3:0);}
function creatureCostCaptureBonus(r,p){if(!p.main||p.status.some(st=>['SLEEP','STUN'].includes(st)))return 0;let n=p.support.filter(id=>meta(id)?.id==='C105'&&!p.disabledSupportIds?.includes(id)&&abilityAvailable(r,p.seat,id,'SUPPORT')).length;if(p.mainAbilityDisabled)return n;if(meta(p.main)?.id==='C108'&&p.level===5&&abilityAvailable(r,p.seat,p.main,'MAIN'))n++;const copied=copiedCostMain(r,p);if(copied?.code==='C108'&&p.level===5&&abilityAvailable(r,p.seat,p.main,copied.slot))n++;if(meta(p.main)?.id==='C110'&&p.creatureCostTurn!==(r.effectTurn||0))n++;const b=p.mainCopy;if(b?.execution?.kind==='COPIED_PROFILE'&&b.execution.sourceCard.id==='C110'&&b.turn===(r.effectTurn||0)&&b.owner===r.seat&&p.main===b.copyId&&p.creatureCostTurn!==(r.effectTurn||0))n++;return n;}
function guardianCopyOptions(r,seat){const p=r.players[seat];if(!p||r.phase!=='ACTIONS'||r.seat!==seat||p.actedHand)return [];const out=[];for(const handId of p.hand.filter(id=>['C079','C154','C181'].includes(meta(id)?.id))){for(const target of copyTargetCandidates(r,seat,meta(handId).id,'HAND')){const pre=copyActivationPreflight(r,seat,handId,target.physicalId,'HAND');const amount=pre.ok?copyCaptureAmount(r,p,pre.execution,p.guardian[String(p.level)]?.id,true,handId):0;const compound=pre.ok&&pre.sourceCardId==='C186'&&p.support.length===2;if(amount>0||compound)out.push({handId,sourceId:target.physicalId,amount,costCaptureBonus:creatureCostCaptureBonus(r,p),...(compound?{compound:true,code:'C186'}:{})});}}return out;}
function copyMainBonus(r,p,kind,target=null){const b=p?.mainCopy;if(!r||!b||b.turn!==(r.effectTurn||0)||b.owner!==r.seat||p.main!==b.copyId||p.mainAbilityDisabled||p.status?.some(st=>['SLEEP','STUN'].includes(st)))return 0;if(b.execution.kind==='COPIED_PROFILE'){if(kind==='EXTRA_EXPLORE')return copyExploreAmount(r,p,b.execution);if(kind==='STATIC_POWER')return window.Bot?.copiedMainPower(p,b.execution.sourceCard)||0;if(kind==='STATIC_CAPTURE')return copyCaptureAmount(r,p,b.execution,target);return 0;}return b.execution.kind===kind?b.execution.amount:0;}
function bindMainCopy(r,p,sourceId){const pre=copyActivationPreflight(r,p.seat,p.main,sourceId,'MAIN');need(pre.ok,pre.reason);need(['STATIC_POWER','STATIC_CAPTURE','EXTRA_EXPLORE','COPIED_PROFILE','COPIED_COST_MAIN','COPIED_ATTACK_MAIN'].includes(pre.execution?.kind),'このコピー元の条件・コスト・時点の解決は未対応');p.mainCopy={copyId:p.main,sourceId,sourceText:pre.sourceText,execution:{...pre.execution},owner:r.seat,turn:r.effectTurn||0};}
function startPhase(r){const p=r.players[r.seat];r.phase='START';
 r.effectTurn=(r.effectTurn||0)+1; r.abilityUsage={};r.startStatusCleanseUsed??={};r.startStatusCleanseUsed[String(r.seat)]=false;
 expireEquipAtStart(r,p);
 r.actionPoints=0;p.moved=false;p.traded=false;p.actedHand=false;p.didInterfere=false;p.usedItemThisTurn=false;p.c174SuccessCount=0;for(const q of r.players){q.turnPowerBonus=0;q.turnPowerPenalty=0;q.turnCaptureBonus=0;q.firstDefenseUsed=[];q.c198AttackBlockedThisTurn=false;q.c198StatusBlockedThisTurn=false;q.c179DefensePending=false;q.mainAbilityDisabled=false;q.disabledSupportIds=[];q.mainCopy=null;q.creatureCostTurn=null;q.creatureDiscardTurn=null;q.actionCounts={};q.c174SuccessCounts={};q.handAttack=null;}captureStartSnapshot(r);if(startAbilityEligible(r,r.seat,'G24')){const n=draw(r,p,1);log(r,`${p.name} G24 START：${n}枚DRAW`);}}
// v0.8.3: Explicitly account for effect sources. No more free draw/discard shortcuts.
const handEffects=new Set(['S14','C011','C035','C117','C005']);
const blockedEffects=new Set(['C079','C154','C181']); // COPY is not certified.
const itemStandalone=new Set(['SI04','I16','I07','I27','I28','I29','I30','I31','I32','I33','I34','I35','I36','I18','I21','I37','I40']);
const itemInCapture=new Set(['SI02','I08','I09','I11','I12','I13','I14']);
const itemInMeta=new Set(['I22','I23','I24','I25','I26']);
function captureFailureOptions(r,seat){const p=r.players[seat];
 if(!p||r.phase!=='ACTIONS'||r.seat!==seat||r.explore?.owner!==seat)return [];
 return p.hand.filter(id=>['I10','C066'].includes(cardId(id)));
}
// Interrupt checkpoints replay an atomic command from its original state.
// Only the decisions and recorded shuffle values persist, so a resumed command
// cannot apply a cost, trigger, reflection or DRAW twice.
const interruptYield=Symbol('interrupt');
function interruptChoice(r,spec,owner,candidates,max=candidates.length){
 if(!interruptReplay||!candidates.length)return [];
 const window={...spec,owner,candidates:[...candidates],max};
 const x=interruptReplay,i=x.index++,decision=x.decisions[i];
 if(!decision)throw {tag:interruptYield,window};
 need(JSON.stringify(decision.window)===JSON.stringify(window),'割り込みのイベントが保存記録と不一致');
 const ids=decision.ids;need(Array.isArray(ids)&&new Set(ids).size===ids.length&&ids.length<=max&&ids.every(id=>candidates.includes(id)),'割り込みITEMの選択が不正');return ids;
}
function reactiveHandCopy(r,owner,event,codes){
 const p=r.players[owner];if(!codes.length||!interruptReplay||!p||r.phase!=='ACTIONS'||r.seat!==owner||p.actedHand||interruptReplay.action?.eventCopy===null)return null;
 const options=[];
 for(const handId of p.hand.filter(id=>['C079','C154','C181'].includes(cardId(id))))for(const x of copyTargetCandidates(r,owner,cardId(handId),'HAND')){if(!codes.includes(x.cardId))continue;const pre=copyActivationPreflight(r,owner,handId,x.physicalId,'HAND',true);if(pre.ok)options.push({key:handId+':'+x.physicalId,handId,sourceId:x.physicalId,code:x.cardId});}
 if(!options.length)return null;
 const selected=interruptChoice(r,{kind:'HAND_COPY',event,options},owner,options.map(o=>o.key),1)[0];if(!selected)return null;
 const o=options.find(o=>o.key===selected),old={main:p.main,support:[...p.support],level:p.level};p.actedHand=true;p.discard.push(take(p.hand,o.handId));resolveCreatureCostTriggers(r,p,[o.handId],old,'HAND_COPY_EVENT');
 commitAbilityUse(r,owner,o.handId,'HAND_REACTIVE_'+o.code);log(r,`${p.name} HAND COPY：${o.code}を${event.kind}の時点で1回実行`);return o;
}
function itemInterrupt(r,spec){
 const used=[];let offered=false;
 for(let offset=0;offset<r.players.length;offset++){
  const owner=(r.seat+offset)%r.players.length,p=r.players[owner];
  if(['CAPTURE_AID','INTERFERENCE_RESCUE'].includes(spec.kind)&&owner===spec.target)continue;
  if(spec.kind==='CAPTURE_FAILURE'&&owner!==spec.target)continue;
  const codes=spec.kind==='CAPTURE_AID'?['I38']:spec.kind==='INTERFERENCE_RESCUE'?['I39']:spec.kind==='CAPTURE_FAILURE'?['I10','C066']:[];
  const candidates=p.hand.filter(id=>codes.includes(cardId(id)));if(!candidates.length)continue;offered=true;
  const chosen=interruptChoice(r,spec,owner,candidates,spec.kind==='INTERFERENCE_RESCUE'||spec.kind==='CAPTURE_FAILURE'?1:candidates.length);
  for(const id of chosen){used.push({id,owner});if(spec.kind==='CAPTURE_FAILURE')continue;
   take(p.hand,id);r.removedItems.push(id);p.usedItemThisTurn=true;
   
   log(r,`${p.name} が${meta(id).name}のREACTIONを使用`);
  }
  if(chosen.length&&['INTERFERENCE_RESCUE','CAPTURE_FAILURE'].includes(spec.kind))break;
 }
 return {used,offered};
}
function itemSupported(card){const id=meta(card)?.id;return itemStandalone.has(id)||itemInCapture.has(id)||itemInMeta.has(id)||['SI01','SI03','I01','I02','I03','I04','I05','I06','I10','I15','I17','I19','I20','I37','I38','I39','I40'].includes(id);}
// A per-physical-card, per-ability-slot once-per-turn gate. Commit only after
// the event has passed its legality/condition checks; The next START clears usage for every seat, matching the global turn boundary.
function abilityUseKey(id,slot){return `${id}:${slot}`;}
function abilityAvailable(r,seat,id,slot){if(slot==='SUPPORT'&&r.players[seat]?.disabledSupportIds?.includes(id))return false;if(slot==='MAIN'&&r.players[seat]?.main===id&&r.players[seat]?.mainAbilityDisabled)return false;return !r.abilityUsage?.[String(seat)]?.[abilityUseKey(id,slot)];}
function commitAbilityUse(r,seat,id,slot){
 r.abilityUsage??={};const seatKey=String(seat);r.abilityUsage[seatKey]??={};
 const key=abilityUseKey(id,slot);need(!r.abilityUsage[seatKey][key],'このターンは能力使用済み');
 r.abilityUsage[seatKey][key]=true;
}
function queueDiscardTriggers(r,p,ids,reason){
 notifyCreatureDiscard(r,p,ids,reason);
 r.effectQueue??=[];
 for(const id of ids){const c=meta(id), t=String(c?.other||'');if(!t.startsWith('DISCARD'))continue;
  if(reason==='STOW'||reason==='FIELD'||reason==='RETURN')continue;
  if(t.includes('META素材として')&&reason!=='META')continue;
  if(t.includes('補給のコスト')&&reason!=='BUY')continue;
  if(t.includes('コストとして')&&!['BUY','META','L5','REACTION_COST'].includes(reason))continue;
  if(t.includes('POISON状態の相手')&&!r.players.some(q=>q!==p&&q.status.includes('POISON')))continue;
  if(['C114','C194'].includes(c.id)){if(c.id==='C194')r.effectQueue.push({owner:p.seat,id,draw:1,discard:0});queueTargetEffect(r,{owner:p.seat,source:id,code:c.id,mode:'POWER_LOSS'});continue;}
  // A supported DRAW clause must not silently consume a composite effect
  // whose additional target/STATUS/POWER operation is not implemented.
  const hasUnresolvedTarget=/(?:相手|対象|SUPPORT).{0,20}(?:POWER|STATUS|FEAR|POISON|STUN|SLEEP|PARASITE|無効)/.test(t);
  const supportedPower=t.includes('POWERを+1')&&!t.includes('引く')&&!hasUnresolvedTarget;
  // A DRAW + POWER compound cannot use the DRAW-only resolver: it would
  // silently omit the POWER part while consuming its once-per-turn use.
  const hasMixedDrawPower=/(?:枚引く|枚引き)/.test(t)&&/POWERを[+＋-－][0-9]+/.test(t);
  // Only the exact, unconditional DRAW + self POWER+1 combination is supported.
  // All other composites remain blocked to avoid silently dropping clauses.
  const simpleMixedDrawPower=/^DISCARD｜(?:[^：。]*：)?[1-9][0-9]*枚引く。POWERを\+1する。(?:1ターン1回。)?$/.test(t);
  const supportedDraw=/枚引く|枚引き/.test(t)&&!hasUnresolvedTarget&&(!hasMixedDrawPower||simpleMixedDrawPower);
  // Do not consume a once-per-turn ability for a branch that is not implemented.
  if(!supportedPower&&!supportedDraw){log(r,`${c.name} のDISCARD：自動処理未対応（使用回数は消費しない）`);continue;}
  const limited=t.includes('1ターン1回');if(limited&&!abilityAvailable(r,p.seat,id,'DISCARD'))continue;
  if(limited)commitAbilityUse(r,p.seat,id,'DISCARD');
  // Use the printed base draw count; alternate draws require their own condition.
  const baseDraw=t.match(/([1-9][0-9]*)枚引(?:く|き)/);
  let extra=baseDraw?Number(baseDraw[1]):1;
  if(t.includes('代わりに2枚引き')&&t.includes('PARASITE')&&r.players.some(q=>q!==p&&q.status.includes('PARASITE')))extra=2;
  if(t.includes('META素材なら、代わりに2枚引き')&&reason==='META')extra=2;
  if(t.includes('POWERを+1')&&!t.includes('引く')){p.turnPowerBonus=(p.turnPowerBonus||0)+1;log(r,`${c.name} のDISCARD：POWER+1（このターン）`);continue;}
  if(t.includes('相手MAIN1体のPOWERを-1')&&!t.includes('引く')){log(r,`${c.name} のDISCARD：対象MAIN POWER-1は要手動判定（対象未確定）`);continue;}
  if(simpleMixedDrawPower){p.turnPowerBonus=(p.turnPowerBonus||0)+1;log(r,`${c.name} のDISCARD：POWER+1（このターン）`);}
  if(/枚引く|枚引き/.test(t)){const swap=t.includes('枚捨てる');r.effectQueue.push({owner:p.seat,id,draw:extra,discard:swap?1:0});}
 }
 processEffectQueue(r);
}
// One serializable selector for effects that choose a player/card AFTER resolution.
function targetEffectCandidates(r,e){
 const actor=r.players[e.owner],target=r.players[e.target];if(!actor)return [];
 if(e.mode==='POWER_LOSS')return r.players.filter(q=>q.seat!==e.owner).map(q=>q.seat);
 if(e.mode==='HAND_DISCARD')return [...actor.hand];
 if(e.mode==='SUPPORT_DISCARD'||e.mode==='SUPPRESS_SUPPORT')return (target?.support||[]).filter(id=>e.mode!=='SUPPRESS_SUPPORT'||!target.disabledSupportIds?.includes(id)&&!!meta(id)?.support);
 if(e.mode==='STRAY_TAKE')return [...(target?.stray||[])];
 if(e.mode==='STRAY_GIVE')return [...actor.stray];
 return [];
}
function queueTargetEffect(r,e){r.effectQueue??=[];r.effectQueue.push({kind:'TARGET',turn:r.effectTurn||0,...e});}
function verifyTargetEffects(r){
 for(const e of [r.targetEffectPending,...(r.effectQueue||[]).filter(x=>x.kind==='TARGET')].filter(Boolean)){
  need(Number.isInteger(e.owner)&&r.players[e.owner]&&P[e.source]&&e.turn===(r.effectTurn||0),'対象選択の使用者・元カード・ターンが不正');
  const modes={C114:'POWER_LOSS',C194:'POWER_LOSS',C065:'HAND_DISCARD',C072:'SUPPORT_DISCARD',I29:'SUPPRESS_SUPPORT',I28:'STRAY_TAKE',C045:'STRAY_GIVE'};
  need(modes[e.code]===e.mode,'対象選択の能力種別が不正');
  if(e.mode==='POWER_LOSS')need(cardId(e.source)===e.code,'DISCARD元カードが不正');
  else {need(Number.isInteger(e.actor)&&r.players[e.actor]&&Number.isInteger(e.target)&&r.players[e.target]&&e.actor!==e.target,'対象選択の攻撃者・対象が不正');if(e.mode==='HAND_DISCARD')need(e.owner===e.target,'手札を捨てる本人が選択');else need(e.owner===e.actor,'能力使用者が対象を選択');
   if(['I28','I29'].includes(e.code))need(cardId(e.source)===e.code&&r.removedItems.includes(e.source)&&r.usedItemOwners?.[e.source]===e.actor,'ITEM由来の選択が不正');
   else {const actor=r.players[e.actor],binding=actor.mainCopy;need(actor.main===e.source&&(cardId(e.source)===e.code||binding?.copyId===e.source&&binding.execution?.sourceCard?.id===e.code&&binding.turn===(r.effectTurn||0)&&binding.sourceText===String(C[e.code].main))||!!handAttackRecord(r,e.actor,e.source,e.code,e.target),'MAIN/HAND由来の選択が不正');}
  }
  if(e===r.targetEffectPending){const candidates=targetEffectCandidates(r,e);need(Array.isArray(e.candidates)&&candidates.length>0&&e.candidates.length===candidates.length&&e.candidates.every((x,i)=>x===candidates[i]),'保存された選択候補が現在状態と不一致');}
 }
}
function processEffectQueue(r){if(r.effectPending||r.targetEffectPending)return;
 while(r.effectQueue?.length){const e=r.effectQueue.shift(),p=r.players[e.owner];if(e.kind==='TARGET'){const candidates=targetEffectCandidates(r,e);if(candidates.length){r.targetEffectPending={...e,candidates};return;}continue;}const n=draw(r,p,e.draw);log(r,`${meta(e.id).name}の能力：${n}枚DRAW`);
 if(e.discard&&p.hand.length){r.effectPending={owner:e.owner,source:e.id};break;}
 }
}
function interferenceSupported(text){if(['C048','C057','C068','C141','C144'].some(code=>String(C[code].main)===text))return true;return /妨害：/.test(text)&&/(POISON|STUN|SLEEP|FEAR|PARASITE)にする|MAIN能力をこのターン無効にする|SUPPORT能力1つをこのターン無効にする|(?:合計)?POWERを[-−][１２12]|その相手は手札1枚|SUPPORT1体を捨て札|遊動個体1体をその相手/.test(text);}
function reactionOptions(r,seat,text=r.pendingAttack?.text||''){
 const p=r.players[seat];if(!p)return [];
 const status=text.match(/(POISON|STUN|SLEEP|FEAR|PARASITE)にする/)?.[1],out=[];
 const profile=mainProfile(r,p,['C075']);const ready=profile&&abilityAvailable(r,seat,profile.id,profile.slot);
 for(const id of p.hand){const c=meta(id)?.id;
  if(['I15','I17'].includes(c)||c==='I19'&&['POISON','PARASITE'].includes(status)||c==='I20'&&['STUN','SLEEP'].includes(status))out.push({id,asMainCost:false});
  if(ready)out.push({id,asMainCost:true});
 }return out;
}
function payAttackReaction(r,p,att,a,inline=false){const seat=p.seat,old={main:p.main,support:[...p.support],level:p.level};
   if(a.id){need(p.hand.includes(a.id),'指定REACTIONカードがありません');const code=meta(a.id).id;
     need(a.asMainCost===undefined||typeof a.asMainCost==='boolean','REACTIONの使用方法が不正');
     const asMainCost=a.asMainCost===true||a.asMainCost===undefined&&!['I15','I17','I19','I20'].includes(code);
     need(reactionOptions(r,seat,att.text).some(o=>o.id===a.id&&o.asMainCost===asMainCost),'使える防御REACTIONではありません');
     take(p.hand,a.id);
     if(asMainCost){const profile=mainProfile(r,p,['C075']);need(profile,'防御能力がありません');commitAbilityUse(r,seat,p.main,profile.slot);p.discard.push(a.id);queueDiscardTriggers(r,p,[a.id],'REACTION_COST');if(inline)resolveCreatureCostTriggers(r,p,[a.id],old,'REACTION_COST');}
     else {r.removedItems.push(a.id);p.usedItemThisTurn=true;}
     if(code==='I20'&&att.itemCode==='I27'&&!asMainCost){att.statusOnlyBlocked=true;return false;}return true;
   }
 return false;
}
function c055SpreadTargets(r,seat,primary){const p=r.players[seat];return r.players.filter(q=>q.seat!==seat&&q.seat!==primary&&q.main&&q.level===p.level).map(q=>q.seat);}
function resolveC055Spread(r,a){
 const candidates=c055SpreadTargets(r,a.seat,a.target);if(!candidates.length)return;
 const target=interruptChoice(r,{kind:'C055_TARGET',primary:a.target,sourceId:a.sourceId,sourceCode:'C055'},a.seat,candidates,1)[0];
 need(target!==undefined,'追加寄生の対象を1人選択してください');
 const q=r.players[target],secondary={...a,target,targetHadStatus:q.status.length>0,c055Secondary:true};
 const defended=isAttackDefense(r,target,secondary.text);
 if(defended){if(defended==='I18'){const id=q.equip.find(id=>cardId(id)==='I18');take(q.equip,id);r.removedItems.push(id);}finishAttack(r,secondary,true);return;}
 const rescue=itemInterrupt(r,{kind:'INTERFERENCE_RESCUE',source:a.seat,target});if(rescue.used.length){finishAttack(r,secondary,true);return;}
 const options=reactionOptions(r,target,secondary.text).map(o=>({...o,key:o.id+':'+(o.asMainCost?'MAIN_COST':'ITEM')}));
 let blocked=false;if(options.length){const key=interruptChoice(r,{kind:'C055_DEFENSE',primary:a.target,target,sourceId:a.sourceId,options},target,options.map(o=>o.key),1)[0];const choice=options.find(o=>o.key===key);if(choice)blocked=payAttackReaction(r,q,secondary,choice,true);}
 finishAttack(r,secondary,blocked);
}
function resolveIncomingAttack(r,attack){
 const q=r.players[attack.target],defended=isAttackDefense(r,attack.target,attack.text);
 if(defended){if(defended==='I18'){const id=q.equip.find(id=>meta(id).id==='I18');take(q.equip,id);r.removedItems.push(id);}finishAttack(r,attack,true);return;}
 if(!attack.ropeChecked){attack.ropeChecked=true;const rescue=itemInterrupt(r,{kind:'INTERFERENCE_RESCUE',source:attack.seat,target:attack.target});if(rescue.used.length){finishAttack(r,attack,true);return;}}
 if(attack.target===0&&attack.seat!==0||attack.target>0&&reactionOptions(r,attack.target,attack.text).length){r.pendingAttack=attack;log(r,`${r.players[attack.seat].name}が${q.name}に妨害！REACTIONを選んでください`);}
 else finishAttack(r,attack,false);
}
function eligibleAttack(r,seat,target,sourceText){const p=r.players[seat],q=r.players[target];need(seat!==target&&q,'妨害対象が不正');need(p.main&&!p.mainAbilityDisabled&&!p.status.includes('STUN')&&!p.status.includes('SLEEP'),'MAIN能力が使用できません');need(sourceText.includes('妨害：'),'妨害ACTIONを持つMAINが必要');need(p.level===q.level||p.returning!==q.returning&&Math.abs(p.level-q.level)===1,'妨害の射程外です');return q;}
function isAttackDefense(r,target,txt){const q=r.players[target];if(q.equip.some(id=>meta(id).id==='I21'))return 'I21';if(q.equip.some(id=>meta(id).id==='I18'))return 'I18';
 // Explicit permanent first-attack defense. Tracked per attacker's turn.
 const c=q.main&&meta(q.main);
 const enabled=c&&!q.mainAbilityDisabled&&!q.status.some(st=>['SLEEP','STUN'].includes(st));
 const binding=q.mainCopy,code=binding?.execution?.sourceCard?.id;
 const borrowed=enabled&&binding?.execution?.kind==='COPIED_PROFILE'&&binding.copyId===q.main&&binding.owner===q.seat&&binding.owner===r.seat&&binding.turn===(r.effectTurn||0)&&binding.sourceText===String(C[code]?.main);
 const comparison=/(?:自分より|相手より)(?:合計)?POWER|合計POWERを比較/.test(txt);
 if(enabled&&(['G10','C188'].includes(c.id)||borrowed&&['G10','C188'].includes(code))&&comparison)return 'POWER_COMPARE_DEFENSE';
 const differentSupport=()=>{const main=window.Bot?.mainSpecies(q)||new Set([c.species]);return main.size>0&&(q.support||[]).some(id=>{const sp=window.Bot?.effectiveSpecies(q,id)||new Set([meta(id).species]);return sp.size>0&&![...sp].some(kind=>main.has(kind));});};
 if(enabled&&borrowed&&code==='C038'&&differentSupport()){q.firstDefenseUsed??=[];if(!q.firstDefenseUsed.includes(r.seat)){q.firstDefenseUsed.push(r.seat);return 'COPY_C038';}}
 if(borrowed&&['G05','C127','C049','C056','C179','C126','C198'].includes(code)){q.firstDefenseUsed??=[];if(!q.firstDefenseUsed.includes(r.seat)){q.firstDefenseUsed.push(r.seat);if(code==='C179')q.c179DefensePending=true;return 'COPY_FIRST_ATTACK';}}
 if(c?.id==='C198'&&!q.mainAbilityDisabled&&!q.status.includes('SLEEP')&&!q.status.includes('STUN')&&!q.c198AttackBlockedThisTurn){q.c198AttackBlockedThisTurn=true;return 'C198';}
 if(c&&!q.mainAbilityDisabled&&(String(c.main||'').includes('最初の妨害を無効')||['C179','C126'].includes(c.id))&&(c.id!=='C038'||differentSupport())&&!q.status.includes('SLEEP')&&!q.status.includes('STUN')){q.firstDefenseUsed??=[];if(!q.firstDefenseUsed.includes(r.seat)){q.firstDefenseUsed.push(r.seat);if(c.id==='C179')q.c179DefensePending=true;return 'MAIN';}}
 if(!q.status.some(st=>['SLEEP','STUN'].includes(st)))for(const id of q.support||[]){
  if(meta(id)?.id==='C126'&&abilityAvailable(r,target,id,'SUPPORT')){commitAbilityUse(r,target,id,'SUPPORT');return 'SUPPORT';}
 }
 return null;
}
function applyPowerReductionCaptureTriggers(r,q){
 // v2.0: C006 MAIN and C028 SUPPORT gain CAPTURE +1 after a
 // successful interference actually reduces this MAIN's total POWER.
 const triggers=[];
 if(q.main&&meta(q.main)?.id==='C006'&&!q.status.includes('STUN')&&!q.status.includes('SLEEP'))triggers.push([q.main,'MAIN']);
 if(activeCopiedProfileCode(r,q)==='C006')triggers.push([q.main,'COPY_C006']);
 for(const id of q.support||[])if(meta(id)?.id==='C028'&&!q.status.includes('STUN')&&!q.status.includes('SLEEP'))triggers.push([id,'SUPPORT']);
 for(const [id,slot] of triggers){
  if(!abilityAvailable(r,q.seat,id,slot))continue;
  commitAbilityUse(r,q.seat,id,slot);
  q.turnCaptureBonus=(q.turnCaptureBonus||0)+1;
  log(r,`${q.name} の${meta(id).id} ${slot}：POWER低下後、捕獲力 +1（このターン）`);
 }
}
function interferenceSuccessDrawProfile(r,p){
 if(!p?.main||p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st)))return null;
 const native=meta(p.main)?.id,code=['C048','C133'].includes(native)?native:activeCopiedProfileCode(r,p);
 if(!['C133'].includes(code))return null;
 const slot=native===code?'MAIN':'COPY_SUCCESS_'+code;
 return {code,slot,available:abilityAvailable(r,p.seat,p.main,slot),discard:code==='C133'&&hasSupportSpecies(p,'胞子種')?0:1};
}
function mainHandCycleSource(r,p){const code=meta(p?.main)?.id;if(['S08','S12','C011'].includes(code))return code;const copied=activeCopiedProfileCode(r,p);return ['S08','S12','C011'].includes(copied)?copied:null;}
function mainStatusCleanseSource(r,p){const code=meta(p?.main)?.id;if(code==='S08')return code;const copied=activeCopiedProfileCode(r,p);return copied==='S08'?copied:null;}
function activeCopiedProfileCode(r,p){const b=p?.mainCopy,code=b?.execution?.sourceCard?.id;return p?.main&&!p.mainAbilityDisabled&&!p.status?.some(st=>['SLEEP','STUN'].includes(st))&&b?.execution?.kind==='COPIED_PROFILE'&&b.copyId===p.main&&b.owner===p.seat&&b.owner===r.seat&&b.turn===(r.effectTurn||0)&&C[code]&&b.sourceText===String(C[code].main)?code:null;}
function applyInterferencePowerLoss(r,source,target,amount,context={}){
 const initialPower=window.Bot?.power(target);if(initialPower!==undefined&&initialPower<=0)return false;
 const copiedPowerDefense=activeCopiedProfileCode(r,target);
 // Borrowed passive defense applies to the physical COPY actor, before limited SUPPORT defenses.
 const binding=target.mainCopy,code=binding?.execution?.sourceCard?.id;
 if(source.seat!==target.seat&&target.main&&!target.mainAbilityDisabled&&!target.status.some(st=>['SLEEP','STUN'].includes(st))
    &&binding?.execution?.kind==='COPIED_PROFILE'&&['G02','G18','G22'].includes(code)
    &&binding.copyId===target.main&&binding.owner===target.seat&&binding.owner===r.seat
    &&binding.turn===(r.effectTurn||0)&&binding.sourceText===String(C[code].main))return false;
 if(target.main&&!target.mainAbilityDisabled&&!target.status.some(st=>['SLEEP','STUN'].includes(st))){
 if(['S03','C126','C178'].includes(copiedPowerDefense)&&abilityAvailable(r,target.seat,target.main,'COPY_POWER_FIRST')){commitAbilityUse(r,target.seat,target.main,'COPY_POWER_FIRST');if(copiedPowerDefense==='C178')target.turnPowerBonus=(target.turnPowerBonus||0)+1;return false;}
 const sources=[{id:target.main,slot:'MAIN',text:meta(target.main)?.main||''},...target.support.map(id=>({id,slot:'SUPPORT',text:meta(id)?.support||''}))];
 for(const x of sources){if(!abilityAvailable(r,target.seat,x.id,x.slot))continue;
 if(source.seat!==target.seat&&/^相手の効果による直接の合計POWER低下を無効にする。?$/.test(x.text.replace(/^(MAIN|SUPPORT)[｜:：]/,'')))return false;
 const first=x.text.includes('そのターン最初の合計POWER低下を無効')||x.text.includes('そのターン最初の1回だけ低下を無効')||meta(x.id)?.id==='C126'&&x.slot==='MAIN';
 if(first){commitAbilityUse(r,target.seat,x.id,x.slot);if(/POWERを\+1/.test(x.text))target.turnPowerBonus=(target.turnPowerBonus||0)+1;log(r,`${target.name} ${meta(x.id).id} ${x.slot}：最初のPOWER低下を無効化`);return false;}
 }
 }

 const c187Slot=copiedPowerDefense==='C187'?'COPY_POWER_C187':'MAIN';
 if((meta(target.main)?.id==='C187'||copiedPowerDefense==='C187')&&!target.status.includes('SLEEP')&&!target.status.includes('STUN')&&abilityAvailable(r,target.seat,target.main,c187Slot)){
  commitAbilityUse(r,target.seat,target.main,c187Slot);
  target.turnPowerBonus=(target.turnPowerBonus||0)+1;
  log(r,`${target.name} C187 MAIN：妨害によるPOWER低下を無効化し、POWER +1`);
  return false;
 }
 const handDefense=reactiveHandCopy(r,target.seat,{kind:'POWER_BEFORE',source:source.seat,target:target.seat,amount,reflection:!!context.reflection},['S03','C126','C178','C187',...(source.seat!==target.seat?['G02','G18','G22']:[])]);if(handDefense){if(['C178','C187'].includes(handDefense.code))target.turnPowerBonus=(target.turnPowerBonus||0)+1;return false;}
 if(itemInterrupt(r,{kind:'POWER_RESCUE',source:source.seat,target:target.seat,amount,interference:context.interference!==false,reflection:!!context.reflection}).used.length)return false;
 const powerBefore=window.Bot?.power(target);target.turnPowerPenalty=(target.turnPowerPenalty||0)+amount;
 if(context.interference!==false){applyPowerReductionCaptureTriggers(r,target);applyPowerReductionDraw(r,target);}
 emitGameEvent(r,{type:'POWER_REDUCED',seat:source.seat,target:target.seat,amount});
 const loss=powerBefore===undefined?amount:Math.max(0,powerBefore-(window.Bot?.power(target)||0)),actualLoss=loss>0;
 const handAfter=actualLoss?reactiveHandCopy(r,target.seat,{kind:'POWER_AFTER',source:source.seat,target:target.seat,loss,interference:context.interference!==false,reflection:!!context.reflection},[...(context.interference!==false?['C006']:[]),...(!context.reflection&&source.seat!==target.seat?['C078']:[])]):null;if(handAfter?.code==='C006')target.turnCaptureBonus=(target.turnCaptureBonus||0)+1;if(handAfter?.code==='C078')applyInterferencePowerLoss(r,target,source,loss,{...context,reflection:true});
 const reflection=mainProfile(r,target,['C078']);if(actualLoss&&!context.reflection&&source.seat!==target.seat&&reflection&&abilityAvailable(r,target.seat,reflection.id,reflection.slot)){commitAbilityUse(r,target.seat,reflection.id,reflection.slot);applyInterferencePowerLoss(r,target,source,loss,{...context,reflection:true});}
 if(actualLoss&&target.main&&!target.status.some(st=>['SLEEP','STUN'].includes(st)))for(const sid of target.support)if(meta(sid).id==='C078'&&!target.disabledSupportIds?.includes(sid)&&abilityAvailable(r,target.seat,sid,'SUPPORT')){commitAbilityUse(r,target.seat,sid,'SUPPORT');applyInterferencePowerLoss(r,target,source,1,{...context,reflection:true});log(r,`${target.name} C078 SUPPORT：POWER低下を受けた後、原因プレイヤーのPOWER -1`);}
 return true;
}
function applyPowerReductionDraw(r,q){
 // C165 SUPPORT: when MAIN's total POWER is reduced by interference, draw one.
 for(const id of q.support||[]){
  if(meta(id)?.id!=='C165'||q.status.includes('SLEEP')||q.status.includes('STUN')||!abilityAvailable(r,q.seat,id,'SUPPORT'))continue;
  commitAbilityUse(r,q.seat,id,'SUPPORT');
  draw(r,q,1);
  log(r,`${q.name} C165 SUPPORT：妨害によるPOWER低下後、1枚引く`);
 }
}
function applyInterferenceResponsePower(r,q,blocked,wasActive,wasPowerReduced){
 // Resolve effects against the pre-attack active state. Only printed
 // "once per turn" effects use abilityUsage; a blocked attack is still received.
 const entries=[];
 for(const id of q.support||[]){
  const cid=meta(id)?.id;
  if(cid==='C043')entries.push([id,'SUPPORT',1,true]);
  if(cid==='C197'&&blocked)entries.push([id,'SUPPORT',1,true]);
  if(cid==='C048'&&wasPowerReduced)entries.push([id,'SUPPORT',1,false]);
 }
 const responseProfile=mainProfile(r,q,['C101'],wasActive);if(responseProfile)entries.push([q.main,responseProfile.slot,2,false]);
 for(const [id,slot,amount,onBlocked] of entries){
  if(blocked&&!onBlocked)continue;
  if(!wasActive||!abilityAvailable(r,q.seat,id,slot))continue;
  commitAbilityUse(r,q.seat,id,slot);
  q.turnPowerBonus=(q.turnPowerBonus||0)+amount;
  log(r,`${meta(id).id} ${slot}：妨害${blocked?'を受けた':'成功後'}、POWER +${amount}`);
 }
}
function queueDefenderMainReaction(r,q,blocked,wasActive){
 if(!wasActive||!q.main)return;
 const profile=mainProfile(r,q,['C073','C150','C062'],wasActive);if(!profile)return;const cid=profile.code;
 if(cid!=='C150'&&blocked)return;
 if(!abilityAvailable(r,q.seat,q.main,profile.slot))return;
 if(cid==='C062'&&q.status.length){
  if(q.status.length>1){r.statusCleansePending={owner:q.seat,source:q.main,statuses:[...q.status],required:true,code:cid,slot:profile.slot};return;}
  commitAbilityUse(r,q.seat,q.main,profile.slot);const status=q.status[0];take(q.status,status);
  emitGameEvent(r,{type:'STATUS_REMOVED',seat:q.seat,target:q.seat,status,action:'C062_MAIN'});resolveStatusRemovedTriggers(r,q);
  if(r.statusSacrificePending?.owner===q.seat&&!q.status.includes(r.statusSacrificePending.status))r.statusSacrificePending=null;
  log(r,`${q.name} C062 MAIN：妨害成功後、STATUS ${status}解除`);return;
 }
 commitAbilityUse(r,q.seat,q.main,profile.slot);
 r.effectQueue??=[];
 r.effectQueue.push({owner:q.seat,id:q.main,draw:1,discard:1});
 processEffectQueue(r);
 log(r,`${q.name} ${cid} MAIN：妨害${blocked?'失敗':'成功'}後、1枚引き1枚捨てる`);
}
function queueStatusReceivedReactions(r,q,eligibleIds){
 // Snapshot eligibility before the newly applied STATUS. Preserve SUPPORT order.
 for(const id of q.support||[]){
  if(!eligibleIds.includes(id))continue;
  const cid=meta(id)?.id;
  if(cid==='C014'||cid==='C149'){
   commitAbilityUse(r,q.seat,id,'SUPPORT');
   r.effectQueue??=[];
   r.effectQueue.push({owner:q.seat,id,draw:1,discard:cid==='C014'?1:0});
   log(r,`${q.name} ${cid} SUPPORT：STATUS受領後のDRAWを予約`);
  }else if(cid==='C101'){
   commitAbilityUse(r,q.seat,id,'SUPPORT');
   q.turnPowerBonus=(q.turnPowerBonus||0)+1;
   log(r,`${q.name} C101 SUPPORT：STATUS受領後、このターンPOWER +1`);
  }else if(cid==='C127'){
   const st=q.status[q.status.length-1];
   if(st&&!r.statusSacrificePending)r.statusSacrificePending={owner:q.seat,id,status:st};
  }else if(cid==='C062'){
   // C062 SUPPORT is a sacrifice, not a once-per-turn bonus.
   // Resolve the newly received status and remove this physical SUPPORT.
   const st=q.status[q.status.length-1];
   if(!st)continue;
   const pos=q.support.indexOf(id);
   if(pos<0)continue;
   q.support.splice(pos,1);
   cycle(r,id);
   q.status.splice(q.status.lastIndexOf(st),1);
   emitGameEvent(r,{type:'STATUS_REMOVED',seat:q.seat,target:q.seat,status:st,action:'C062'});
   draw(r,q,1);
   resolveStatusRemovedTriggers(r,q);
   log(r,`${q.name} C062 SUPPORT：自身を捨てて${st}解除、1枚引く`);
  }
 }
 // An automatic C062 sacrifice may already have removed the STATUS.
 // Do not leave an impossible C127 choice pending, regardless of SUPPORT order.
 if(r.statusSacrificePending?.owner===q.seat&&!q.status.includes(r.statusSacrificePending.status)){
  r.statusSacrificePending=null;
 }
 processEffectQueue(r);
}
function preventFirstFearSleep(r,q,status,responseWasActive){
 if(!['FEAR','SLEEP'].includes(status)||!responseWasActive)return false;
 const sources=[];
 if(meta(q.main)?.id==='C099')sources.push({id:q.main,slot:'MAIN'});
 if(activeCopiedProfileCode(r,q)==='C099')sources.push({id:q.main,slot:'COPY_STATUS_C099'});
 if(window.Bot?.mainSpecies?.(q).has('鱗種')??meta(q.main)?.species==='鱗種')for(const id of q.support||[]){
  if(meta(id)?.id==='C099')sources.push({id,slot:'SUPPORT'});
 }
 for(const source of sources){
  if(!abilityAvailable(r,q.seat,source.id,source.slot))continue;
  commitAbilityUse(r,q.seat,source.id,source.slot);
  log(r,`${q.name} C099 ${source.slot}：最初の${status}を無効化`);
  return true;
 }
 return false;
}
function mainStatusImmunity(r,q,status){
 if(!q.main||q.mainAbilityDisabled||q.status.some(st=>['SLEEP','STUN'].includes(st)))return null;
 const immunity={G16:'SLEEP',G26:'STUN',G28:'FEAR'};
 const native=meta(q.main)?.id;
 if(immunity[native]===status)return {code:native,copied:false};
 const b=q.mainCopy,code=b?.execution?.sourceCard?.id;
 if(b?.execution?.kind==='COPIED_PROFILE'&&b.copyId===q.main&&b.owner===q.seat
    &&b.owner===r.seat&&b.turn===(r.effectTurn||0)&&immunity[code]===status
    &&b.sourceText===String(C[code].main))return {code,copied:true};
 return null;
}
function preventIncomingStatus(r,q,status,responseWasActive){
 // Unlimited type-specific immunity precedes consumable/first-use defenses.
 // It suppresses a new application only, never removes an existing STATUS.
 const immunity=responseWasActive?mainStatusImmunity(r,q,status):null;
 if(immunity){log(r,`${q.name} ${immunity.code}${immunity.copied?' COPY':''} MAIN：${status}付与を無効化`);return true;}
 const c049=(q.support||[]).find(id=>meta(id)?.id==='C049');
 const c049Protects=!!c049&&(window.Bot?.mainSpecies?.(q).has('鱗種')??meta(q.main)?.species==='鱗種')&&responseWasActive&&abilityAvailable(r,q.seat,c049,'SUPPORT');
 if(c049Protects){
  commitAbilityUse(r,q.seat,c049,'SUPPORT');
  log(r,`${q.name} C049 SUPPORT：最初のSTATUS ${status} を無効化`);
  return true;
 }
 if(responseWasActive&&(meta(q.main)?.id==='C198'||activeCopiedProfileCode(r,q)==='C198')&&!q.mainAbilityDisabled&&!q.status.includes('SLEEP')&&!q.status.includes('STUN')&&!q.c198StatusBlockedThisTurn){
  q.c198StatusBlockedThisTurn=true;
  log(r,`${q.name} C198 MAIN：最初のSTATUS ${status} を無効化`);
  return true;
 }
 if(status==='STUN'&&responseWasActive){
  const copied=activeCopiedProfileCode(r,q)==='C090',slot=copied?'COPY_STATUS_C090':'MAIN';
  if((meta(q.main)?.id==='C090'||copied)&&abilityAvailable(r,q.seat,q.main,slot)){
   commitAbilityUse(r,q.seat,q.main,slot);log(r,`${q.name} C090${copied?' COPY':''} MAIN：最初のSTUNを無効化`);return true;
  }
 }
 if(preventFirstFearSleep(r,q,status,responseWasActive))return true;
 // C082 SUPPORT: sacrifice itself when MAIN would receive SLEEP.
 // Only after other non-consuming prevention, to avoid wasting the card.
 if(status==='SLEEP'&&responseWasActive){
  const c082=(q.support||[]).find(id=>meta(id)?.id==='C082'&&abilityAvailable(r,q.seat,id,'SUPPORT'));
  if(c082){
   take(q.support,c082);cycle(r,c082);draw(r,q,1);
   log(r,`${q.name} C082 SUPPORT：SLEEPを無効化し、SUPPORTを循環へ戻して1枚引く`);
   return true;
  }
 }
 // S08/C005 SUPPORT: prevent the incoming STATUS by sacrificing this SUPPORT.
 // Existing non-consuming prevention and the SLEEP-specific C082 remain first.
 if(responseWasActive){
  const source=(q.support||[]).find(id=>['S08','C005'].includes(meta(id)?.id)&&abilityAvailable(r,q.seat,id,'SUPPORT'));
  if(source){take(q.support,source);cycle(r,source);log(r,`${q.name} ${meta(source).id} SUPPORT：自身を捨てて${status}を無効化`);return true;}
 }
 const codes=['C198',...(status==='STUN'?['C090','G26']:[]),...(['FEAR','SLEEP'].includes(status)?['C099']:[]),...(status==='SLEEP'?['G16']:[]),...(status==='FEAR'?['G28']:[])];return !!reactiveHandCopy(r,q.seat,{kind:'STATUS_BEFORE',target:q.seat,status},codes);
}
// C142 armour only modifies the defending side of a POWER-comparison interference.
// This bonus is not stored on the player and cannot leak into exploration/FORCE.
function interferenceAttackPower(r,seat,target,text=null,slot='MAIN',override=null,extraPower=0){
 const p=override||r.players[seat],q=r.players[target];let n=0;
 if(!p?.main||!q||r.seat!==seat||slot!=='HAND'&&p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st)))return window.Bot?.power(p,extraPower)||0;
 const desc=text??String(meta(p.main)?.main||'');
 const compares=/(?:自分より|相手より)(?:合計)?POWER/.test(desc);
 for(const id of p.support||[]){
  if(!abilityAvailable(r,seat,id,'SUPPORT'))continue;
  if(meta(id)?.id==='C174'&&compares&&slot==='MAIN')n+=1;
  const beast=window.Bot?.mainSpecies?.(p).has('獣種')??meta(p.main)?.species==='獣種';
  if(meta(id)?.id==='S11'&&(q.status.length||q.turnPowerPenalty>0))n+=1;
  if(beast&&meta(id)?.id==='C119'&&q.status.length)n+=1;
  if(beast&&meta(id)?.id==='C139'&&p.level===q.level)n+=1;
 }
 return window.Bot?.power(p,extraPower+n)??Math.max(0,extraPower+n);
}
function interferenceDefensePower(r,seat){
 const q=r.players[seat];let n=0;
 if(!q?.main||q.status.includes('SLEEP')||q.status.includes('STUN'))return window.Bot?.power(q)||0;
 const armour=mainProfile(r,q,['C142']);if(armour&&abilityAvailable(r,seat,q.main,armour.slot))n+=2;
 if(window.Bot?.mainSpecies?.(q).has('鱗種')??meta(q.main)?.species==='鱗種')for(const id of q.support||[]){if(meta(id)?.id==='C198'&&abilityAvailable(r,seat,id,'SUPPORT'))n+=2;}
 for(const id of q.support||[]){
  if(meta(id)?.id==='C142'&&abilityAvailable(r,seat,id,'SUPPORT'))n+=1;
 }
 if(!q.status.some(st=>['SLEEP','STUN'].includes(st)))for(const id of q.support||[])if(meta(id)?.id==='S11'&&!q.disabledSupportIds?.includes(id)){const opponent=r.players[r.seat];if(opponent&&opponent!==q&&(opponent.status.length||opponent.turnPowerPenalty>0))n++;}
 return window.Bot?.power(q,n)??Math.max(0,n);
}
function supportDisableMainSource(r,p,text=null){
 const codes=['C044','C080','C141','C144','C054'],b=p?.mainCopy;
 if(b?.execution?.kind==='COPIED_ATTACK_MAIN'&&b.copyId===p.main&&b.owner===p.seat
    &&b.turn===(r.effectTurn||0)&&codes.includes(b.execution.sourceCard.id)
    &&b.sourceText===String(C[b.execution.sourceCard.id].main)&&(text===null||b.sourceText===text))return b.execution.sourceCard.id;
 const card=meta(p?.main);return codes.includes(card?.id)&&(text===null||card.main===text)?card.id:null;
}
function queueSupportDisable(r,e){
 if(r.supportDisablePending){r.supportDisableQueue??=[];r.supportDisableQueue.push(e);}else r.supportDisablePending=e;
}
function verifySupportDisableChoices(r){
 need(r.supportDisableQueue===undefined||Array.isArray(r.supportDisableQueue),'SUPPORT無効化の待ち行列が不正');
 const queued=r.supportDisableQueue||[];need(!queued.length||!!r.supportDisablePending,'SUPPORT無効化の先頭選択がありません');
 for(const e of [r.supportDisablePending,...queued].filter(Boolean)){
  const owner=r.players[e.owner],target=r.players[e.target],card=meta(e.source);
  need(Number.isInteger(e.owner)&&Number.isInteger(e.target)&&owner&&target&&e.owner!==e.target,'SUPPORT無効化の選択者・対象が不正');
  need(owner.main===e.source&&!!supportDisableMainSource(r,owner)||e.handCopy&&['C044','C080','C141','C144','C054'].includes(e.code)&&!!handAttackRecord(r,e.owner,e.source,e.code,e.target)||card?.id==='C183'&&owner.support.includes(e.source),'SUPPORT無効化の発動元が不正');
  need(Array.isArray(e.candidates)&&e.candidates.length>0&&new Set(e.candidates).size===e.candidates.length&&e.candidates.every(id=>target.support.includes(id)&&!!meta(id)?.support&&!target.disabledSupportIds?.includes(id)),'SUPPORT無効化の候補が不正');
 }
}
function finishAttack(r,a,blocked){const q=r.players[a.target],p=r.players[a.seat],desc=a.text;let newlyAppliedParasite=false;
 const hadParasiteBefore=q.status.includes('PARASITE');
 const targetHadStatus=typeof a.targetHadStatus==='boolean'?a.targetHadStatus:q.status.length>0;
 const responseWasActive=!q.status.includes('SLEEP')&&!q.status.includes('STUN');
 const statusReactionEligible=(q.support||[]).filter(id=>responseWasActive&&['C014','C101','C149','C062','C127'].includes(meta(id)?.id)&&abilityAvailable(r,q.seat,id,'SUPPORT'));
 const s13=q.support.find(id=>meta(id)?.id==='S13');
 const s13Eligible=!!s13&&!q.status.includes('SLEEP')&&!q.status.includes('STUN')&&abilityAvailable(r,q.seat,s13,'SUPPORT');
 // Determine STATUS-only prevention before publishing the interference result.
 // Reapplication keeps the adopted success semantics without a new STATUS event.
 const incomingStatus=desc.match(/(POISON|STUN|SLEEP|FEAR|PARASITE)にする/)?.[1];
 const statusChecked=!a.pushback&&!!incomingStatus&&!q.status.includes(incomingStatus);
 let statusOnlyBlocked=!!a.statusOnlyBlocked;
 if(!blocked&&statusChecked&&preventIncomingStatus(r,q,incomingStatus,responseWasActive)){if(a.itemCode==='I27')statusOnlyBlocked=true;else blocked=true;}
 emitGameEvent(r,{type:blocked?'INTERFERE_BLOCKED':'INTERFERE_RESOLVED',seat:a.seat,target:a.target,...(a.c055Secondary?{action:'C055_SECONDARY'}:{})});
 if(blocked){
  const binding=q.mainCopy,copiedC179=binding?.execution?.kind==='COPIED_PROFILE'&&binding.execution.sourceCard.id==='C179'&&binding.copyId===q.main&&binding.owner===q.seat&&binding.owner===r.seat&&binding.turn===(r.effectTurn||0)&&binding.sourceText===String(C.C179.main);
  if((meta(q.main)?.id==='C179'||copiedC179)&&!q.mainAbilityDisabled&&!q.status.includes('SLEEP')&&!q.status.includes('STUN')&&q.c179DefensePending){
   q.c179DefensePending=false;
   r.effectQueue??=[];
   r.effectQueue.push({owner:q.seat,id:q.main,draw:1,discard:1});
   processEffectQueue(r);
   log(r,`${q.name} C179 MAIN：妨害無効化後、1枚引き1枚捨てる`);
  }
  applyInterferenceResponsePower(r,q,true,responseWasActive);
  // C150 SUPPORT: capture bonus after a failed interference against MAIN.
  for(const id of q.support||[]){
   if(meta(id)?.id!=='C150'||!responseWasActive||!abilityAvailable(r,q.seat,id,'SUPPORT'))continue;
   commitAbilityUse(r,q.seat,id,'SUPPORT');
   q.turnCaptureBonus=(q.turnCaptureBonus||0)+1;
   log(r,`${q.name} C150 SUPPORT：妨害失敗後、このターン捕獲力 +1`);
  }
  // v2.0: failed interference reactions from the defender's SUPPORTs.
  // Resolve from the pre-attack active state; each printed reaction is once per turn.
  for(const id of q.support||[]){
   const cid=meta(id)?.id;
   if(!responseWasActive||!abilityAvailable(r,q.seat,id,'SUPPORT'))continue;
   if(cid==='C061'||cid==='C146'){
    const st=cid==='C061'?'STUN':'FEAR';
    commitAbilityUse(r,q.seat,id,'SUPPORT');
    if(!p.status.includes(st)){
     const active=!p.status.includes('SLEEP')&&!p.status.includes('STUN');
     const statusEligible=(p.support||[]).filter(id=>active&&['C014','C101','C149','C062','C127'].includes(meta(id)?.id)&&abilityAvailable(r,p.seat,id,'SUPPORT'));
     if(!preventIncomingStatus(r,p,st,active)){
      p.status.push(st);
      emitGameEvent(r,{type:'STATUS_APPLIED',seat:q.seat,target:p.seat,status:st});
      queueStatusReceivedReactions(r,p,statusEligible);
     }
    }
    log(r,`${q.name} ${cid} SUPPORT：妨害失敗への反撃${st}（${p.name}は${p.status.includes(st)?"付与中":"未付与"}）`);
   }else if(cid==='C073'){
    commitAbilityUse(r,q.seat,id,'SUPPORT');
    draw(r,q,1);
    log(r,`${q.name} C073 SUPPORT：妨害失敗後、1枚引く`);
   }
  }
  queueDefenderMainReaction(r,q,true,responseWasActive);
  log(r,`${p.name}の妨害は${q.name}に防御された`);return;
 }
 let targetEffect=false;const attackCode=a.pushback?'PUSHBACK':a.itemCode||a.sourceCode||(desc===String(meta(p.main)?.main)?cardId(p.main):null),physicalSource=a.sourceId||p.main;
 if(['C045','C065','C072','I28','I29'].includes(attackCode)){
  const mode={C045:'STRAY_GIVE',C065:'HAND_DISCARD',C072:'SUPPORT_DISCARD',I28:'STRAY_TAKE',I29:'SUPPRESS_SUPPORT'}[attackCode];
  queueTargetEffect(r,{owner:attackCode==='C065'?q.seat:p.seat,actor:p.seat,target:q.seat,source:physicalSource,code:attackCode,mode});targetEffect=true;
 }
 let didPowerDrop=false;
 if(!a.pushback){
  if(attackCode==='C012'){const x=take(p.hand,a.giftId);q.discard.push(x);recordTransfer(r,p.seat,q.seat,x);targetEffect=true;}
  if(attackCode==='C048'){if(q.deck.length){const id=q.deck.shift();q.discard.push(id);notifyCreatureDiscard(r,q,[id],'CARD_EFFECT');}targetEffect=true;}
  if(attackCode==='C057'){if(q.hand.length){const id=take(q.hand,q.hand[random(q.hand.length)]);q.discard.push(id);notifyCreatureDiscard(r,q,[id],'CARD_EFFECT');}targetEffect=true;}
  if(attackCode==='C068'){q.nextExplorePenalty=true;targetEffect=true;}
  if(attackCode==='C141'&&q.support.length){const chosen=interruptChoice(r,{kind:'FORMATION_SWAP',target:q.seat,sourceId:physicalSource,required:true},p.seat,q.support,1)[0];need(chosen,'入れ替えるSUPPORTを選択');swapMainPhysical(r,q,chosen);targetEffect=true;}
  if(attackCode==='C144'&&q.hand.length){const revealed=shuffle(q.hand).slice(0,2);const chosen=interruptChoice(r,{kind:'REVEALED_DISCARD',target:q.seat,sourceId:physicalSource,required:true},p.seat,revealed,1)[0];need(chosen,'公開された手札から1枚選択');q.discard.push(take(q.hand,chosen));notifyCreatureDiscard(r,q,[chosen],'CARD_EFFECT');targetEffect=true;}
  if(attackCode==='I27'&&q.hand.length)q.discard.push(take(q.hand,q.hand[random(q.hand.length)]));
 }

 if(targetEffect){}
 else if(/MAIN能力をこのターン無効にする/.test(desc)){q.mainAbilityDisabled=true;log(r,`${p.name} C183 MAIN：${q.name}のMAIN能力をこのターン無効化`);}
 const status=desc.match(/(POISON|STUN|SLEEP|FEAR|PARASITE)にする/);
 if(a.pushback){need(q.returning&&q.level===a.pushback.fromLevel&&q.level<7,'押し戻し対象の状態が変わりました');q.level++;log(r,`${p.name} のRETURN押し戻し成功：${q.name} L${q.level-1}→L${q.level}`);}
 else if(targetEffect){}
 else if(status){if(!statusOnlyBlocked&&!q.status.includes(status[1])){
  if(!statusChecked&&preventIncomingStatus(r,q,status[1],responseWasActive)){
   log(r,`${q.name}は防御能力により${status[1]}を受けなかった`);
  }else{
   newlyAppliedParasite=status[1]==='PARASITE';q.status.push(status[1]);if(status[1]==='PARASITE'&&!hadParasiteBefore&&(!p.mainAbilityDisabled||a.handCopy)&&!p.status.some(st=>['SLEEP','STUN'].includes(st)))for(const sid of p.support)if(meta(sid).id==='C169'&&!p.disabledSupportIds?.includes(sid))fireLifecycleAbility(r,p,sid,'SUPPORT',{drawCount:1});emitGameEvent(r,{type:'STATUS_APPLIED',seat:a.seat,target:a.target,status:status[1]});queueStatusReceivedReactions(r,q,statusReactionEligible);
  }
 }log(r,`${p.name}の妨害成功：${q.name}への${status[1]}処理完了（現在${q.status.includes(status[1])?'付与中':'未付与'}）`);}
 else if(/(?:合計)?POWERを[-−－][１２12]/.test(desc)){
  const matched=desc.match(/(?:合計)?POWERを[-−－]([１２12])/);
  const penalty=Number(matched[1].replace('１','1').replace('２','2'));
  if(applyInterferencePowerLoss(r,p,q,penalty)){didPowerDrop=true;log(r,`${p.name}の妨害成功：${q.name}の合計POWER -${penalty}（このターン）`);}
 }
 else if((['C044','C080','C141','C144','C054'].includes(attackCode)||supportDisableMainSource(r,p,desc))&&/SUPPORT能力1つをこのターン無効にする/.test(desc)){
  const candidates=q.support.filter(id=>!q.disabledSupportIds?.includes(id)&&!!meta(id)?.support);
  if(candidates.length)queueSupportDisable(r,{owner:p.seat,target:q.seat,source:physicalSource,candidates,...(a.handCopy?{handCopy:true,code:attackCode}:{})});
  log(r,`${p.name} ${supportDisableMainSource(r,p,desc)} MAIN：妨害成功、相手のSUPPORT無効化対象を選択${candidates.length?'':'（有効対象なし）'}`);
 }
 else if(!/MAIN能力をこのターン無効にする/.test(desc)){log(r,`${p.name}の妨害成功判定：特殊効果は未対応。結果は変更しない`);}
 const parasiteReached=newlyAppliedParasite||q.status.includes('PARASITE');
 if(attackCode==='C136'&&desc===String(C.C136.main)&&parasiteReached&&applyInterferencePowerLoss(r,p,q,1))didPowerDrop=true;
 applyInterferenceResponsePower(r,q,false,responseWasActive,didPowerDrop);
 // S13 SUPPORT: after a successful interference against this player's MAIN,
 // draw one then choose one card to discard; never trigger on blocked attacks.
 if(s13Eligible){
  commitAbilityUse(r,q.seat,s13,'SUPPORT');
  r.effectQueue??=[];
  r.effectQueue.push({owner:q.seat,id:s13,draw:1,discard:1});
  processEffectQueue(r);
 }
 // C187 SUPPORT: after interference succeeds against MAIN, reduce attacker POWER.
 for(const id of q.support||[]){
  if(meta(id)?.id!=='C187'||!responseWasActive||!abilityAvailable(r,q.seat,id,'SUPPORT'))continue;
  commitAbilityUse(r,q.seat,id,'SUPPORT');
  applyInterferencePowerLoss(r,q,p,1);
  log(r,`${q.name} C187 SUPPORT：妨害成功後、攻撃者のPOWER -1`);
 }
 // C183 SUPPORT: defender selects an attacking SUPPORT to suppress.
 for(const id of q.support||[]){
  if(meta(id)?.id!=='C183'||!responseWasActive||!abilityAvailable(r,q.seat,id,'SUPPORT'))continue;
  const candidates=(p.support||[]).filter(x=>!p.disabledSupportIds?.includes(x)&&!!meta(x)?.support);
  if(!candidates.length)continue;
  commitAbilityUse(r,q.seat,id,'SUPPORT');
  queueSupportDisable(r,{owner:q.seat,target:p.seat,source:id,candidates});
  break;
 }
 const cleanse=mainProfile(r,q,['C130'],responseWasActive);if(cleanse&&q.status.length&&abilityAvailable(r,q.seat,q.main,cleanse.slot))r.statusCleansePending={owner:q.seat,source:q.main,statuses:[...q.status],code:cleanse.code,slot:cleanse.slot};
 queueDefenderMainReaction(r,q,false,responseWasActive);
 if(a.c055Secondary)return;
 // Post-success abilities use the printed MAIN and the resolved target state.
 const borrowedSuccess=activeCopiedProfileCode(r,p);
 const attackMain=!p.mainAbilityDisabled&&!p.status.some(st=>['SLEEP','STUN'].includes(st))?(borrowedSuccess||p.main&&meta(p.main)?.id):null;
 const successSlot=borrowedSuccess?'COPY_SUCCESS_'+borrowedSuccess:'MAIN';
 // Borrowed active attack text supplies its own success clause; the physical COPY
 // remains the actor and the queued discard source, never the borrowed card.
 const bound=p.mainCopy;
 const handAttack=!!a.handCopy,sourceActor=handAttack?a.sourceId:p.main,sourceEnabled=handAttack||!p.mainAbilityDisabled&&!p.status.some(st=>['SLEEP','STUN'].includes(st));
 const copiedAttack=handAttack||bound?.execution?.kind==='COPIED_ATTACK_MAIN'&&bound.turn===(r.effectTurn||0)
    &&bound.owner===r.seat&&bound.copyId===p.main&&bound.sourceText===desc;
 const successMain=a.pushback?null:handAttack?a.handCopy.code:copiedAttack?bound.execution.sourceCard.id:attackMain;
 // Printed post-PARASITE clauses use the declared native/borrowed attack.
 // Reapplication is successful without a second STATUS event (adopted B ruling).
 // A status-only prevention that leaves no PARASITE has not reached '付与後'.
 if(['C051','C085','C113','C115','C136','C167'].includes(successMain)
    &&desc===String(C[successMain].main)&&parasiteReached
    &&sourceEnabled){
  if(successMain==='C115'){if(!hadParasiteBefore)p.turnPowerBonus=(p.turnPowerBonus||0)+2;}
  else {r.effectQueue??=[];r.effectQueue.push({owner:p.seat,id:sourceActor,draw:1,discard:['C051','C085','C113'].includes(successMain)?1:0});}
  processEffectQueue(r);
 }
 // G09's own attack has a DRAW clause, not an independent ITEM-success trigger.
 // The adopted B ruling permits STATUS reapplication without a new STATUS event.
 // Queue DRAW only: respect existing mandatory choices, and do not invent DISCARD
 // or a once-per-turn limit absent from the canonical text.
 if(successMain==='G09'&&desc===String(C.G09.main)&&sourceEnabled){
  r.effectQueue??=[];
  r.effectQueue.push({owner:p.seat,id:sourceActor,draw:1,discard:0});
  processEffectQueue(r);
  log(r,`${p.name} G09${copiedAttack?' COPY':''} MAIN：妨害成功後、1枚引く`);
 }
 if(successMain==='C077'&&desc===String(C.C077.main)&&targetHadStatus
    &&sourceEnabled){
  p.turnPowerBonus=(p.turnPowerBonus||0)+1;
  log(r,`${p.name} C077${copiedAttack?' COPY':''} MAIN：使用前からSTATUS状態の対象への妨害成功後、POWER +1`);
 }
 if(successMain==='C087'&&sourceEnabled&&q.status.includes('PARASITE')){
  r.effectQueue??=[];
  r.effectQueue.push({owner:p.seat,id:sourceActor,draw:1,discard:1});
  processEffectQueue(r);
  log(r,`${p.name} C087 MAIN：PARASITE対象への妨害成功後、1枚引き1枚捨てる`);
 }
 // Printed C121 (L5 only), C147 and C175: draw then mandatory discard
 // after an unblocked successful interference. No printed once-per-turn limit.
 if(['C121','C147','C175'].includes(successMain)&&(successMain!=='C121'||p.level===5)
    &&sourceEnabled){
  r.effectQueue??=[];
  r.effectQueue.push({owner:p.seat,id:sourceActor,draw:1,discard:1});
  processEffectQueue(r);
  log(r,`${p.name} ${successMain}${copiedAttack?' COPY':''} MAIN：妨害成功後、1枚引き1枚捨てる`);
 }
 // Success clauses from the canonical source share the same effect queue.
 if(['C162','C170','C195'].includes(successMain)&&desc===String(C[successMain].main)
    &&sourceEnabled){
  if(successMain==='C195')p.turnPowerBonus=(p.turnPowerBonus||0)+2;
  r.effectQueue??=[];r.effectQueue.push({owner:p.seat,id:sourceActor,draw:1,discard:0});processEffectQueue(r);
 }
 if(attackMain)resolveSuccessProfile(r,p,q,{code:attackMain,id:p.main,slot:successSlot});
 if(a.handEvent)resolveSuccessProfile(r,p,q,{code:a.handEvent.code,id:a.handEvent.handId,slot:'HAND_EVENT_'+a.handEvent.code});
 for(const sid of p.support){if(!handAttack&&meta(sid).id==='C137'&&!p.status.some(st=>['SLEEP','STUN'].includes(st))&&!p.disabledSupportIds?.includes(sid))fireLifecycleAbility(r,p,sid,'SUPPORT',{drawCount:1,discard:q.status.includes('PARASITE')?0:1});}
 // C193 SUPPORT: after MAIN's successful interference, draw and discard;
 // if this interference newly applied PARASITE, no discard.
 for(const id of p.support||[]){
  if(handAttack||meta(id)?.id!=='C193'||p.status.includes('SLEEP')||p.status.includes('STUN')||!abilityAvailable(r,p.seat,id,'SUPPORT'))continue;
  commitAbilityUse(r,p.seat,id,'SUPPORT');
  r.effectQueue??=[];
  r.effectQueue.push({owner:p.seat,id,draw:1,discard:newlyAppliedParasite?0:1});
  processEffectQueue(r);
  log(r,`${p.name} C193 SUPPORT：妨害成功後DRAW${newlyAppliedParasite?'':'・DISCARD'}`);
 }
 // C143 SUPPORT: after successful interference against a STATUS-affected target.
 for(const id of p.support||[]){
  if(handAttack||meta(id)?.id!=='C143'||!q.status.length
      ||p.status.includes('SLEEP')||p.status.includes('STUN')
      ||!abilityAvailable(r,p.seat,id,'SUPPORT'))continue;
  commitAbilityUse(r,p.seat,id,'SUPPORT');
  r.effectQueue??=[];
  r.effectQueue.push({owner:p.seat,id,draw:1,discard:1});
  processEffectQueue(r);
  log(r,`${p.name} C143 SUPPORT：STATUS対象への妨害成功後、DRAW・DISCARD`);
 }
 // C174 MAIN: draw once when the second interference succeeds this turn.
 if(successMain==='C174'&&desc===String(C.C174.main)&&sourceEnabled){
  p.c174SuccessCounts??={};const prior=p.c174SuccessCounts[sourceActor]??(copiedAttack?0:p.c174SuccessCount||0);
  p.c174SuccessCounts[sourceActor]=prior+1;if(!copiedAttack)p.c174SuccessCount=prior+1;
  if(p.c174SuccessCounts[sourceActor]>=2&&abilityAvailable(r,p.seat,sourceActor,handAttack?'HAND_ATTACK_C174':copiedAttack?'COPY_ATTACK_C174':successSlot)){
   commitAbilityUse(r,p.seat,sourceActor,handAttack?'HAND_ATTACK_C174':copiedAttack?'COPY_ATTACK_C174':successSlot);draw(r,p,1);
   log(r,`${p.name} C174 MAIN：2回の妨害成功で1枚引く`);
  }
 }
 // These borrowed comparison attacks include an unconditional success POWER
 // clause. Read their resolved attack text, while retaining original MAIN
 // triggers for all other sources and using the COPY actor's actual POWER.
 const actualMainText=String((borrowedSuccess?C[borrowedSuccess]:meta(p.main))?.main||'');
 if(handAttack&&['C172','C197'].includes(successMain)){const amount=Number(desc.match(/成功後、このターン合計POWERを\+(\d+)/)?.[1]||0);p.turnPowerBonus=(p.turnPowerBonus||0)+amount;}
 const src=successEventCodes.has(attackMain)?'':handAttack||a.pushback?(/妨害：/.test(actualMainText)?'':actualMainText):copiedAttack&&['C172','C197'].includes(successMain)?desc:actualMainText;let bonus=0;
 const normal=src.match(/成功後、このターン合計POWERを\+(\d+)/);if(normal)bonus=Number(normal[1]);
 const alt=src.match(/対象がSTATUS状態なら、代わりに合計POWERを\+(\d+)/);if(alt&&q.status.length)bonus=Number(alt[1]);
 if(bonus&&!p.mainAbilityDisabled&&!p.status.includes('SLEEP')&&!p.status.includes('STUN')){p.turnPowerBonus=(p.turnPowerBonus||0)+bonus;log(r,`${p.name} のMAIN能力：妨害成功後、このターン合計POWER +${bonus}`);}
 if(attackCode==='C055'&&newlyAppliedParasite&&!a.pushback)resolveC055Spread(r,a);
}
const successEventCodes=new Set(['C133',...batchASuccessProfiles]);
const handCostEventCodes=new Set(['C063','C135','C108','S10','G12']);
function resolveSuccessProfile(r,p,q,{code,id,slot}){
 if(!successEventCodes.has(code))return;
 const same=p.level===q.level,status=q.status.length>0;
 if(['C057','C068','C119','C139'].includes(code)&&!same)return;
 if(['C060','C091','C106','C148'].includes(code)&&!status)return;
 // The printed condition is actual total POWER, independent of the attack's text.
 if(code==='C165'&&!(window.Bot?.power(p)>window.Bot?.power(q)))return;
 const drawCount=['C098','C143','C148'].includes(code)?0:1;
 const discard=['C048','C057','C165'].includes(code)||code==='C133'&&!hasSupportSpecies(p,'胞子種')?1:0;
 const power=code==='C119'?(status?2:1):code==='C143'?(status?2:1):['C068','C098','C106','C148'].includes(code)?1:0;
 const limited=['C048','C133','C106','C139'].includes(code);
 if(limited&&!abilityAvailable(r,p.seat,id,slot))return;
 fireLifecycleAbility(r,p,id,slot,{drawCount,discard,power,limited});
 processEffectQueue(r);
 if(code==='C139'&&hasSupportSpecies(p,'獣種'))applyInterferencePowerLoss(r,p,q,1);
}
function hasSupportSpecies(p,sp){return (p.support||[]).some(id=>{const kinds=window.Bot?.effectiveSpecies?.(p,id);return kinds?kinds.has(sp):meta(id)?.species===sp;});}
function resolveStatusRemovedTriggers(r,p){
 // Trigger only after an actual STATUS was removed. C182 MAIN is not limited
 // to once per turn; C182 SUPPORT and C192 SUPPORT are each once per turn.
 const eligible=id=>!!id&&!p.status.includes('SLEEP')&&!p.status.includes('STUN')&&abilityAvailable(r,p.seat,id,id===p.main?'MAIN':'SUPPORT');
 if(meta(p.main)?.id==='C182'&&eligible(p.main)){
  p.turnPowerBonus=(p.turnPowerBonus||0)+1;
  log(r,`${p.name} C182 MAIN：STATUS解除後、POWER +1`);
 }
 if(activeCopiedProfileCode(r,p)==='C182'){
  p.turnPowerBonus=(p.turnPowerBonus||0)+1;
  log(r,`${p.name} C182 COPY MAIN：STATUS解除後、POWER +1`);
 }
 for(const id of p.support||[]){
  const cid=meta(id)?.id;
  if(!['C182','C192'].includes(cid)||!eligible(id))continue;
  commitAbilityUse(r,p.seat,id,'SUPPORT');
  if(cid==='C182'){
   p.turnCaptureBonus=(p.turnCaptureBonus||0)+1;
   log(r,`${p.name} C182 SUPPORT：STATUS解除後、捕獲力 +1`);
  }else{
   r.effectQueue??=[];
   r.effectQueue.push({owner:p.seat,id,draw:1,discard:0});
   processEffectQueue(r);
   log(r,`${p.name} C192 SUPPORT：STATUS解除後、1枚引く`);
  }
 }
}

function recordTransfer(r,from,to,id){r.cardOwners??={};r.cardOwners[id]=to;r.transferLog??=[];r.transferLog.push({id,from,to,turn:r.effectTurn||0});}
function setMainPhysical(r,p,id){const tracked=r.physicalStatus&&(Object.hasOwn(r.physicalStatus,p.main)||Object.hasOwn(r.physicalStatus,id));if(tracked){if(p.main)r.physicalStatus[p.main]=[...p.status];p.status=[...(r.physicalStatus[id]||[])];}p.main=id;}
function swapMainPhysical(r,p,id){need(p.support.includes(id),'SUPPORTが必要');const old=p.main;r.physicalStatus??={};r.physicalStatus[old]=[...p.status];p.support[p.support.indexOf(id)]=old;setMainPhysical(r,p,id);p.mainCopy=null;p.mainAbilityDisabled=false;log(r,`${p.name} MAIN/SUPPORTを入替（STATUSはカードに付随）`);}
function revisedItemHand(r,p,source){
 if(p.actedHand||r.seat!==p.seat||r.phase!=='ACTIONS')return;
 const candidates=p.hand.filter(id=>['C067','C140'].includes(cardId(id)));if(!candidates.length)return;
 const id=interruptChoice(r,{kind:'ITEM_HAND',sourceId:source},p.seat,candidates,1)[0];if(!id)return;
 p.discard.push(take(p.hand,id));p.actedHand=true;
 if(cardId(id)==='C067')draw(r,p,1);
 else {const options=p.discard.filter(creature);const chosen=interruptChoice(r,{kind:'RECYCLE_BOTTOM',sourceId:id,required:true},p.seat,options,1)[0];need(chosen,'捨て札CREATUREを選択');p.deck.push(take(p.discard,chosen));}
}

function useItemDirect(r,p,id,a,handEvent=null){const card=meta(id),c=card.id,target=a.target??p.seat;
 if(c==='I28'&&a.mode!=='stray'&&a.target===undefined&&r.explore?.owner===p.seat){need(r.explore.source==='wild','通常探索後のみ');const ids=a.redrawIds||[];need(ids.length<=2&&new Set(ids).size===ids.length&&ids.every(x=>r.explore.ids.includes(x)),'引き直し対象は最大2枚');take(p.hand,id);r.removedItems.push(id);p.usedItemThisTurn=true;for(const x of ids){take(r.explore.ids,x);r.wild[String(r.explore.level)].push(x);}r.explore.ids.push(...wildDraw(r,r.explore.level,ids.length));return;}
 need(itemStandalone.has(c),`${c}はこの画面から使用不可。専用の探索・捕獲・META・REACTION画面を使うか、未対応です`);
 need(card.timing==='FREE'||card.timing==='EQUIP','このタイミングでは使用不可');
 need(r.seat===p.seat&&['START','ACTIONS'].includes(r.phase),'自分の手番以外は使えません');
 const hand=items=>{need(Array.isArray(items)&&new Set(items).size===items.length,'対象カードの重複');need(items.every(x=>p.hand.includes(x)&&x!==id),'対象は手札から');return items;};
 if(['SI04','I16'].includes(c)){need(p.status.includes(a.status),'解除対象のSTATUSがありません');}
 if(['I27','I28','I29','I30','I31'].includes(c)){
  need(Number.isInteger(target)&&target>=0&&target<4&&target!==p.seat,'対象プレイヤーを選択');
  const q=r.players[target];need(q.level===p.level,'同LEVELの相手が必要');
  if(c==='I28')need(q.stray.length>0,'対象の遊動個体が必要');
  if(c==='I29')need(q.support.some(id=>!q.disabledSupportIds?.includes(id)&&!!meta(id)?.support),'有効なSUPPORT能力が必要');
  
 }
 if(['I37','I40'].includes(c)){need(Number.isInteger(target)&&r.players[target]&&target!==p.seat,'他プレイヤーを選択');if(c==='I37')hand([a.card]);}
 if(c==='I07')need(r.explore?.owner===p.seat,'採取ドローンは探索後のみ使用可能');
 if(c==='I32'){need(hand(a.pay||[]).length<=2,'2枚まで捨てられます');}
 if(c==='I33'){need(!a.toBottom||Array.isArray(a.toBottom),'山札へ戻す指定が不正');}
 if(c==='I36'){need(hand([a.card]).length===1,'手札から対象を1枚選択');}
 if(c==='I35'){need(r.removedItems.includes(a.card)&&['SUPPLY','START ITEM'].includes(type(a.card))&&r.usedItemOwners?.[a.card]===p.seat,'自分が使用して除外したITEMを選択（使用者の記録が必要）');}
 if(card.timing==='EQUIP')need(p.main,'装備するMAINが必要');
 take(p.hand,id);if(card.timing==='EQUIP')p.equip.push(id);else r.removedItems.push(id);p.usedItemThisTurn=true;
 if(['SI04','I16'].includes(c)){const before=p.status.length;p.status=p.status.filter(x=>x!==a.status);if(p.status.length<before){emitGameEvent(r,{type:'STATUS_REMOVED',seat:p.seat,target:p.seat,status:a.status,action:'ITEM'});resolveStatusRemovedTriggers(r,p);}}
 else if(c==='I07'){draw(r,p,1);r.effectPending={owner:p.seat,source:id};}
 else if(['I28','I29'].includes(c)){resolveIncomingAttack(r,{seat:p.seat,target,text:'妨害：'+card.effect,itemCode:c,sourceId:id,...(handEvent?{handEvent}:{})});}
 else if(c==='I27'){resolveIncomingAttack(r,{seat:p.seat,target,itemCode:c,sourceId:id,text:'妨害：相手MAINをSTUNにする。手札をランダムに1枚捨てさせる。',...(handEvent?{handEvent}:{})});}
 else if(c==='I30'){resolveIncomingAttack(r,{seat:p.seat,target,text:'妨害：'+String(meta(id).effect),...(handEvent?{handEvent}:{})});}
 else if(c==='I31'){resolveIncomingAttack(r,{seat:p.seat,target,text:'妨害：同じLEVELの相手の合計POWERを-2する。このターン中。',...(handEvent?{handEvent}:{})});}
 else if(c==='I37'){const x=take(p.hand,a.card);r.players[target].hand.push(x);recordTransfer(r,p.seat,target,x);draw(r,p,3);}
 else if(c==='I40'){draw(r,p,2);draw(r,r.players[target],2);}
 else if(c==='I32'){for(const x of a.pay||[])p.discard.push(take(p.hand,x));draw(r,p,(a.pay||[]).length);queueDiscardTriggers(r,p,a.pay||[],'ITEM');}
 else if(c==='I34'){const seen=[];for(let i=0;i<3&&p.deck.length;i++)seen.push(p.deck.shift());let order=a.order;
  if(order===undefined)order=seen.length?interruptChoice(r,{kind:'ORDER',source:id},p.seat,seen,seen.length):[];
  need(Array.isArray(order)&&order.length===seen.length&&new Set(order).size===seen.length&&order.every(x=>seen.includes(x)),'整理ケースの戻す順が不正');p.deck=[...order,...p.deck];draw(r,p,1);}
 else if(c==='I35'){const x=take(r.removedItems,a.card);p.hand.push(x);}
 else if(c==='I36'){const x=take(p.hand,a.card);if(creature(x))cycle(r,x);else r.removedItems.push(x);draw(r,p,1);}
 else if(c==='I33'){draw(r,p,2);const back=(a.toBottom||[])[0]||p.hand[p.hand.length-1];need(back&&p.hand.includes(back),'山札へ戻す1枚が必要');p.deck.push(take(p.hand,back));}
 log(r,`${p.name}が${card.name}を使用：${c}の専用処理を実行`);
}
// Source capability is a conservative preflight, not copied-effect execution.
// The v2.0 master forbids copying another COPY ability and requires the
// original ability's cost, timing and per-turn limit.
// Conservative execution classification: only unconditional numeric MAIN POWER
// may be considered for the first COPY executor. All other text stays gated.
function classifyCopySourceMain(text,sourceCard=null){
 const raw=String(text||'').replace(/^MAIN[｜:：]\s*/,'').trim();
 if(/COPY|コピー|擬態|写し/.test(raw))return {kind:'FORBIDDEN_COPY',supported:false};
 if(sourceCard&&['C048','C057','C068'].includes(sourceCard.id))return {kind:'COPIED_ATTACK_MAIN',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard?.id==='C012')return {kind:'COPIED_PROFILE',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&batchBProfiles.has(sourceCard.id))return {kind:'COPIED_PROFILE',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&['C051','C085','C113','C115','C136','C167','C174','C055'].includes(sourceCard.id))return {kind:'COPIED_ATTACK_MAIN',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&batchBTargetAttacks.has(sourceCard.id))return {kind:'COPIED_ATTACK_MAIN',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&batchASuccessProfiles.has(sourceCard.id))return {kind:'COPIED_PROFILE',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&batchAAttacks.has(sourceCard.id))return {kind:'COPIED_ATTACK_MAIN',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&redrawMains.has(sourceCard.id))return {kind:'COPIED_PROFILE',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&['S08','C005','C182','C074','C124','C176','S12','C011','C048','C133'].includes(sourceCard.id))return {kind:'COPIED_PROFILE',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&['S04','C103','S14','C067','C140'].includes(sourceCard.id))return {kind:'COPIED_PROFILE',supported:false,amount:2,sourceCard:{...sourceCard}};
 if(sourceCard&&['C006','C066','C153'].includes(sourceCard.id))return {kind:'COPIED_PROFILE',supported:false,amount:2,sourceCard:{...sourceCard}};
 if(sourceCard&&['C013','C017','C019','C027','C042','C059','C084','C129','C132','C163'].includes(sourceCard.id))return {kind:'COPIED_PROFILE',supported:false,amount:2,sourceCard:{...sourceCard}};
if(sourceCard&&['S11','C043','C008','C052','C061','C070','C183','C046','C047','C064','C071','C082','C146','C166','C087','C121','C147','C175','C172','C197','C077','C199','C044','C080','C141','C144','C054','G01','G07','G09'].includes(sourceCard.id))return {kind:'COPIED_ATTACK_MAIN',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&['C063','C135','C108','S10','G12'].includes(sourceCard.id))return {kind:'COPIED_COST_MAIN',supported:false,sourceCard:{...sourceCard}};
 if(sourceCard&&['C123','C160','C168','C193','C137','C169','C033','C128','C164','C180','C185','C191','C004','C018','C022','C028','C034','C094','C007','C026','C021','C192','C110','G03','G08','G11','G13','G17','G21','G25','G16','G26','G28','G02','G18','G22','G05','G10','C038','C188','C127','C049','C056','C179','S03','C126','C187','C198','C090','C099','C178','C003','C020','C023','C041','C050','C096','C102','C111','C131','C145','C155','C190'].includes(sourceCard.id))return {kind:'COPIED_PROFILE',supported:false,amount:2,sourceCard:{...sourceCard}};
 // Classify genuine card texts without granting permission to execute COPY.
 // A named prefix is allowed only when the remaining effect is unconditional.
 const normalized=raw.replace(/^[^：。]+：(?=(?:捕獲力|合計POWER|探索時))/,'');
 let match=normalized.match(/^捕獲力を\+([1-9][0-9]*)する。?$/);
 if(match)return {kind:'STATIC_CAPTURE',supported:false,amount:Number(match[1]),reason:'捕獲判定へのCOPY接続は未実装'};
 match=normalized.match(/^合計POWERを\+([1-9][0-9]*)する。?$/);
 if(match)return {kind:'STATIC_POWER',supported:true,amount:Number(match[1]),reason:'分類上対応可能。COPY実行は未接続'};
 if(/^探索時、追加で([1-9][0-9]*)枚見る。?$/.test(normalized)){
  match=normalized.match(/追加で([1-9][0-9]*)枚/);
  return {kind:'EXTRA_EXPLORE',supported:false,amount:Number(match[1]),reason:'探索タイミングへのCOPY接続は未実装'};
 }
 return {kind:'UNSUPPORTED_CONTEXT',supported:false};
}

// Ownership and zone check only; copied effect execution remains disabled.
function handAttackRecord(r,seat,source=null,code=null,target=null){const p=r.players[seat],b=p?.handAttack;
 return b&&b.owner===seat&&b.turn===(r.effectTurn||0)&&p.actedHand&&(!source||b.handId===source)&&(!code||b.code===code)&&(target===null||b.target===target)?b:null;
}
function handCostPowerBonus(r,p){if(!p.main||p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st)))return 0;
 if(['C063','C135'].includes(cardId(p.main))&&abilityAvailable(r,p.seat,p.main,'MAIN'))return 1;
 const b=copiedCostMain(r,p);return b&&['C063','C135'].includes(b.code)&&abilityAvailable(r,p.seat,p.main,b.slot)?1:0;
}
function handAttackTargets(r,seat,handId,sourceId){
 const p=r.players[seat];if(!p||!p.main||r.explore||r.actionPoints<1)return [];
 const pre=copyActivationPreflight(r,seat,handId,sourceId,'HAND');if(!pre.ok||pre.execution?.kind!=='COPIED_ATTACK_MAIN')return [];
 const text=pre.sourceText,code=pre.sourceCardId;
 const trial={...p,creatureDiscardTurn:r.effectTurn||0,turnPowerBonus:(p.turnPowerBonus||0)+handCostPowerBonus(r,p)};
 const contextReady=q=>{if(['C048','C057','C068','C144'].includes(code)&&q.level!==p.level)return false;if(code==='C141'&&Object.values(q.guardian).some(g=>g.pending))return false;if(code==='C045')return q.level===p.level&&p.stray.length>0;if(code==='C065')return q.hand.length>0;if(['C072','C044','C080','C141','C054'].includes(code)&&!q.support.length)return false;if(['C125','C162'].includes(code)&&!q.status.length)return false;if(['C170','C195'].includes(code)&&q.level!==p.level)return false;return code!=='C054'||q.status.includes('PARASITE');};
 return r.players.filter(q=>q.seat!==seat&&q.main&&contextReady(q)&&(q.level===p.level||p.returning!==q.returning&&Math.abs(q.level-p.level)===1)&&(!/(?:自分より|相手より)(?:合計)?POWER/.test(text)||interferenceAttackPower(r,seat,q.seat,text,'HAND',trial)>interferenceDefensePower(r,q.seat)));
}
function handAttackOptions(r,seat,handId=null){const p=r.players?.[seat];if(!p)return [];const out=[];
 for(const id of handId?[handId]:p.hand.filter(id=>['C079','C154','C181'].includes(cardId(id))))for(const source of copyTargetCandidates(r,seat,cardId(id),'HAND')){const targets=handAttackTargets(r,seat,id,source.physicalId);if(targets.length)out.push({handId:id,sourceId:source.physicalId,code:source.cardId,targets:targets.map(q=>q.seat)});}return out;
}
function verifyHandAttacks(r){for(const p of r.players){const b=p.handAttack;if(!b)continue;
 need(b.owner===p.seat&&b.turn===(r.effectTurn||0)&&p.actedHand===true&&['C079','C154','C181'].includes(cardId(b.handId))&&cardId(b.sourceId)===b.code&&b.sourceText===String(C[b.code]?.main)&&(classifyCopySourceMain(b.sourceText,C[b.code]).kind==='COPIED_ATTACK_MAIN'||b.code==='C012'&&classifyCopySourceMain(b.sourceText,C[b.code]).kind==='COPIED_PROFILE')&&Number.isInteger(b.target)&&r.players[b.target]&&b.target!==p.seat,'HAND妨害の保存記録が不正');
 }
 if(r.pendingAttack?.handCopy){const a=r.pendingAttack,b=handAttackRecord(r,a.seat,a.sourceId,a.sourceCode,a.target);need(b&&JSON.stringify(b)===JSON.stringify(a.handCopy)&&a.text===interferenceResolvedText(b.sourceText,{status:a.targetHadStatus?['STATUS']:[]}),'HAND妨害のREACTION保存状態が不正');}
}
function handCheckPlayer(p,record){return record?.code==='C186'&&p.support?.length===2?{...p,handCopyCheck:{code:'C186',handId:record.handId}}:p;}
function handPowerAmount(r,p,execution){if(execution?.kind==='STATIC_POWER')return execution.amount;if(execution?.kind!=='COPIED_PROFILE')return 0;if(execution.sourceCard.id==='C186')return p.support.length===2?2:0;return window.Bot?.copiedMainPower?.(p,execution.sourceCard,true)||0;}
function handPowerOptions(r,seat){const p=r.players[seat];if(!p?.main||r.explore)return [];const out=[];
 for(const handId of p.hand.filter(id=>['C079','C154','C181'].includes(cardId(id))))for(const x of copyTargetCandidates(r,seat,cardId(handId),'HAND')){const pre=copyActivationPreflight(r,seat,handId,x.physicalId,'HAND');if(!pre.ok)continue;const trial=handCheckPlayer({...p,hand:p.hand.filter(id=>id!==handId),creatureDiscardTurn:r.effectTurn||0,turnPowerBonus:(p.turnPowerBonus||0)+handCostPowerBonus(r,p)},{code:x.cardId,handId}),amount=handPowerAmount(r,trial,pre.execution);if(amount>0)out.push({handId,sourceId:x.physicalId,code:x.cardId,amount,costPowerBonus:handCostPowerBonus(r,p)});}return out;
}
function handPowerAttackOptions(r,seat){const p=r.players[seat],text=mainAbilityText(r,p);if(!/(?:自分より|相手より)(?:合計)?POWER/.test(text))return [];return handPowerOptions(r,seat).map(o=>{const trial=handCheckPlayer({...p,hand:p.hand.filter(id=>id!==o.handId),creatureDiscardTurn:r.effectTurn||0,turnPowerBonus:(p.turnPowerBonus||0)+o.costPowerBonus},o),room={...r,players:r.players.map(q=>q.seat===seat?trial:q)};return {...o,targets:interferenceTargets(room,seat,text,o.amount).map(q=>q.seat)};}).filter(o=>o.targets.length);}
function handPowerPushbackOptions(r,seat){const p=r.players[seat];if(r.mode!=='RETURN'||r.actionPoints<2)return [];return handPowerAttackOptions(r,seat).map(o=>({...o,targets:o.targets.filter(s=>r.players[s].returning&&r.players[s].level>=1&&r.players[s].level<7)})).filter(o=>o.targets.length&&p.hand.some(id=>id!==o.handId&&creature(id)));}
function payHandPower(r,p,a){need(a.copyHandId!==undefined&&a.copySourceId!==undefined,'HAND POWER COPYのカードと元能力が必要');const option=handPowerOptions(r,p.seat).find(o=>o.handId===a.copyHandId&&o.sourceId===a.copySourceId);need(option,'合法なHAND POWER COPYを選択してください');const pre=copySourcePreflight(r,p.seat,cardId(option.handId),option.sourceId,'HAND'),old={main:p.main,support:[...p.support],level:p.level};p.discard.push(take(p.hand,option.handId));p.actedHand=true;resolveCreatureCostTriggers(r,p,[option.handId],old,a.type);const amount=handPowerAmount(r,p,pre.execution);need(amount>0,'HAND POWER条件が成立していません');const record={owner:p.seat,handId:option.handId,sourceId:option.sourceId,code:option.code,sourceText:pre.sourceText,amount,turn:r.effectTurn||0};log(r,`${p.name} HAND COPY：このPOWER判定に+${amount}`);return record;}
function countedActionType(a){if(a.type==='explore_resolve')return 'explore';if(['hand_copy_attack','pushback'].includes(a.type))return 'interfere';return ['buy','move','main_status_cleanse','main_hand_cycle','hand_copy_action','interfere','guardian_challenge'].includes(a.type)?a.type:null;}
function handEventReplyAllowed(r,seat,a){return a.type==='resolve_effect'&&r.effectPending?.owner===seat||a.type==='field_discard'&&r.fieldDiscardPending?.owner===seat||a.type==='target_effect_reply'&&r.targetEffectPending?.owner===seat&&r.targetEffectPending.mode==='HAND_DISCARD';}
function eventDiscardIds(r,seat,a){if(a.type==='buy'||a.type==='use_item'&&cardId(a.id)==='I32')return a.pay||[];if(['main_hand_cycle','resolve_effect','field_discard'].includes(a.type))return [a.id];if(a.type==='target_effect_reply'&&r.targetEffectPending?.mode==='HAND_DISCARD')return [a.choice];return [];}
function handEventOptions(r,seat,a){const p=r.players[seat];if(!p||r.explore&&a.type!=='explore_resolve'||!['buy','use_item','main_status_cleanse','interfere','pushback','explore_resolve','guardian_challenge','main_hand_cycle','move','resolve_effect','field_discard','target_effect_reply','main_draw_cycle'].includes(a.type)||a.copyHandId!==undefined||a.copySourceId!==undefined)return [];const out=[];
 for(const handId of p.hand.filter(id=>['C079','C154','C181'].includes(cardId(id)))){if((a.pay||[]).includes(handId)||a.card===handId||a.id===handId)continue;for(const x of copyTargetCandidates(r,seat,cardId(handId),'HAND')){const pre=copyActivationPreflight(r,seat,handId,x.physicalId,'HAND',handEventReplyAllowed(r,seat,a));if(!pre.ok)continue;const code=x.cardId;
 const clean=a.type==='main_status_cleanse'||a.type==='use_item'&&['SI04','I16'].includes(cardId(a.id));const success=a.type==='interfere'||a.type==='pushback'||a.type==='use_item'&&['I27','I28','I29','I30','I31'].includes(cardId(a.id));const cost=(a.type==='buy'||a.type==='use_item'&&cardId(a.id)==='I32')&&(a.pay||[]).some(id=>creature(id)&&id!==handId);const discards=eventDiscardIds(r,seat,a).filter(id=>id!==handId),actionType=countedActionType(a);const capture=a.method==='CAPTURE'&&(a.type==='explore_resolve'&&r.explore?.owner===seat||a.type==='guardian_challenge')&&meta(a.type==='guardian_challenge'?p.guardian[String(p.level)]?.id:a.id)?.species==='樹種';const extra=code==='C186'&&a.type==='main_draw_cycle'&&!mainDrawCycleProfile(r,p)?.available&&mainDrawCycleProfile(r,handCheckPlayer(p,{code,handId}))?.available||code==='C009'&&discards.some(id=>creature(id))||code==='C100'&&p.level===5&&discards.length>0||code==='C036'&&capture||code==='C074'&&a.type==='explore_resolve'&&r.explore?.owner===seat||code==='C184'&&actionType&&(p.actionCounts?.[actionType]||0)===1;const eligible=extra||success&&successEventCodes.has(code)||cost&&handCostEventCodes.has(code)||a.type==='buy'&&['S04','C103'].includes(code)||a.type==='use_item'&&['S14','C067','C140'].includes(code)||clean&&code==='C182'&&p.status.includes(a.status);if(eligible)out.push({handId,sourceId:x.physicalId,code});}}
 return out;
}
function prepareHandEvent(r,seat,a,before){if(a.eventCopy===undefined||a.eventCopy===null)return;need(a.eventCopy&&typeof a.eventCopy==='object'&&!Array.isArray(a.eventCopy),'HANDイベントCOPYの指定が不正');const p=r.players[seat],o=handEventOptions(r,seat,a).find(o=>o.handId===a.eventCopy.handId&&o.sourceId===a.eventCopy.sourceId);need(o,'この行動に合法なHANDイベントCOPYがありません');const old={main:p.main,support:[...p.support],level:p.level};p.discard.push(take(p.hand,o.handId));p.actedHand=true;resolveCreatureCostTriggers(r,p,[o.handId],old,a.type);before.handEvent={...o,owner:seat,turn:r.effectTurn||0,sourceText:String(C[o.code].main)};}
function resolveHandEvent(r,seat,a,before){const o=before.handEvent;if(!o)return;if(successEventCodes.has(o.code)||handCostEventCodes.has(o.code)||o.code==='C186')return;const p=r.players[seat];let valid=false;
 if(['S04','C103'].includes(o.code))valid=a.type==='buy';
 else if(['S14','C067','C140'].includes(o.code))valid=a.type==='use_item'&&(r.removedItems.includes(a.id)||p.equip.includes(a.id));
 else if(o.code==='C182')valid=before.players[seat].status.some(st=>!p.status.includes(st));
 else if(['C009','C100'].includes(o.code))valid=true;
 else if(o.code==='C036')valid=a.type==='explore_resolve'?a.method==='CAPTURE'&&!r.explore:p.guardian[String(before.players[seat].level)]?.status==='captured';
 else if(o.code==='C074')valid=before.explore&&!r.explore;
 else if(o.code==='C184')valid=p.actionCounts?.[countedActionType(a)]===2;
 if(o.code==='C036'&&!valid)return;need(valid,'コピーしたイベントが成立していません');fireLifecycleAbility(r,p,o.handId,'HAND_EVENT_'+o.code,{drawCount:o.code==='C182'?0:1,discard:['C036','C074'].includes(o.code)||['S04','C103','S14','C067','C140'].includes(o.code)?1:0,power:o.code==='C182'?1:0});
}
const handActionCodes=new Set(['S08','C005','S12','C011','C031','C032','C088','C012']);
function handCopyActionOptions(r,seat,handId){
 const p=r.players?.[seat];if(!p||r.explore)return [];
 return copyTargetCandidates(r,seat,cardId(handId),'HAND').filter(x=>{
  const pre=copyActivationPreflight(r,seat,handId,x.physicalId,'HAND');if(!pre.ok||!handActionCodes.has(pre.sourceCardId))return false;
  const code=pre.sourceCardId;
  if(code==='S08')return r.actionPoints>0&&(p.status.length>0||p.hand.some(id=>id!==handId));
  if(code==='C012')return r.actionPoints>0&&p.hand.some(id=>id!==handId&&creature(id))&&r.players.some(q=>q.seat!==seat&&q.level===p.level);
  if(code==='C005')return r.actionPoints>0&&p.status.length>0;
  if(['S12','C011'].includes(code))return r.actionPoints>0&&p.hand.some(id=>id!==handId);
  return hasSupportSpecies(p,{C031:'樹種',C032:'胞子種',C088:'水棲種'}[code]);
 }).map(x=>({sourceId:x.physicalId,code:x.cardId,cost:['S08','C005','S12','C011','C012'].includes(x.cardId)?1:0}));
}
function copyActivationPreflight(r,seat,copyPhysicalId,sourceId,mode="MAIN",eventReply=false){
 const p=r.players?.[seat];
 if(!p)return {ok:false,reason:'プレイヤーが存在しません'};
 if(!['MAIN','HAND'].includes(mode))return {ok:false,reason:'COPY使用欄が不正'};
 if(!copyPhysicalId||!P[copyPhysicalId])return {ok:false,reason:'COPYカードが存在しません'};
 const cid=cardId(copyPhysicalId);
 if(!['C079','C122','C149','C154','C181'].includes(cid))return {ok:false,reason:'COPY能力のないカード'};
 if(mode==='MAIN'){
  if(p.main!==copyPhysicalId)return {ok:false,reason:'COPYカードがMAINにいません'};
  if(p.mainAbilityDisabled)return {ok:false,reason:'MAIN能力は無効化されています'};
  if(p.status?.includes('SLEEP')||p.status?.includes('STUN'))return {ok:false,reason:'MAIN能力を使用できないSTATUSです'};
 }
 if(mode==='HAND'){
  if(r.phase!=='ACTIONS'||r.seat!==seat)return {ok:false,reason:'HAND COPYは自分のACTION中のみ'};
  if(!eventReply&&(r.interruptPending||r.targetEffectPending||r.statusCleansePending||r.supportDisablePending||r.effectPending||r.pendingAttack||r.statusSacrificePending||r.fieldDiscardPending))return {ok:false,reason:'先に保留中の選択を解決してください'};
  if(!['C079','C154','C181'].includes(cid))return {ok:false,reason:'このカードにHAND COPYはありません'};
  if(!p.hand?.includes(copyPhysicalId))return {ok:false,reason:'COPYカードが手札にありません'};
  if(p.actedHand)return {ok:false,reason:'HAND能力はこのターン使用済み'};
 }
 const pre=copySourcePreflight(r,seat,cid,sourceId,mode);
 if(!pre.ok)return pre;


 return {...pre,copyPhysicalId,mode,activationLegal:true,executable:false,
  executionReason:'COPY実行のコスト・タイミング・元能力効果解決は未接続'};
}
function copySourcePreflight(r,seat,copyCardId,sourceId,mode="MAIN"){
 const candidate=copyTargetCandidates(r,seat,copyCardId,mode).find(x=>x.physicalId===sourceId);
 if(!candidate)return {ok:false,reason:'対象範囲外'};
 if(candidate.copySource)return {ok:false,reason:'COPY能力の再COPYは禁止'};
 const source=meta(sourceId);
 // GUARDIAN stores its MAIN field without the WILD/STARTER display prefix.
 const mainText=String(source?.main||'').trim();
 if(!source||!(mainText.startsWith('MAIN')||source.kind==='GUARDIAN'&&mainText&&!/^[―—–-]+$/.test(mainText)))return {ok:false,reason:'コピー元MAIN能力なし'};
 const execution=classifyCopySourceMain(source.main,source);
 return {ok:true,sourceId,sourceCardId:candidate.cardId,sourceText:source.main,
   execution,executable:execution.supported,
   executionReason:execution.supported?null:(execution.kind==='FORBIDDEN_COPY'?'COPY元を再COPYできません':'元能力のコスト・タイミング・条件を解決する処理が未対応'),
   requirement:'元能力のコスト・使用時点・1ターン回数制限を継承'};
}
// COPY target discovery only. This does not execute a copied ability.
// Returning candidates is not permission to bypass timing/cost/usage rulings.
function copyTargetCandidates(r,seat,copyCardId,mode="MAIN"){
 const actor=r.players[seat];
 if(!actor||!['C079','C122','C149','C154','C181'].includes(copyCardId))return [];
 const candidates=[];
 const adjacent=(q)=>Number.isInteger(actor.level)&&Number.isInteger(q.level)&&Math.abs(actor.level-q.level)<=1;
 for(let i=0;i<r.players.length;i++){
  const q=r.players[i];if(!q)continue;
  const sources=[];
  if((i!==seat||copyCardId==='C181'&&mode==='HAND')&&q.main)sources.push({id:q.main,zone:'MAIN'});
  if(copyCardId==='C181'&&i!==seat)for(const id of q.support||[])sources.push({id,zone:'SUPPORT'});
  if(i===seat)for(const id of q.support||[])sources.push({id,zone:'SUPPORT'});
  if(copyCardId==='C079'||copyCardId==='C122'){
   if(i===seat||!adjacent(q))continue;
  }else if(copyCardId==='C149'){
   if(i!==seat&&!adjacent(q))continue;
  }else if(copyCardId==='C154'){
   if(i===seat&&sources.length===0)continue;
   if(i!==seat&&(!adjacent(q)||(mode==='MAIN'&&(actor.support||[]).length)))continue;
  }
  for(const src of sources){
   if(copyCardId==='C079'||copyCardId==='C122'||copyCardId==='C154'){
    if(src.zone!==(i===seat?'SUPPORT':'MAIN'))continue;
   }
   if(copyCardId==='C149'&&i!==seat&&src.zone!=='MAIN')continue;
   if(copyCardId==='C181'&&mode==='MAIN'&&src.id===actor.main)continue;
   if(!creature(src.id))continue;
   candidates.push({seat:i,physicalId:src.id,cardId:cardId(src.id),zone:src.zone,
     copySource:/(?:COPY|コピー|擬態|写し)/.test(String(meta(src.id)?.main||''))});
  }
 }
 return candidates;
}
function snapshotAction(r){return {phase:r.phase,actionPoints:r.actionPoints,exploreState:r.explore?structuredClone(r.explore):null,explore:!!r.explore,players:r.players.map(p=>({main:p.main,support:[...p.support],status:[...p.status],hand:[...p.hand],level:p.level,enabled:!p.mainAbilityDisabled&&!p.status.some(st=>['SLEEP','STUN'].includes(st))}))};}
function resolveCreatureCostTriggers(r,p,ids,old,action,handEvent=null){const creatureCost=ids.some(id=>creature(id)),supportEnabled=!!p.main&&!p.status.some(st=>['SLEEP','STUN'].includes(st)),costEnabled=supportEnabled&&!p.mainAbilityDisabled;if(!creatureCost)return;notifyCreatureDiscard(r,p,ids,'CREATURE_COST');p.creatureCostTurn=r.effectTurn||0;emitGameEvent(r,{type:'CREATURE_COST_PAID',seat:p.seat,action});for(const id of (supportEnabled?old.support.filter(id=>p.support.includes(id)&&!p.disabledSupportIds?.includes(id)):[]))if(meta(id).id==='C105')fireLifecycleAbility(r,p,id,'SUPPORT',{cap:1});if(costEnabled&&p.main===old.main&&['C063','C135'].includes(meta(old.main).id))fireLifecycleAbility(r,p,old.main,'MAIN',{power:1});if(costEnabled&&p.main===old.main&&['C108','S10','G12'].includes(meta(old.main).id))fireLifecycleAbility(r,p,old.main,'MAIN',{drawCount:1,cap:meta(old.main).id==='C108'&&old.level===5?1:0});const copied=costEnabled&&p.main===old.main?copiedCostMain(r,p):null;if(copied){const power=['C063','C135'].includes(copied.code)?1:0;fireLifecycleAbility(r,p,p.main,copied.slot,{power,drawCount:power?0:1,cap:copied.code==='C108'&&old.level===5?1:0});}if(handEvent&&handCostEventCodes.has(handEvent.code)){const power=['C063','C135'].includes(handEvent.code)?1:0;fireLifecycleAbility(r,p,handEvent.handId,'HAND_EVENT_'+handEvent.code,{power,drawCount:power?0:1,cap:handEvent.code==='C108'&&old.level===5?1:0});}processEffectQueue(r);}
function fireLifecycleAbility(r,p,id,slot,{drawCount=0,discard=0,cap=0,power=0,limited=true}={}){
 if(!id||limited&&!abilityAvailable(r,p.seat,id,slot))return;
 if(limited)commitAbilityUse(r,p.seat,id,slot);if(cap)p.turnCaptureBonus=(p.turnCaptureBonus||0)+cap;if(power)p.turnPowerBonus=(p.turnPowerBonus||0)+power;
 if(drawCount){r.effectQueue??=[];r.effectQueue.push({owner:p.seat,id,draw:drawCount,discard});}
 log(r,`${p.name} ${meta(id).id} ${slot.startsWith('COPY_COST_')?'COPY MAIN（'+(C[slot.slice(10)]?.name||slot.slice(10))+'）':slot}：条件成立後${drawCount?' DRAW'+drawCount:''}${discard?' / DISCARD'+discard:''}${cap?' / CAPTURE+'+cap:''}${power?' / POWER+'+power:''}`);
}
function resolveLifecycleTriggers(r,seat,a,before){const p=r.players[seat],old=before.players[seat];
 if(r.seat===seat&&(a.type==='explore_resolve'&&before.explore||before.phase==='ACTIONS'&&before.actionPoints>r.actionPoints&&countedActionType(a))){const actionType=countedActionType(a);p.actionCounts??={};p.actionCounts[actionType]=(p.actionCounts[actionType]||0)+1;const profile=mainProfile(r,p,['C184']);if(profile&&p.actionCounts[actionType]===2)fireLifecycleAbility(r,p,profile.id,profile.slot,{drawCount:1,limited:false});}

 if(a.type==='guardian_challenge'&&a.method==='CAPTURE'){const g=p.guardian[String(old.level)],profile=mainProfile(r,p,['C036']);if(g?.status==='captured'&&meta(g.id)?.species==='樹種'&&profile)fireLifecycleAbility(r,p,profile.id,profile.slot,{drawCount:1,discard:1,limited:false});}
 const activeMain=old.enabled&&old.main&&p.main===old.main&&!p.mainAbilityDisabled;
 // C183 suppresses MAIN only. SUPPORT eligibility has its own STATUS/slot gate.
 const activeSupports=!old.status.some(st=>['SLEEP','STUN'].includes(st))?old.support.filter(id=>p.support.includes(id)&&!p.disabledSupportIds?.includes(id)):[];
 if(before.explore&&!r.explore&&a.type==='explore_resolve'){
  emitGameEvent(r,{type:'EXPLORE_COMPLETED',seat,action:a.method});
  for(const id of activeSupports){const cid=meta(id).id;
   if(cid==='C029'&&old.main&&(window.Bot?.speciesCondMatch?.('MAINと異なる種族なら',{...p,main:old.main,support:old.support},id)??meta(old.main).species!==meta(id).species)||cid==='C134'&&(window.Bot?.mainSpecies?.({...p,main:old.main,support:old.support}).has('胞子種')??meta(old.main)?.species==='胞子種'))fireLifecycleAbility(r,p,id,'SUPPORT',{drawCount:1,discard:1});
  }
  if(a.method==='CAPTURE'&&before.exploreState?.ids.includes(a.id)&&meta(a.id)?.species==='樹種'){const profile=mainProfile(r,p,['C036']);if(profile)fireLifecycleAbility(r,p,profile.id,profile.slot,{drawCount:1,discard:1,limited:false});}
  const afterExplore=code=>code==='C074'||code==='C176'||code==='C124'&&hasSupportSpecies(p,'蟲種');
  if(activeMain&&afterExplore(meta(old.main).id))fireLifecycleAbility(r,p,old.main,'MAIN',{drawCount:1,discard:1,limited:meta(old.main).id!=='C176'});
  const copied=activeMain?activeCopiedProfileCode(r,p):null;
  for(const record of before.exploreState?.handAfterExplore||[])if(afterExplore(record.code))fireLifecycleAbility(r,p,record.id,'HAND_EXPLORE_'+record.code,{drawCount:1,discard:1,limited:record.code!=='C176'});
  if(afterExplore(copied))fireLifecycleAbility(r,p,p.main,'COPY_EXPLORE_'+copied,{drawCount:1,discard:1,limited:copied!=='C176'});
  if(a.method==='META'){
   emitGameEvent(r,{type:'META_SUCCEEDED',seat});
   for(const id of activeSupports)if(meta(id).id==='C156'&&old.main)fireLifecycleAbility(r,p,id,'SUPPORT',{drawCount:1,discard:1});
  }
 }
 let costs=[];
 if(a.type==='buy')costs=a.pay||[];
 else if(a.type==='hand_use')costs=[a.id];
 else if(a.type==='explore_resolve'&&a.failureReactionId&&creature(a.failureReactionId))costs=[a.failureReactionId];
 else if(a.type==='reaction_reply'&&a.id&&!['SUPPLY','START ITEM'].includes(type(a.id)))costs=[a.id];
 else if(a.type==='use_item'&&meta(a.id)?.id==='I32')costs=a.pay||[];
 else if(a.type==='status_sacrifice_reply'&&a.use===true)costs=old.support.filter(id=>!p.support.includes(id));
 resolveCreatureCostTriggers(r,p,costs,old,a.type,before.handEvent);
 if(a.type==='buy'&&activeMain){
  if(['S04','C103'].includes(meta(old.main).id))fireLifecycleAbility(r,p,old.main,'MAIN',{drawCount:1,discard:1,limited:false});
  if(['S04','C103'].includes(activeCopiedProfileCode(r,p)))fireLifecycleAbility(r,p,p.main,'COPY_BUY',{drawCount:1,discard:1,limited:false});
 }
 for(let i=0;i<r.players.length;i++){const q=r.players[i],prior=before.players[i];
  const used=prior.hand.filter(id=>['SUPPLY','START ITEM'].includes(type(id))&&!q.hand.includes(id)&&(r.removedItems.includes(id)||q.equip.includes(id)));
  for(const id of used){r.usedItemOwners??={};if(a.type==='use_item'&&meta(a.id)?.id==='I36'&&a.card===id)delete r.usedItemOwners[id];else r.usedItemOwners[id]=i;}
  if(!used.length)continue;
  emitGameEvent(r,{type:'ITEM_USED',seat:i,action:a.type});q.usedItemThisTurn=true;revisedItemHand(r,q,used[0]);
  if(!prior.main||q.main!==prior.main||q.status.some(st=>['SLEEP','STUN'].includes(st)))continue;
  if(!q.mainAbilityDisabled&&['S14','C067','C140'].includes(meta(q.main).id))fireLifecycleAbility(r,q,q.main,'MAIN',{drawCount:1,discard:1});
  if(['S14','C067','C140'].includes(activeCopiedProfileCode(r,q)))fireLifecycleAbility(r,q,q.main,'COPY_ITEM',{drawCount:1,discard:1});
  for(const id of prior.support)if(q.support.includes(id)&&!q.disabledSupportIds?.includes(id)){
   if(meta(id).id==='C117')fireLifecycleAbility(r,q,id,'SUPPORT',{cap:1});
   if(meta(id).id==='C074')fireLifecycleAbility(r,q,id,'SUPPORT',{drawCount:1,discard:1});
  }
 }
 if(a.type==='explore_resolve'&&before.exploreState?.source==='wild'&&!r.explore&&!p.status.some(st=>['SLEEP','STUN'].includes(st)))for(const id of p.support)if(cardId(id)==='C093'&&!p.disabledSupportIds?.includes(id))fireLifecycleAbility(r,p,id,'SUPPORT',{drawCount:1,discard:1});
 resolveHandEvent(r,seat,a,before);processEffectQueue(r);

}
function unsafeApply(r,seat,a){
 need(r.phase!=='LOBBY'||['set_mode','start'].includes(a.type),'ゲーム開始前です');
 let p=r.players[seat];need(p,'無効なプレイヤー');const beforeAction=snapshotAction(r);
 if(r.phase==='START'&&!r.startSnapshot)captureStartSnapshot(r);
 const pendingReply=r.targetEffectPending?'target_effect_reply':r.supportDisablePending?'support_disable_reply':r.statusSacrificePending?'status_sacrifice_reply':r.statusCleansePending?'status_cleanse_reply':r.effectPending?'resolve_effect':r.fieldDiscardPending?'field_discard':r.pendingAttack?'reaction_reply':null;
 need(!pendingReply||a.type===pendingReply,'先に保留中の選択を解決してください: '+pendingReply);
 prepareHandEvent(r,seat,a,beforeAction);
 const items=arr=>{need(Array.isArray(arr),'カード配列が必要');need(arr.length===new Set(arr).size,'同一カードの二重指定');return arr;};
 switch(a.type){
 case 'target_effect_reply':{
  const e=r.targetEffectPending;need(e?.owner===seat,'対象選択の権限がありません');const candidates=targetEffectCandidates(r,e);need(candidates.includes(a.choice),'現在の合法な対象を選択してください');
  r.targetEffectPending=null;
  if(e.mode==='POWER_LOSS')applyInterferencePowerLoss(r,p,r.players[a.choice],1,{interference:false});
  else if(e.mode==='HAND_DISCARD'){const id=take(p.hand,a.choice);p.discard.push(id);notifyCreatureDiscard(r,p,[id],'CARD_EFFECT');r.effectQueue.unshift({owner:e.actor,id:e.source,draw:1,discard:0});}
  else if(e.mode==='SUPPORT_DISCARD'){const q=r.players[e.target],id=take(q.support,a.choice);q.discard.push(id);q.disabledSupportIds=(q.disabledSupportIds||[]).filter(x=>x!==id);notifyCreatureDiscard(r,q,[id],'CARD_EFFECT');}
  else if(e.mode==='SUPPRESS_SUPPORT'){const q=r.players[e.target];q.disabledSupportIds??=[];q.disabledSupportIds.push(a.choice);}
  else if(e.mode==='STRAY_TAKE')p.stray.push(take(r.players[e.target].stray,a.choice));
  else if(e.mode==='STRAY_GIVE')r.players[e.target].stray.push(take(p.stray,a.choice));
  log(r,`${p.name} ${e.code}：対象を選択し効果を解決`);processEffectQueue(r);break;}
 case 'support_disable_reply':{
  const e=r.supportDisablePending;need(e&&e.owner===seat,'無効化の選択権がありません');
  need(e.candidates.includes(a.id),'対象外のSUPPORT');
  const target=r.players[e.target];need(target.support.includes(a.id),'SUPPORTが変更されています');
  target.disabledSupportIds??=[];need(!target.disabledSupportIds.includes(a.id),'すでに無効化済み');
  target.disabledSupportIds.push(a.id);r.supportDisablePending=r.supportDisableQueue?.shift()||null;
  log(r,`${p.name} ${meta(e.source).id}${e.source===p.main&&p.mainCopy?' COPY '+supportDisableMainSource(r,p):''} ${e.source===p.main?'MAIN':'SUPPORT'}：${target.name}の${meta(a.id).name}をこのターン無効化`);break;}
 case 'status_cleanse_reply':{const e=r.statusCleansePending;need(e&&e.owner===seat,'解除の選択権がありません');need(!e.required||a.status!==undefined,'解除するSTATUSを1つ選択してください');if(a.status!==undefined){need(e.statuses.includes(a.status)&&p.status.includes(a.status),'解除対象STATUSがありません');need(abilityAvailable(r,seat,e.source,e.slot||'MAIN'),'このターンは能力使用済み/無効');commitAbilityUse(r,seat,e.source,e.slot||'MAIN');take(p.status,a.status);emitGameEvent(r,{type:'STATUS_REMOVED',seat,target:seat,status:a.status,action:meta(e.source).id+'_MAIN'});resolveStatusRemovedTriggers(r,p);}r.statusCleansePending=null;log(r,`${p.name} ${meta(e.source).id} MAIN：${a.status?'STATUS '+a.status+'解除':'解除しなかった'}`);break;}
 case 'status_sacrifice_reply':{
  const e=r.statusSacrificePending;need(e&&e.owner===seat,'脱皮の選択権がありません');
  r.statusSacrificePending=null;
  if(a.use===true){
   need(p.support.includes(e.id),'脱皮カードがSUPPORTにありません');
   need(p.status.includes(e.status),'解除するSTATUSがありません');
   take(p.support,e.id);cycle(r,e.id);take(p.status,e.status);
   emitGameEvent(r,{type:'STATUS_REMOVED',seat:p.seat,target:p.seat,status:e.status,action:'C127'});
   resolveStatusRemovedTriggers(r,p);log(r,`${p.name} C127 SUPPORT：脱皮で${e.status}解除`);
  }else log(r,`${p.name} C127 SUPPORT：脱皮を使用しなかった`);
  break;}
 case 'resolve_effect':{
   need(r.effectPending?.owner===seat,'この効果の選択権はありません');need(p.hand.includes(a.id),'捨てる対象が手札にありません');const e=r.effectPending;
   p.discard.push(take(p.hand,a.id));notifyCreatureDiscard(r,p,[a.id],'CARD_EFFECT');r.effectPending=null;log(r,`${meta(e.source).name}の能力：手札1枚を捨てた`);processEffectQueue(r);break;}
 case 'hand_copy_action':{
  p=active(r,seat);requireNoExplore(r);const pre=copyActivationPreflight(r,seat,a.id,a.sourceId,'HAND');need(pre.ok,pre.reason);const option=handCopyActionOptions(r,seat,a.id).find(x=>x.sourceId===a.sourceId);need(option,'この条件で実行できるHAND COPYのACTION能力ではありません');
  const code=option.code;
  if(['S08','C005'].includes(code)&&!(code==='S08'&&a.mode==='cycle'))need(p.status.includes(a.status),'解除対象STATUSがありません');
  if(code==='S08'&&a.mode==='cycle')need(a.payId!==a.id&&p.hand.includes(a.payId),'コピーカード以外の手札1枚が必要');
  if(code==='C012'){need(a.payId!==a.id&&p.hand.includes(a.payId)&&creature(a.payId),'渡す別のCREATUREが必要');need(Number.isInteger(a.target)&&r.players[a.target]?.level===p.level&&a.target!==seat,'同LEVELの相手が必要');}
  if(['S12','C011'].includes(code))need(a.payId!==a.id&&p.hand.includes(a.payId),'元能力で捨てる別の手札1枚が必要');
  const old={main:p.main,support:[...p.support],level:p.level};p.discard.push(take(p.hand,a.id));p.actedHand=true;resolveCreatureCostTriggers(r,p,[a.id],old,a.type);
  if(option.cost)useAction(r);
  if(code==='S08'&&a.mode==='cycle'){p.discard.push(take(p.hand,a.payId));draw(r,p,1);queueDiscardTriggers(r,p,[a.payId],'MAIN_EFFECT');}
  else if(code==='C012'){const record={handId:a.id,sourceId:a.sourceId,sourceText:pre.sourceText,code,owner:seat,target:a.target,turn:r.effectTurn||0};p.handAttack=record;resolveIncomingAttack(r,{seat,target:a.target,text:pre.sourceText,sourceId:a.id,sourceCode:code,handCopy:{...record},giftId:a.payId});}
  else if(['S08','C005'].includes(code)){take(p.status,a.status);emitGameEvent(r,{type:'STATUS_REMOVED',seat,target:seat,status:a.status,action:'HAND_COPY_ACTION'});resolveStatusRemovedTriggers(r,p);}
  else if(['S12','C011'].includes(code)){p.discard.push(take(p.hand,a.payId));draw(r,p,1);queueDiscardTriggers(r,p,[a.payId],'MAIN_EFFECT');}
  else {r.effectQueue??=[];r.effectQueue.push({owner:seat,id:a.id,draw:1,discard:1});}
  log(r,`${p.name} HAND COPY：${code}を1回実行（元能力のコストを適用）`);processEffectQueue(r);break;}
 case 'hand_use':{
   p=active(r,seat);need(!p.actedHand,'HAND能力は自ターン合計1回');need(p.hand.includes(a.id),'HAND能力を持つカードが手札にありません');const c=meta(a.id);need(handEffects.has(c.id),'このHAND能力はCOPY等の未対応処理を含みます。勝手に使用できません');
   if(c.id==='C005')need(p.main&&p.status.includes(a.status),'MAINの解除対象STATUSが必要');
   if(c.id==='C035')need(p.discard.includes(a.target),'捨て札から戻す1枚を選択');
   p.discard.push(take(p.hand,a.id));p.actedHand=true;
   if(c.id==='C005'){take(p.status,a.status);emitGameEvent(r,{type:'STATUS_REMOVED',seat,target:seat,status:a.status,action:'HAND'});resolveStatusRemovedTriggers(r,p);}
   else if(c.id==='C035')p.deck.unshift(take(p.discard,a.target));
   else {const n=c.id==='C117'&&p.usedItemThisTurn?2:1;draw(r,p,n);if(n===2&&p.hand.length)r.effectPending={owner:seat,source:a.id};}
   log(r,`${p.name} が${c.name}のHAND能力を使用（1ターン1回）`);break;}
 case 'hand_copy_attack':{
  p=action(r,seat);requireNoExplore(r);const pre=copyActivationPreflight(r,seat,a.id,a.sourceId,'HAND');need(pre.ok,pre.reason);need(pre.execution?.kind==='COPIED_ATTACK_MAIN','妨害能力を選択してください');need(handAttackTargets(r,seat,a.id,a.sourceId).some(q=>q.seat===a.target),'HAND妨害の対象・POWER・条件が不正');
  const old={main:p.main,support:[...p.support],level:p.level};p.discard.push(take(p.hand,a.id));p.actedHand=true;resolveCreatureCostTriggers(r,p,[a.id],old,a.type);
  const record={handId:a.id,sourceId:a.sourceId,sourceText:pre.sourceText,code:pre.sourceCardId,owner:seat,target:a.target,turn:r.effectTurn||0};p.handAttack=record;
  if([...batchAAttacks,'C072','C115','C055'].includes(record.code))commitAbilityUse(r,seat,a.id,'HAND_ATTACK_'+record.code);
  const q=r.players[a.target];useAction(r);p.didInterfere=true;resolveIncomingAttack(r,{seat,target:a.target,text:interferenceResolvedText(pre.sourceText,q),targetHadStatus:q.status.length>0,sourceId:a.id,sourceCode:record.code,handCopy:{...record}});break;}
 case 'main_give_creature':{
 p=action(r,seat);requireNoExplore(r);const profile=mainProfile(r,p,['C012']);need(profile,'C012の有効なMAIN能力が必要');need(abilityAvailable(r,seat,profile.id,profile.slot),'1ターン1回');const q=r.players[a.target];need(q&&q.seat!==seat&&q.level===p.level,'同LEVELの相手が必要');need(p.hand.includes(a.id)&&creature(a.id),'手札CREATUREが必要');commitAbilityUse(r,seat,profile.id,profile.slot);useAction(r);resolveIncomingAttack(r,{seat,target:q.seat,text:'妨害：'+C.C012.main,sourceId:p.main,sourceCode:'C012',giftId:a.id});break;}
 case 'interfere':{
   p=action(r,seat);requireNoExplore(r);need(Number.isInteger(a.target),'対象を選択');const text=mainAbilityText(r,p);const q=eligibleAttack(r,seat,a.target,text);let handPower=null;if(a.copyHandId!==undefined||a.copySourceId!==undefined){need(/(?:自分より|相手より)(?:合計)?POWER/.test(text),'この妨害にPOWER比較はありません');handPower=payHandPower(r,p,a);}if(p.mainCopy?.execution?.kind==='COPIED_ATTACK_MAIN'&&!handPower)need(interferenceTargets(r,seat,text).includes(q),'COPY妨害の対象が不正');
   
   need(/妨害：/.test(text),'MAINに妨害能力がありません');need(interferenceSupported(text),'この妨害はまだ自動処理できません。カードを消費しません');
   if(/自分より(?:合計)?POWERが低/.test(text)||/相手より合計POWERが高ければ/.test(text))need(interferenceAttackPower(r,seat,a.target,text,'MAIN',handCheckPlayer(p,handPower),handPower?.amount||0)>interferenceDefensePower(r,a.target),'POWER比較の条件未達');
   if(text.includes('相手MAINがPARASITE状態なら'))need(q.status.includes('PARASITE'),'PARASITE状態の対象が必要です');
   need(attackContextReady(r,p,q,text),'妨害の対象条件または使用回数が不正');
   commitAttackDeclaration(r,p,text);
   useAction(r);p.didInterfere=true;resolveIncomingAttack(r,{seat,target:a.target,text:interferenceResolvedText(text,q),targetHadStatus:q.status.length>0,sourceId:p.main,sourceCode:p.mainCopy?.execution?.kind==='COPIED_ATTACK_MAIN'?p.mainCopy.execution.sourceCard.id:cardId(p.main),...(handPower?{handPower}:{}),...(beforeAction.handEvent?{handEvent:beforeAction.handEvent}:{})});
   break;}
 case 'reaction_reply':{
   need(r.pendingAttack?.target===seat,'REACTIONの対象ではありません');const att=r.pendingAttack;let blocked=false;
   blocked=payAttackReaction(r,p,att,a);
   r.pendingAttack=null;finishAttack(r,att,blocked);break;}
 case 'set_mode':need(seat===0&&r.phase==='LOBBY','ホストのみ変更できます');need(['RETURN','ORIGIN'].includes(a.mode),'無効なモード');r.mode=a.mode;break;
 case 'start':need(seat===0,'ホストだけが開始できます');setup(r);break;
 case 'draft_pick':need(r.phase==='DRAFT' && r.seat===seat,'選択順ではありません');need(r.starterOffer.includes(a.id),'提示外のカード');p.main=take(r.starterOffer,a.id);log(r,`${p.name} が初期MAINを選択`);r.draftIndex++;if(r.draftIndex===4){r.unusedStarters.push(...r.starterOffer);r.starterOffer=[];r.phase='START';r.seat=0;captureStartSnapshot(r);log(r,'全員のSTARTER選択完了。第1ラウンド開始');}else r.seat=r.draftOrder[r.draftIndex];break;
 case 'rearrange':{
   p=active(r,seat);need(r.phase==='START','START時のみ編成可能');
   // v0.9.2: explicit role inputs for the sequential UI; legacy ids still supported.
   const explicit=Object.prototype.hasOwnProperty.call(a,'main')||Object.prototype.hasOwnProperty.call(a,'support');
   let nextMain,nextSupport;
   if(explicit){need(a.main===null||(typeof a.main==='string'&&a.main.length>0),'MAINはカードIDまたはnull');nextMain=a.main;nextSupport=items(a.support);need(nextSupport.length<=2,'SUPPORTは最大2体');}
   else {const legacy=items(a.ids);nextMain=legacy[0]||null;nextSupport=legacy.slice(1);}
   const ids=items([...(nextMain?[nextMain]:[]),...nextSupport]);need(ids.length<=3,'編成は最大3体');need(ids.every(creature),'CREATUREのみ配置');
   let available=[...p.hand,...(p.main?[p.main]:[]),...p.support];need(ids.every(id=>available.includes(id)),'所持していないカード');
   const old=[...(p.main?[p.main]:[]),...p.support];p.hand.push(...old);ids.forEach(id=>take(p.hand,id));setMainPhysical(r,p,nextMain);p.support=[...nextSupport];log(r,`${p.name} が編成を変更`);break;}
 case 'start_status_cleanse':{
   p=active(r,seat);need(r.phase==='START','START中のみ使用できます');
   need(startAbilityEligible(r,seat,'C173'),'ターン開始時のMAINが有効なC173ではありません');
   need(r.startSnapshot.status.includes(a.status),'ターン開始時にないSTATUSは解除できません');
   need(r.startSnapshot.enabled,'ターン開始時のMAIN能力が使用できません');
   need(p.status.includes(a.status),'解除対象STATUSがありません');
   need(!r.startStatusCleanseUsed?.[String(seat)],'このSTARTではすでに解除しています');
   take(p.status,a.status);
   r.startStatusCleanseUsed??={};r.startStatusCleanseUsed[String(seat)]=true;
   emitGameEvent(r,{type:'STATUS_REMOVED',seat,target:seat,status:a.status,action:'C173_START'});
   resolveStatusRemovedTriggers(r,p);
   log(r,`${p.name} C173 MAIN：START時に${a.status}を解除`);
   break;}
 case 'copy_main':{p=active(r,seat);need(['START','ACTIONS'].includes(r.phase),'自分のSTART/ACTION中のみ');requireNoExplore(r);bindMainCopy(r,p,a.sourceId);log(r,`${p.name} が${meta(a.sourceId).name}のMAIN能力をこのターンCOPY`);break;}
 case 'start_species':{p=active(r,seat);const choice=startSpeciesOptions(r,seat);need(choice,'開始時の未選択START種族能力が必要');if(choice.support){need(choice.candidates.includes(a.id),'開始時SUPPORTから選択');p.startSupportSpecies={source:choice.source,card:a.id,species:'蟲種',turn:r.effectTurn||0};}else{const selected=Array.isArray(a.species)?a.species:[a.species];need(selected.length===choice.count&&new Set(selected).size===selected.length&&selected.every(sp=>choice.candidates.includes(sp)),'正本の種族を必要数選択');p.startSpecies={card:choice.source,species:selected[0],speciesList:selected,replace:choice.replace,turn:r.effectTurn||0};if(choice.code==='C177'&&!r.startSnapshot.support.some(id=>meta(id).species===selected[0]))p.turnCaptureBonus=(p.turnCaptureBonus||0)+1;}log(r,`${p.name} ${choice.code} START：種族を選択`);break;}
 case 'start_done':{
   p=active(r,seat);need(r.phase==='START','STARTではありません');need(!startSpeciesOptions(r,seat),'START種族を選択してください');r.phase='ACTIONS';r.actionPoints=2;break;}
 case 'explore':{
   p=action(r,seat);requireNoExplore(r);// RETURN中も通常探索は可能
   const got=wildDraw(r,p.level,Math.max(1,3-(p.nextExplorePenalty?1:0)));p.nextExplorePenalty=false;need(got.length,'野生山札と捨て札が空です');useAction(r);r.explore={owner:seat,level:p.level,ids:got,source:'wild',usedExploreSources:[],heatPenalty:p.level===5&&!p.returning&&!hasHeatAdaptation(p)};log(r,`${p.name} L${p.level} 探索で${got.length}枚公開`);break;}
 case 'explore_stray':{
   p=action(r,seat);requireNoExplore(r);need(p.stray.includes(a.id),'遊動個体がありません');useAction(r);r.explore={owner:seat,level:p.level,ids:[take(p.stray,a.id)],source:'stray',strayId:a.id,usedExploreSources:[],heatPenalty:p.level===5&&!p.returning&&!hasHeatAdaptation(p)};log(r,`${p.name} は遊動個体を追跡`);break;}
 case 'explore_more':{
   p=active(r,seat);need(r.explore?.owner===seat,'探索中ではありません');
   const id=a.sourceId;need(typeof id==='string','追加公開には使用するカードが必要');
   r.explore.usedExploreSources??=[];
   need(!r.explore.usedExploreSources.includes(id),'この探索でその能力・ITEMはすでに使用済み');
   // COPY MAIN: resolve only an unconditionally classified exploration reveal.
   // Inherit source timing (exploration), never permit recursive COPY.
   let copySource=null;
   let n=0;
   const handCopy=!!a.copyHandId;
   if(handCopy)need(id===a.copyHandId,'HAND COPYカードの指定が不一致');
   if(a.copySourceId!==undefined){
    const mode=handCopy?'HAND':'MAIN';
    need((handCopy||id===p.main)&&['C079','C122','C149','C154','C181'].includes(meta(id)?.id),'COPY発動元が不正');
    const pre=copyActivationPreflight(r,seat,id,a.copySourceId,mode);
    need(pre.ok,pre.reason||'COPY対象が不正');
    n=copyExploreAmount(r,p,pre.execution,id);
    need(Number.isInteger(n)&&(n>0||handCopy&&pre.sourceCardId==='C176'&&n===0),'現在の条件では探索追加のCOPY能力を使用できません');
    copySource=pre.sourceId;
   }else{
    need(!handCopy,'HAND COPYのコピー元が必要');
    n=exploreSourceCount(p,id,r);
   }
   need(n>0||handCopy&&cardId(copySource)==='C176','追加公開できるMAIN・SUPPORT能力またはFREE ITEMを選んでください');
   // I05: +1 normally, +4 with a stray.
   if(meta(id)?.id==='I06')need(p.level>=6,'深層探査機はLEVEL6以降限定');
   need(r.explore.ids.length+n<=12,'公開上限12枚を超えています');
   need(n===0||r.wild[String(r.explore.level)].length+r.wildDiscard[String(r.explore.level)].length>0,'野生山札にカードがないため追加公開できません');
   const item=p.hand.includes(id)&&['SUPPLY','START ITEM'].includes(type(id));
   if(item){take(p.hand,id);r.removedItems.push(id);p.usedItemThisTurn=true;}
   if(handCopy){const old={main:p.main,support:[...p.support],level:p.level};take(p.hand,id);p.discard.push(id);p.actedHand=true;resolveCreatureCostTriggers(r,p,[id],old,a.type);}
   r.explore.usedExploreSources.push(id);
   if(copySource&&handCopy&&['C124','C176'].includes(cardId(copySource))){r.explore.handAfterExplore??=[];r.explore.handAfterExplore.push({id,code:cardId(copySource),sourceId:copySource,sourceText:meta(copySource).main,turn:r.effectTurn||0});}
   if(copySource){r.explore.copySourceUsed=copySource;if(!handCopy)bindMainCopy(r,p,copySource);}
   const copiedExploreCode=id===p.main?activeCopiedProfileCode(r,p):null;const exploreCode=copySource?cardId(copySource):copiedExploreCode||cardId(id);if(exploreCode==='C039'&&!handCopy)commitAbilityUse(r,seat,id,copySource||copiedExploreCode?'COPY_EXPLORE_C039':'MAIN');
   const got=wildDraw(r,r.explore.level,n);r.explore.ids.push(...got);
   log(r,`${p.name} が${meta(id).name}の${item?'ITEM':'能力'}で${got.length}枚追加公開（同探索中は再使用不可）`);break;}
 case 'explore_redraw':{
   p=active(r,seat);need(r.explore?.owner===seat,'探索中ではありません');
   const id=a.sourceId,c=meta(id);let handRecord=r.explore.handRedraw?.[id],handPre=null;
   if(a.copyHandId!==undefined){need(a.copyHandId===id,'HAND COPYカードが不一致');if(handRecord){need(a.copySourceId===handRecord.sourceId,'継続中HAND COPYが不正');}else{handPre=copyActivationPreflight(r,seat,id,a.copySourceId,'HAND');need(handPre.ok,handPre.reason);need(redrawMains.has(handPre.sourceCardId),'引き直し能力ではありません');handRecord={code:handPre.sourceCardId,sourceId:a.copySourceId,sourceText:handPre.sourceText,turn:r.effectTurn||0};}}
   need(!handRecord||a.copyHandId===id,'HAND継続指定が必要');
   const profile=redrawProfile(r,p,id,handRecord?.code);
   need(id&&r.explore.ids.includes(a.id),'引き直す公開カードを指定してください');
   need(profile,'現在有効な引き直し能力を持つカードではありません');need(!profile.reason,profile.reason);
   const {code,maximum,item:isItem}=profile;
   r.explore.redrawCount??={};const uses=profile.used;
   need(!isItem||uses>0||p.hand.includes(id),'ITEMが手札にありません');
   need(handRecord||isItem||p.main===id||p.support.includes(id),'引き直しを行う仲間が編成にいません');
   if(handPre){const old={main:p.main,support:[...p.support],level:p.level};p.discard.push(take(p.hand,id));p.actedHand=true;r.explore.handRedraw??={};r.explore.handRedraw[id]=handRecord;resolveCreatureCostTriggers(r,p,[id],old,a.type);}
   if(code==='C171'&&!uses)commitAbilityUse(r,seat,id,profile.slot);
   if(code==='I02'){
      need(typeof a.species==='string'&&a.species,'生体探知機は宣言する種族が必要');
      r.explore.redrawSpecies??={};
      if(!uses){need(!r.explore.ids.some(x=>meta(x).species===a.species),'宣言した種族が公開済みのため引き直せません');r.explore.redrawSpecies[id]=a.species;}
      else {need(r.explore.redrawSpecies[id]===a.species,'同じ種族の宣言を維持してください');need(!r.explore.ids.some(x=>meta(x).species===a.species),'指定種族が出たので追加引き直しはできません');}
   }
   if(isItem&&!uses){take(p.hand,id);r.removedItems.push(id);p.usedItemThisTurn=true;}
   r.explore.redrawCount[id]=uses+1;r.explore.usedExploreSources??=[];if(!r.explore.usedExploreSources.includes(id))r.explore.usedExploreSources.push(id);
   take(r.explore.ids,a.id);r.wild[String(r.explore.level)].push(a.id);
   r.explore.ids.push(...wildDraw(r,r.explore.level,1));
   if(code==='C171'&&uses===1){r.effectQueue??=[];r.effectQueue.push({owner:seat,id,draw:1,discard:1});processEffectQueue(r);}
   log(r,`${p.name} は${c.name}で公開カードを引き直した（${uses+1}/${maximum}）`);break;}
 case 'explore_resolve':{
   p=active(r,seat);need(r.explore?.owner===seat,'探索中ではありません');const e=r.explore;let chosen=a.id || null;need(!chosen||e.ids.includes(chosen),'公開外のカード');need(['CAPTURE','META','FAIL','SKIP'].includes(a.method),'不正な獲得方法');
   if(['CAPTURE','META','FAIL'].includes(a.method))need(chosen,'対象選択が必要');
   if(a.awaitCaptureAid!==undefined)need(a.method==='CAPTURE'&&typeof a.awaitCaptureAid==='boolean','援護待ち捕獲の指定が不正');
   if(a.failureReactionId!==undefined){
    need(a.method==='FAIL','捕獲失敗時だけREACTIONを使用できます');
    need(captureFailureOptions(r,seat).includes(a.failureReactionId),'使える捕獲失敗REACTIONがありません');
    need(creature(chosen),'通常捕獲のCREATUREだけが対象です');
   }
   if(a.method==='CAPTURE'){
     if(a.directSupport===true){need(p.level===1&&!p.returning&&p.l1CaptureCount<2,'SUPPORT直接配置はL1最初のCAPTURE成功2回だけです');need(p.main&&p.support.length<2,'SUPPORTの空き枠がありません');}
     const cap=Number(meta(chosen).cap);
     need(Number.isFinite(cap),'CAP値を確認できません');
     const used=items(a.captureItems||[]);
     need(used.every(id=>p.hand.includes(id)),'指定した捕獲ITEMが手札にありません');
     need(used.every(id=>meta(id)?.id==='I14'||captureItemBonus(id,chosen)>0),'この対象に使えない捕獲ITEMが含まれます');need(used.filter(id=>meta(id)?.id==='I14').length<=1,'自動捕獲装置は1枚だけ');need(!used.some(id=>meta(id)?.id==='I14')||used.length===1,'I14固定5にほかの補正ITEMは併用不可');
     const fixed=used.some(id=>meta(id)?.id==='I14');const bonus=used.reduce((s,id)=>s+captureItemBonus(id,chosen),0);
     // Evaluate the legal COPY source in this target and cost context.
     let copyCapBonus=0,compoundHand=null;
     const copyFromHand=a.copyHandId!==undefined;
     if(copyFromHand)need(a.copySourceId!==undefined,'HAND COPYのコピー元が必要です');
     if(a.copySourceId!==undefined){
      if(!copyFromHand){
       need(p.main&&['C079','C122','C149','C154','C181'].includes(meta(p.main)?.id),'捕獲COPYを使用できるMAINがいません');
       need(!e.copyCaptureUsed,'この探索では捕獲COPYを使用済み');
      }
      const pre=copyActivationPreflight(r,seat,copyFromHand?a.copyHandId:p.main,a.copySourceId,copyFromHand?'HAND':'MAIN');
      need(pre.ok,pre.reason||'COPY対象が不正');need(!fixed||copyFromHand&&pre.sourceCardId==='C186','固定値捕獲ITEMと数値COPY補正は併用できません');
      copyCapBonus=copyCaptureAmount(r,p,pre.execution,chosen,copyFromHand,a.copyHandId);compoundHand=copyFromHand&&pre.sourceCardId==='C186'&&p.support.length===2?{code:'C186',handId:a.copyHandId}:null;
      need(Number.isInteger(copyCapBonus)&&(copyCapBonus>0||compoundHand),'現在の編成では捕獲力COPY補正を使用できません');
     }
     if((copyCapBonus||compoundHand)&&copyFromHand){
      const old={main:p.main,support:[...p.support],level:p.level};
      p.discard.push(take(p.hand,a.copyHandId));p.actedHand=true;
      resolveCreatureCostTriggers(r,p,[a.copyHandId],old,a.type);
      log(r,compoundHand?`${p.name} HAND COPY：この捕獲判定にC186のSUPPORT種族補正を適用`:`${p.name} がHAND COPYを捨てて捕獲力+${copyCapBonus}を得た`);
     }
     if(compoundHand)copyCapBonus=0;const base=fixed?5:(window.Bot?.capScore(handCheckPlayer(p,compoundHand),chosen)??1)-(a.copySourceId!==undefined&&!copyFromHand?copyMainBonus(r,p,'STATIC_CAPTURE',chosen):0);
     const aid=fixed?{used:[],offered:false}:itemInterrupt(r,{kind:'CAPTURE_AID',target:seat,card:chosen,required:cap,base:base+bonus+copyCapBonus,guardian:false});
     const aidBonus=aid.used.length*2;const isShort=base+bonus+copyCapBonus+aidBonus<cap;
     // Legacy manual fields carry no authority over the computed result.
     // A committed shortage resolves as failure after the existing REACTIONs;
     // an uncommitted shortage keeps the existing atomic validation behavior.
     if(isShort){
      need(aid.offered||a.awaitCaptureAid===true,'捕獲力不足：援護を含む判定を確定するか、捕獲方法を選び直してください');
      a.method='FAIL';const reaction=itemInterrupt(r,{kind:'CAPTURE_FAILURE',target:seat,card:chosen}).used[0];if(reaction)a.failureReactionId=reaction.id;
     }
     if(copyCapBonus||compoundHand){
      if(!copyFromHand){e.copyCaptureUsed=true;bindMainCopy(r,p,a.copySourceId);}
      e.copyCaptureSource=a.copySourceId;
     }
     for(const id of used){take(p.hand,id);r.removedItems.push(id);}if(used.length)p.usedItemThisTurn=true;
     log(r,`${p.name} CAPTURE判定：簡易基礎${base}+ITEM${bonus}+COPY${copyCapBonus}+援護${aidBonus} / CAP${cap}${isShort?' / 捕獲失敗':''}`);
   }
   if(a.method==='META'){
     const mats=items(a.materials||[]);need(mats.length>=2,'META素材は2体以上');need(mats.every(id=>[...p.hand,...(p.main?[p.main]:[]),...p.support].includes(id)),'素材が所持領域にありません');
     const goal=meta(chosen);need(type(chosen)!=='GUARDIAN','GUARDIANにMETA不可');need(mats.every(id=>creature(id)&&meta(id).species===goal.species),'META素材は同一の印刷種族');
     const used=items(a.metaItems||[]);need(used.every(x=>p.hand.includes(x)&&itemInMeta.has(meta(x)?.id)),'META用ITEM以外を使用できません');
     need(used.every(x=>!['I23','I24'].includes(meta(x).id)||meta(x).id==='I23'&&['樹種','胞子種'].includes(goal.species)||meta(x).id==='I24'&&goal.species==='蟲種'),'指定種族用META ITEMの条件不足');
     let bonus=used.reduce((n,x)=>n+(meta(x).id==='I22'?1:['I23','I24'].includes(meta(x).id)?2:0),0);
     let reduction=used.reduce((n,x)=>n+(meta(x).id==='I25'?2:0),0);
     need(mats.reduce((t,x)=>t+Number(meta(x).meta||0),0)+bonus>=Number(goal.meta)-reduction,'META合計不足');
     for(const x of used){take(p.hand,x);r.removedItems.push(x);}if(used.length)p.usedItemThisTurn=true;

     for(const id of mats){ if(p.main===id)p.main=null;else if(p.support.includes(id))take(p.support,id);else take(p.hand,id);cycle(r,id);}
     queueDiscardTriggers(r,p,mats,'META');
     if(used.some(x=>meta(x).id==='I26')){r.effectQueue??=[];r.effectQueue.push({owner:seat,id:used.find(x=>meta(x).id==='I26'),draw:2,discard:1});processEffectQueue(r);}
     log(r,`${p.name} がMETA素材${mats.length}体を循環させて進化成功（DISCARD能力は手動裁定）`);
   }
   if(['CAPTURE','META'].includes(a.method)){
     // L1のCAPTURE成功・最初の2回のみ、空SUPPORTへの即時配置を選べる。
     // 成功した回数は配置を断っても増える。META・失敗・帰還中には適用しない。
     const l1InitialCapture = a.method==='CAPTURE' && p.level===1 && !p.returning && p.l1CaptureCount<2;
     if(l1InitialCapture){
       need(typeof a.directSupport==='boolean','L1最初のCAPTURE2回は配置するか選択してください');
       if(a.directSupport)need(p.main&&p.support.length<2,'SUPPORTの空き枠がありません');
       p.l1CaptureCount++;
     }else if(a.directSupport===true)err('SUPPORT直接配置はL1最初のCAPTURE成功2回だけです');
     if(l1InitialCapture&&a.directSupport){
       p.support.push(chosen);
       log(r,`${p.name} がL1初期捕獲 ${p.l1CaptureCount}/2：${meta(chosen).name}を空きSUPPORT${p.support.length}へ直接配置（能力は直ちに有効）`);
     }else{
       p.discard.push(chosen);
       log(r,`${p.name} が${meta(chosen).name}を${a.method==='META'?'META':'CAPTURE'}で捨て札へ獲得（自動判定）`);
     }

   }else if(a.method==='FAIL'&&a.failureReactionId!==undefined){
    const id=take(p.hand,a.failureReactionId);
    if(cardId(id)==='I10'){r.removedItems.push(id);p.usedItemThisTurn=true;}
    else {p.discard.push(id);queueDiscardTriggers(r,p,[id],'REACTION_COST');}
    p.stray.push(chosen);log(r,`${p.name} は${meta(id).name}のREACTIONで捕獲失敗したCREATUREを遊動個体に残した`);
   }else if(a.method==='FAIL'&&p.level===3){if(p.stray.length)discardWild(r,p.stray.shift());p.stray.push(chosen);log(r,`${p.name} の捕獲失敗。遊動個体になった`);}else if(chosen)discardWild(r,chosen);
   for(const id of e.ids){if(id!==chosen)discardWild(r,id);}
   r.explore=null;
   if(e.heatPenalty&&p.hand.length){
      r.fieldDiscardPending={owner:seat,level:5};
      log(r,`${p.name} L5灼熱FIELD：適応のないMAINで探索したため手札1枚の破棄が必要`);
   }
   break;}
 case 'field_discard':{
   need(r.fieldDiscardPending?.owner===seat,'FIELD破棄の対象プレイヤーではありません');
   need(p.hand.includes(a.id),'FIELD破棄カードを手札から選んでください');
   p.discard.push(take(p.hand,a.id));r.fieldDiscardPending=null;notifyCreatureDiscard(r,p,[a.id],'FIELD');
   log(r,`${p.name} が灼熱FIELDによる破棄（DISCARD能力は発動しない）`);break;}
 case 'buy':{
   p=action(r,seat);requireNoExplore(r);need(r.market.includes(a.id),'市場にありません');const cost=Number(meta(a.id)?.cost);const paid=items(a.pay||[]);need(Number.isInteger(cost)&&paid.length===cost,'支払う手札枚数とCOSTが一致しません');need(paid.every(x=>p.hand.includes(x)),'手札にないカードがあります');paid.forEach(id=>p.discard.push(take(p.hand,id)));p.discard.push(take(r.market,a.id));fillSupply(r);useAction(r);queueDiscardTriggers(r,p,paid,'BUY');log(r,`${p.name} が手札${cost}枚で${meta(a.id).name}を補給`);break;}
 case 'use_item':{
   p=r.players[seat];need(p.hand.includes(a.id),'手札にないITEM');need(['SUPPLY','START ITEM'].includes(type(a.id)),'ITEMのみ使用できます');useItemDirect(r,p,a.id,a,beforeAction.handEvent);break;}
 case 'guard_interference':{
   p=active(r,seat);const shield=p.equip.find(id=>meta(id)?.id==='I21');
   const armor=p.equip.find(id=>meta(id)?.id==='I18');
   need(shield||armor,'使用可能な防御装備がありません');
   if(shield){log(r,`${p.name} の携帯シェルターが妨害を無効化（次のSTARTまで保持）`);}
   else{take(p.equip,armor);r.removedItems.push(armor);log(r,`${p.name} の甲殻プロテクターが妨害を無効化し除外`);}
   break;}
 case 'discard':{
   p=active(r,seat);need(p.hand.includes(a.id),'手札にありません');err('任意の手札破棄は無効です。HANDは専用ボタン、コスト破棄は補給/METAから実行してね');}
 case 'draw':{
   err('根拠のない無料DRAWは禁止。HAND・DISCARD・ITEM能力から発動してください');}
 case 'cycle':{
   p=active(r,seat);need(p.hand.includes(a.id),'手札にありません');need(creature(a.id),'CREATUREのみ循環');take(p.hand,a.id);cycle(r,a.id);log(r,`${p.name} が${meta(a.id).name}を野生山札の底へ循環（能力手動裁定）`);break;}
 case 'guardian_challenge':{
   need(a.failureReactionId===undefined,'捕獲失敗REACTIONはGUARDIAN挑戦には使えません');
   p=action(r,seat);requireNoExplore(r);need(p.level>=2&&p.level<=8&&!p.returning,'降下中のL2〜L8でGUARDIANへ挑戦できます');
   const lvl=p.level,g=p.guardian[String(lvl)];need(g?.status==='waiting','担当GUARDIANは突破済み／不在です');need(['FORCE','CAPTURE'].includes(a.method),'FORCE/CAPTUREを選択');need(!p.moved,'このターンの移動枠を使用済み');
   const gi=items(a.captureItems||[]);if(a.method==='FORCE')need(!gi.length,'FORCEで捕獲ITEM不可');
   need(gi.every(id=>p.hand.includes(id)&&(meta(id)?.id==='I14'||captureItemBonus(id,g.id)>0)),'GUARDIANに使える手札の捕獲ITEMを指定');
   need(gi.filter(id=>meta(id)?.id==='I14').length<=1,'I14は1枚だけ');need(!gi.some(id=>meta(id)?.id==='I14')||gi.length===1,'I14固定5に他の捕獲ITEMは併用不可');
   const fixed=gi.some(id=>meta(id)?.id==='I14'),computed=gi.reduce((n,id)=>n+captureItemBonus(id,g.id),0);
   let handCopy=null,handPower=null;if(a.copySourceId!==undefined||a.copyHandId!==undefined){if(a.method==='FORCE')handPower=payHandPower(r,p,a);else{handCopy=guardianCopyOptions(r,seat).find(x=>x.handId===a.copyHandId&&x.sourceId===a.copySourceId);need(handCopy,'合法なHAND捕獲COPYを選択してください');need(!fixed||handCopy.compound,'HAND捕獲COPYの数値補正は固定5ITEMと併用できません');}}
   if(handCopy){const old={main:p.main,support:[...p.support],level:p.level};p.discard.push(take(p.hand,handCopy.handId));p.actedHand=true;resolveCreatureCostTriggers(r,p,[handCopy.handId],old,a.type);log(r,`${p.name} GUARDIAN HAND COPY：捕獲力+${handCopy.amount}`);}
   const capturePlayer=handCheckPlayer(p,handCopy),handCaptureBonus=handCopy?.compound?0:handCopy?.amount||0;const aid=a.method==='CAPTURE'&&!fixed?itemInterrupt(r,{kind:'CAPTURE_AID',target:seat,card:g.id,required:Number(meta(g.id).cap),base:(window.Bot?.capScore(capturePlayer,g.id)??1)+computed+handCaptureBonus,guardian:true}):{used:[]};
   const predicted=a.method==='FORCE'?(window.Bot?.canForce(handCheckPlayer(p,handPower),g,handPower?.amount||0)??false):(window.Bot?.canCaptureGuardian(capturePlayer,g,computed+handCaptureBonus+aid.used.length*2,fixed)??false);
   need(a.success===undefined||typeof a.success==='boolean'&&a.success===predicted,'GUARDIAN判定結果の手動上書きはできません');const success=predicted;
   for(const id of gi){take(p.hand,id);r.removedItems.push(id);}if(gi.length)p.usedItemThisTurn=true;
   useAction(r);p.moved=true;
   if(success){g.status=a.method==='CAPTURE'?'captured':'forced';if(a.method==='CAPTURE')p.discard.push(g.id);
     if(lvl===8){p.final=[true,true,true];if(r.mode==='ORIGIN'){r.winner=seat;r.phase='FINISHED';log(r,`${p.name} がL8担当GUARDIANを${a.method}で突破！ ORIGIN勝利`);break;}p.returning=true;log(r,`${p.name} がL8担当GUARDIANを突破。RETURN帰還開始（上昇は次の自ターン以降）`);}
     else {p.level=lvl+1;log(r,`${p.name} が${a.method}でL${lvl}担当GUARDIANを即時突破 → L${p.level}`);}
   }else log(r,`${p.name} L${lvl} GUARDIAN即時CHECK失敗（ACTION・移動枠・使用ITEMは戻らない）`);
   break;}
 case 'guardian_check':{err('v0.9.4ではGUARDIANは挑戦宣言時に即時CHECKします');}
 case 'move':{
   p=action(r,seat);requireNoExplore(r);need(!p.moved,'移動は1手番1回');const lvl=p.level;
   if(p.returning){need(lvl>=1,'すでに地上です');p.level--;log(r,`${p.name} が地上へ向けてL${lvl}→${p.level===0?'地上':'L'+p.level}`);if(p.level===0){r.winner=seat;r.phase='FINISHED';}useAction(r);p.moved=true;break;}
   need(lvl===1,'L2〜L8の降下は担当GUARDIAN突破で行います');need(p.main&&p.support.length===2,'L1：MAIN1＋SUPPORT2が必要');p.level=2;for(const id of p.stray)discardWild(r,id);p.stray=[];useAction(r);p.moved=true;log(r,`${p.name} が仲間3体を揃えてL1→L2へ降下`);break;}
 case 'status':{
   err('無制限STATUS編集は無効です。妨害・ITEMから処理してください');p=active(r,seat);need(Number.isInteger(a.target)&&a.target>=0&&a.target<4,'対象プレイヤーが不正');need(['POISON','SLEEP','STUN','PARASITE','FEAR'].includes(a.status),'状態異常が不正');const q=r.players[a.target];need(typeof a.active==='boolean','状態を選択');if(a.active&&!q.status.includes(a.status))q.status.push(a.status);if(!a.active)q.status=q.status.filter(x=>x!==a.status);log(r,`${p.name} が${q.name}の${a.status}を${a.active?'付与':'解除'}（手動裁定）`);break;}
 case 'pushback':{
   p=action(r,seat);requireNoExplore(r);need(a.blocked===undefined,'防御結果の手動指定はできません');let handPower=null;if(a.copyHandId!==undefined||a.copySourceId!==undefined){need(/(?:自分より|相手より)(?:合計)?POWER/.test(mainAbilityText(r,p)),'この妨害にPOWER比較はありません');need(a.copyHandId!==a.id,'COPYと押し戻しのコストは別のCREATUREが必要');handPower=payHandPower(r,p,a);}need(Number.isInteger(a.target)&&pushbackTargets(handPower?{...r,players:r.players.map(q=>q.seat===seat?handCheckPlayer(p,handPower):q)}:r,seat,handPower?.amount||0).some(q=>q.seat===a.target),'押し戻しの射程・対象条件・使用回数が不正（L8へは押し戻せません）');need(p.hand.includes(a.id)&&creature(a.id),'手札CREATUREが必要');
   const q=r.players[a.target],text=mainAbilityText(r,p),record={owner:seat,sourceId:p.main,sourceCode:p.mainCopy?.execution?.sourceCard?.id||cardId(p.main),sourceText:text,costId:a.id,fromLevel:q.level,turn:r.effectTurn||0};
   commitAttackDeclaration(r,p,text);take(p.hand,a.id);cycle(r,a.id);useAction(r,2);p.didInterfere=true;
   resolveIncomingAttack(r,{seat,target:a.target,text:pushbackText(text),targetHadStatus:q.status.length>0,sourceId:p.main,sourceCode:record.sourceCode,pushback:record,...(handPower?{handPower}:{}),...(beforeAction.handEvent?{handEvent:beforeAction.handEvent}:{})});break;}
 case 'main_draw_cycle':{p=active(r,seat);requireNoExplore(r);const profile=mainDrawCycleProfile(r,handCheckPlayer(p,beforeAction.handEvent));need(profile?.available,'条件または使用回数を満たすMAIN手札交換能力がありません');fireLifecycleAbility(r,p,profile.id,profile.slot,{drawCount:1,discard:1});processEffectQueue(r);break;}
 case 'main_hand_cycle':{
   p=action(r,seat);requireNoExplore(r);const source=mainHandCycleSource(r,p);
   need(p.main&&source,'MAINに対応する手札交換能力がありません');
   need(!p.mainAbilityDisabled,'MAIN能力がこのターン無効化されています');
   need(!p.status.includes('SLEEP')&&!p.status.includes('STUN'),'MAIN能力を使用できない状態です');
   need(p.hand.includes(a.id),'捨てるカードは自分の手札から選択してください');
   p.discard.push(take(p.hand,a.id));useAction(r);const n=draw(r,p,1);
   log(r,`${p.name} ${source}${source===meta(p.main).id?' MAIN':' COPY MAIN'}：1 ACTIONで手札1枚を捨て、${n}枚引いた`);
   queueDiscardTriggers(r,p,[a.id],'MAIN_EFFECT');break;}
 case 'main_status_cleanse':{
   p=action(r,seat);requireNoExplore(r);
   const cleanseSource=mainStatusCleanseSource(r,p);
   need(p.main&&cleanseSource,'MAINに対応するSTATUS解除能力がありません');
   need(!p.mainAbilityDisabled,'MAIN能力がこのターン無効化されています');
   need(!p.status.includes('SLEEP')&&!p.status.includes('STUN'),'MAIN能力を使用できない状態です');
   need(['POISON','SLEEP','STUN','PARASITE','FEAR'].includes(a.status)&&p.status.includes(a.status),'解除対象STATUSがありません');
   take(p.status,a.status);
   useAction(r);
   emitGameEvent(r,{type:'STATUS_REMOVED',seat,target:seat,status:a.status,action:'MAIN_1_ACTION'});
   resolveStatusRemovedTriggers(r,p);
   log(r,`${p.name} ${cleanseSource}${cleanseSource===meta(p.main).id?' MAIN':' COPY MAIN'}：1 ACTIONで${a.status}解除`);
   break;}
 case 'manual_action':{
   p=action(r,seat);requireNoExplore(r);const n=Number(a.count||1);need([1,2].includes(n),'1/2 ACTIONのみ');useAction(r,n);log(r,`${p.name}：${String(a.note||'手動能力').slice(0,90)}（${n} ACTION）`);break;}
 case 'note':{
   p=active(r,seat);log(r,`${p.name}：${String(a.note||'手動裁定').slice(0,120)}`);break;}
 case 'trade_offer':case 'trade_reply':err('TRADEは廃止されました');break;
 case 'camp':{
   p=active(r,seat);need(r.phase==='ACTIONS','STARTを完了してください');requireNoExplore(r);const keep=items(a.keep||[]);need(keep.every(id=>p.hand.includes(id)),'KEEPに持っていないカードあり');if(r.pendingTrade?.from===seat){r.pendingTrade=null;log(r,'未成立の交換提案はCAMPで破棄');}const send=p.hand.filter(id=>!keep.includes(id));p.discard.push(...send);p.hand=keep;const n=draw(r,p,Math.max(0,5-p.hand.length));
   const campSources=(p.support||[]).filter(id=>!p.disabledSupportIds?.includes(id)&&['C006','C081','C130'].includes(meta(id)?.id));
   const choice=a.campCleanse??null;
   if(choice!==null){
    need(choice&&typeof choice==='object'&&!Array.isArray(choice),'CAMP解除指定が不正');
    need(campSources.includes(choice.id),'CAMP解除可能なSUPPORTがありません');
    need(['POISON','PARASITE','FEAR'].includes(choice.status)&&p.status.includes(choice.status),'CAMP任意解除の対象STATUSがありません');
    take(p.status,choice.status);
    emitGameEvent(r,{type:'STATUS_REMOVED',seat:p.seat,target:p.seat,status:choice.status,action:'CAMP_OPTIONAL'});
    if(meta(choice.id).id==='C130')draw(r,p,1);
    resolveStatusRemovedTriggers(r,p);
    log(r,`${p.name} CAMP：${meta(choice.id).id}で${choice.status}解除`);
   }
   const cleared=p.status.filter(x=>['STUN','SLEEP'].includes(x));p.status=p.status.filter(x=>!['STUN','SLEEP'].includes(x));for(const status of cleared){emitGameEvent(r,{type:'STATUS_REMOVED',seat:p.seat,target:p.seat,status,action:'CAMP'});resolveStatusRemovedTriggers(r,p);}log(r,`${p.name} CAMP：STOW ${send.length}枚／DRAW ${n}枚`);r.seat=(r.seat+1)%4;startPhase(r);break;}
 default:err('未対応アクション: '+a.type);
 }
 resolveLifecycleTriggers(r,seat,a,beforeAction);if(r.fieldDiscardPending&&!r.players[r.fieldDiscardPending.owner].hand.length){log(r,'FIELD破棄：手札0枚のため不発');r.fieldDiscardPending=null;}for(const q of r.players)if(q.main&&r.physicalStatus&&Object.hasOwn(r.physicalStatus,q.main))r.physicalStatus[q.main]=[...q.status];r.revision++;assertConservation(r);
}
function restoreRoom(r,snapshot){for(const key of Object.keys(r))delete r[key];Object.assign(r,snapshot);}
function runInterruptTransaction(r,base,commands,decisions=[],randomTape=[],time=Date.now(),strict=false,reset=true){
 const previousContext=interruptReplay;const context={decisions,randomTape:[...randomTape],time,index:0,randomIndex:0,strict,room:r};interruptReplay=context;
 if(reset)restoreRoom(r,structuredClone(base));
 try {for(const c of commands){const a=structuredClone(c.action);context.action=a;unsafeApply(r,c.seat,a);emitGameEvent(r,{type:'ACTION_COMMITTED',seat:c.seat,action:String(a.type||'')});}need(context.index===decisions.length,'余分な割り込み決定が保存されています');return null;}
 catch(e){if(e?.tag!==interruptYield)throw e;need(context.index===decisions.length+1,'割り込み履歴の長さが不正');restoreRoom(r,structuredClone(base));const pending={base:structuredClone(base),commands:structuredClone(commands),decisions:structuredClone(decisions),randomTape:context.randomTape,time,window:e.window};r.interruptPending=pending;return pending;}
 finally{interruptReplay=previousContext;}
}
function apply(r,seat,a){const previous=structuredClone(r);try{
 if(r.interruptPending){const e=r.interruptPending;need(a.type==='interrupt_reply'&&seat===e.window.owner,'先に割り込みREACTIONを解決してください');const ids=a.ids??[];need(Array.isArray(ids)&&new Set(ids).size===ids.length&&ids.length<=e.window.max&&ids.every(id=>e.window.candidates.includes(id)),'割り込み選択が不正');runInterruptTransaction(r,e.base,e.commands,[...e.decisions,{window:e.window,ids}],e.randomTape,e.time);}
 else {need(a.type!=='interrupt_reply','割り込みREACTIONはありません');runInterruptTransaction(r,previous,[{seat,action:a}],[],[],Date.now(),false,false);}
 assertConservation(r);
}catch(e){restoreRoom(r,previous);throw e;}}
function applyMany(r,seat,actions){need(Array.isArray(actions)&&actions.length>0&&actions.length<=20,'操作数が不正');const previous=structuredClone(r);try{need(!r.interruptPending,'先に割り込みREACTIONを解決してください');runInterruptTransaction(r,previous,actions.map(action=>({seat,action})),[],[],Date.now(),false,false);assertConservation(r);}catch(e){restoreRoom(r,previous);throw e;}}
function verifyInterrupt(r){
 const e=r.interruptPending;if(!e)return;
 need(e.base&&!e.base.interruptPending&&Array.isArray(e.commands)&&e.commands.length>0&&e.commands.length<=20,'割り込み元の保存状態が不正');
 need(Array.isArray(e.decisions)&&e.decisions.length<=128&&Array.isArray(e.randomTape)&&e.randomTape.length<=100000&&e.randomTape.every(v=>Number.isFinite(v)&&v>=0&&v<1)&&Number.isFinite(e.time),'割り込み履歴が不正');
 const original=structuredClone(e.base);verifyRoom(original);
 const outer=structuredClone(r);delete outer.interruptPending;need(JSON.stringify(outer)===JSON.stringify(e.base),'割り込み中の元状態が変更されています');
 const replay=structuredClone(e.base);const result=runInterruptTransaction(replay,e.base,e.commands,e.decisions,e.randomTape,e.time,true);need(result&&JSON.stringify(result.window)===JSON.stringify(e.window)&&JSON.stringify(result.randomTape)===JSON.stringify(e.randomTape),'割り込み窓が現在の正本・状態と不一致');
}
function verifyRoom(r){r.pendingTrade=null;if(r?.interruptPending){verifyInterrupt(r);assertConservation(r);return r;}need(r&&Array.isArray(r.players)&&r.players.length===4,'保存データのプレイヤー構成が不正');
 if(r.explore){const e=r.explore;for(const [id,b] of Object.entries(e.handRedraw||{})){need(e.owner>=0&&r.players[e.owner]&&['C079','C154','C181'].includes(cardId(id))&&redrawMains.has(b.code)&&cardId(b.sourceId)===b.code&&b.sourceText===String(C[b.code].main)&&b.turn===(r.effectTurn||0)&&r.players[e.owner].actedHand===true&&Number.isInteger(e.redrawCount?.[id])&&e.redrawCount[id]>0,'HAND引き直し保存状態が不正');}for(const b of e.handAfterExplore||[]){need(r.players[e.owner]&&['C079','C154','C181'].includes(cardId(b.id))&&['C124','C176'].includes(b.code)&&cardId(b.sourceId)===b.code&&b.sourceText===String(C[b.code].main)&&b.turn===(r.effectTurn||0)&&r.players[e.owner].actedHand===true,'HAND複合探索の保存状態が不正');}}
 if(r.explore?.source==='stray'){
  const e=r.explore;
  // Only an untouched single-card legacy reveal has an unambiguous original stray.
  if(e.strayId===undefined&&e.ids?.length===1&&!e.usedExploreSources?.length&&!Object.keys(e.redrawCount||{}).length)e.strayId=e.ids[0];
  if(e.strayId!==undefined)need(!!P[e.strayId]&&creature(e.strayId),'追跡元カードが不正');
 }
 need(['ORIGIN','RETURN'].includes(r.mode),'保存データのモードが不正');
 // v0.5以前からのセーブは特例の使用履歴がないため、新規2枠の誤付与を避ける。
 for(const p of r.players){
   need(!Object.prototype.hasOwnProperty.call(p,'handCopyCheck'),'一時COPY判定文脈を保存できません');
   if(p.l1CaptureCount===undefined)p.l1CaptureCount=2;p.usedItemThisTurn??=false;p.turnPowerBonus??=0;p.turnPowerPenalty??=0;p.firstDefenseUsed??=[];
   need(Number.isInteger(p.l1CaptureCount)&&p.l1CaptureCount>=0&&p.l1CaptureCount<=2,'L1捕獲成功回数が不正');
 }
 need(['DRAFT','CHECK','START','ACTIONS','FINISHED'].includes(r.phase),'保存データのフェーズが不正');
 need(Number.isInteger(r.seat)&&r.seat>=0&&r.seat<4,'保存データの手番が不正');
 need(r.wild&&r.wildDiscard&&r.supply&&r.market&&r.unusedStarters&&r.removedItems,'保存データの山札が不正');
 verifyTargetEffects(r);
 verifySupportDisableChoices(r);
 verifyHandAttacks(r);
 if(r.pendingAttack){
  need(!Object.prototype.hasOwnProperty.call(r.pendingAttack,'c055Secondary'),'追加寄生は再生トランザクション内でのみ解決します');
  const a=r.pendingAttack,q=r.players[a.target];if(a.handEvent){const b=a.handEvent,p=r.players[a.seat];need(r.phase==='ACTIONS'&&r.seat===a.seat&&b.owner===a.seat&&b.turn===(r.effectTurn||0)&&p?.actedHand&&['C079','C154','C181'].includes(cardId(b.handId))&&cardId(b.sourceId)===b.code&&successEventCodes.has(b.code)&&b.sourceText===String(C[b.code]?.main)&&!a.handPower&&!a.handCopy,'HAND成功後イベントの保存状態が不正');}if(a.handPower){const b=a.handPower,p=r.players[a.seat],card=C[b.code],ex=card&&classifyCopySourceMain(card.main,card);need(r.seat===a.seat&&b.owner===a.seat&&b.turn===(r.effectTurn||0)&&p?.actedHand&&['C079','C154','C181'].includes(cardId(b.handId))&&cardId(b.sourceId)===b.code&&b.sourceText===String(card?.main)&&b.amount>0&&b.amount===handPowerAmount(r,p,ex)&&/(?:自分より|相手より)(?:合計)?POWER/.test(a.pushback?.sourceText||a.text),'HAND POWERの保存状態が不正');}if(a.pushback){const b=a.pushback,p=r.players[a.seat],source=C[b.sourceCode],binding=p?.mainCopy;need(r.phase==='ACTIONS'&&r.seat===a.seat&&r.mode==='RETURN'&&b.owner===a.seat&&p?.main===b.sourceId&&a.sourceId===b.sourceId&&a.sourceCode===b.sourceCode&&source&&b.sourceText===String(source.main)&&a.text===pushbackText(b.sourceText)&&/妨害：/.test(b.sourceText)&&b.turn===(r.effectTurn||0)&&p.didInterfere&&r.actionPoints===0&&q?.returning&&q.level===b.fromLevel&&Number.isInteger(b.fromLevel)&&b.fromLevel>=1&&b.fromLevel<7&&creature(b.costId)&&r.wild[type(b.costId)==='STARTER'?'1':String(meta(b.costId).level)].includes(b.costId)&&(cardId(p.main)===b.sourceCode||binding?.sourceText===b.sourceText&&binding.sourceId&&binding.copyId===p.main),'押し戻しREACTION保存状態が不正');}if(a.itemCode!==undefined)need(['I27','I28','I29'].includes(a.itemCode)&&cardId(a.sourceId)===a.itemCode&&r.removedItems.includes(a.sourceId)&&a.text===(a.itemCode==='I27'?'妨害：相手MAINをSTUNにする。手札をランダムに1枚捨てさせる。':'妨害：'+String(C[a.itemCode].effect)),'ITEM妨害の保存状態が不正');
  need(a.targetHadStatus===undefined||typeof a.targetHadStatus==='boolean','妨害前STATUSの保存状態が不正');
  // Old C077/C199 reaction waits have not applied this attack's STATUS yet.
  if([String(C.C077.main),String(C.C199.main)].includes(a.text)&&a.targetHadStatus===undefined&&q)a.targetHadStatus=q.status.length>0;
  if(typeof a.text==='string')a.text=interferenceResolvedText(a.text,a.targetHadStatus===undefined?q:{status:a.targetHadStatus?['STATUS']:[]});
 }
 r.usedItemOwners??={};need(r.usedItemOwners&&typeof r.usedItemOwners==='object'&&!Array.isArray(r.usedItemOwners),'ITEM使用者の保存記録が不正');for(const [id,owner] of Object.entries(r.usedItemOwners))need(P[id]&&['SUPPLY','START ITEM'].includes(type(id))&&Number.isInteger(owner)&&owner>=0&&owner<4,'ITEM使用者の保存記録が不正');
 r.effectTurn??=0;for(const p of r.players){need(p.creatureDiscardTurn===undefined||p.creatureDiscardTurn===null||Number.isInteger(p.creatureDiscardTurn)&&p.creatureDiscardTurn>=0&&p.creatureDiscardTurn<=r.effectTurn,'CREATURE破棄履歴が不正');need(p.c174SuccessCounts===undefined||p.c174SuccessCounts&&typeof p.c174SuccessCounts==='object'&&!Array.isArray(p.c174SuccessCounts)&&Object.entries(p.c174SuccessCounts).every(([id,n])=>P[id]&&['C174','C079','C122','C149','C154','C181'].includes(cardId(id))&&Number.isInteger(n)&&n>=0),'C174成功履歴が不正');need(p.actionCounts===undefined||p.actionCounts&&typeof p.actionCounts==='object'&&!Array.isArray(p.actionCounts)&&Object.values(p.actionCounts).every(n=>Number.isInteger(n)&&n>=0),'ACTION履歴が不正');}
if(r.phase==='START'&&!r.startSnapshot)r.startSnapshot={seat:r.seat,turn:r.effectTurn,main:null,support:[],status:[],enabled:false,legacy:true};for(const p of r.players){if(p.mainCopy){const b=p.mainCopy,source=meta(b.sourceId);need(P[b.copyId]&&source&&Number.isInteger(b.turn)&&b.turn>=0&&Number.isInteger(r.effectTurn)&&r.effectTurn>=0&&b.turn<=r.effectTurn&&b.owner===p.seat&&['C079','C122','C149','C154','C181'].includes(meta(b.copyId)?.id),'COPY保存状態が不正');const ex=classifyCopySourceMain(source.main,source);need(b.sourceText===source.main&&['STATIC_POWER','STATIC_CAPTURE','EXTRA_EXPLORE','COPIED_PROFILE','COPIED_COST_MAIN','COPIED_ATTACK_MAIN'].includes(ex.kind)&&JSON.stringify(b.execution)===JSON.stringify(ex),'COPY保存能力が正本と一致しません');}validateStartSpecies(r,p);}r.abilityUsage??={};r.effectEvents??=[];for(const p of r.players){if(p.creatureCostTurn===undefined)p.creatureCostTurn=r.effectEvents.some(e=>e.type==='CREATURE_COST_PAID'&&e.seat===p.seat&&e.turn===r.effectTurn)?r.effectTurn:null;need(p.creatureCostTurn===null||Number.isInteger(p.creatureCostTurn)&&p.creatureCostTurn>=0&&p.creatureCostTurn<=r.effectTurn,'CREATUREコストの保存状態が不正');}r.unusedInitial??=[];r.setupPreset='R2';r.marketSize=3;if(r.phase==='CHECK'){r.phase='START';for(const p of r.players)for(const g of Object.values(p.guardian||{}))if(g?.pending)g.pending=null;}
 if(r.statusCleansePending){const e=r.statusCleansePending,actor=r.players[e.owner],profile=actor?mainProfile(r,actor,['C130','C062'],true):null;need(Number.isInteger(e.owner)&&actor?.main===e.source&&profile&&(e.code===undefined||e.code===profile.code)&&(e.slot===undefined||e.slot===profile.slot)&&(profile.code!=='C062'||e.required===true&&abilityAvailable(r,e.owner,e.source,profile.slot)&&e.statuses?.some(st=>actor.status.includes(st)))&&Array.isArray(e.statuses)&&e.statuses.length>0&&e.statuses.length===new Set(e.statuses).size&&e.statuses.every(st=>['POISON','SLEEP','STUN','PARASITE','FEAR'].includes(st)),'STATUS解除の保存状態が不正');}if(r.phase==='START'&&!r.startSnapshot)r.startSnapshot={seat:r.seat,turn:r.effectTurn,main:null,support:[],status:[],enabled:false,legacy:true};return assertConservation(r);}
function adaptCount(p){let group=[...(p.main?[p.main]:[]),...p.support];let n=group.filter(id=>String(meta(id).keyword||'').includes('適応：地下海')).length;
 if(p.main&&!String(meta(p.main).keyword||'').includes('適応：地下海') && p.support.some(id=>!p.disabledSupportIds?.includes(id)&&String(meta(id).support||'').includes('「適応：地下海」を与える')))n++;return n;}
function assertConservation(r){if(r.phase==='LOBBY')return true;const zones=[r.supply,r.market,r.unusedStarters,r.starterOffer,r.removedItems,r.unusedInitial||[]];Object.values(r.wild).forEach(x=>zones.push(x));Object.values(r.wildDiscard).forEach(x=>zones.push(x));if(r.explore)zones.push(r.explore.ids);for(const p of r.players){zones.push(p.deck,p.hand,p.discard,p.support,p.equip,p.stray);if(p.main)zones.push([p.main]);for(const x of Object.values(p.guardian)){if(x.status!=='captured')zones.push([x.id]);}}
 const all=zones.flat();const seen=new Set();for(const id of all){need(P[id],`未知の物理ID ${id}`);need(!seen.has(id),`物理コピー重複 ${id}`);seen.add(id);}need(all.length===physical.length,`枚数不一致 ${all.length}/${physical.length}`);return true;}
function publicState(r,seat){const me=r.players[seat];const ps=r.players.map((p,i)=>({seat:i,name:p.name,level:p.level,returning:p.returning,handCount:p.hand.length,deckCount:p.deck.length,discard:p.discard,main:p.main,support:p.support,equip:p.equip,stray:p.stray,status:p.status,guardian:p.guardian,final:p.final,me:i===seat}));
 const offer = r.pendingTrade && ([r.pendingTrade.from,r.pendingTrade.to].includes(seat))?r.pendingTrade:null;
 return {code:r.code,mode:r.mode,setupPreset:'R2',marketSize:3,phase:r.phase,seat:r.seat,revision:r.revision,winner:r.winner,players:ps,me:{seat,hand:me.hand,deckCount:me.deck.length,discard:me.discard,l1CaptureCount:me.l1CaptureCount,main:me.main,support:me.support,equip:me.equip,stray:me.stray},market:r.market||[],supplyCount:r.supply?.length||0,wildCounts:r.wild?Object.fromEntries(Object.entries(r.wild).map(([k,v])=>[k,{deck:v.length,discard:r.wildDiscard[k].length}])):{},starterOffer:r.starterOffer||[],draftSeat:r.phase==='DRAFT'?r.seat:null,actionPoints:r.actionPoints||0,explore:r.explore?{owner:r.explore.owner,level:r.explore.level,ids:r.explore.ids}:null,trade:offer,log:r.log.slice(0,50)};
}
return {startSpeciesOptions,interferenceTargetUseful,interferenceResolvedText,mainAbilityText,interferenceTargets,copyAttackValue,copyCostValue,creatureCostCaptureBonus,guardianCopyOptions,copyCaptureAmount,reactionOptions,interferenceSupported,interferenceAttackPower,startAbilityEligible,copyMainBonus,interferenceDefensePower,copyActivationPreflight,classifyCopySourceMain,copySourcePreflight,copyTargetCandidates,handEffects,itemSupported,cards,physical,C,P,captureItemBonus,exploreSourceCount,exploreTimingOptions,baseRoom,addPlayer,setup,apply,applyMany,verifyRoom,hasHeatAdaptation,publicState,assertConservation,adaptCount,roomCode,mainStatusCleanseSource,mainHandCycleSource,interferenceSuccessDrawProfile,redrawProfile,mainProfile,mainDrawCycleProfile,targetEffectCandidates,captureFailureOptions,handCopyActionOptions,handAttackOptions,handAttackTargets,pushbackTargets,handCheckPlayer,handPowerPushbackOptions,handPowerOptions,handPowerAttackOptions,handEventOptions,c055SpreadTargets,evaluationRoom:()=>interruptReplay?.room||null};

})();
window.RINNE=RINNE;
