'use strict';
(() => {
const $=id=>document.getElementById(id), E=window.RINNE, levels=['地上','菌糸洞窟','地下森林','捕食圏','地下海','灼熱層','古代生物圏','原始生命圏','起源層'];
const cpuNames=['深森の探索者','古代の追跡者','起源の研究者'];
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[x]));
let delay=320,botTimer=null,locked=false,noticeCount=0,lastModalFocus=null;
const m=id=>E.C[E.P[id]?.card_id]||{};
const revisedEffectIds=new Set(['S08','S11','C005','C012','C048','C057','C067','C068','C093','C140','C141','C144','I05','I13','I27','I28','I30','I37','I39','I40']);
const img=id=>window.RINNE_CARD_IMAGE_OVERRIDES?.[m(id).id]||window.RINNE_IMAGE?.[id]||`assets/cards_v094/${esc(m(id).id||String(id).replace(/_\d+$/,''))}.webp`;
const who=()=>window.gameRoom?.players?.[0];
const current=()=>window.gameRoom;
const isCreature=id=>['STARTER','WILD','GUARDIAN'].includes(m(id).kind);
const humanTurn=()=>current()?.seat===0;
function ccard(id,sz='small',attrs=''){if(!id)return `<div class="empty-slot">空き</div>`;return `<button type="button" class="game-card ${sz}" data-card="${esc(id)}" ${attrs} title="${esc(m(id).name)}"><img src="${img(id)}" alt="${esc(m(id).name)}" loading="lazy"><span>${esc(m(id).name)}</span></button>`;}
const lbl=(s)=>`<span class="eyebrow">${esc(s)}</span>`;
const b=(label,act,style='')=>`<button type="button" class="btn ${style}" data-action="${esc(act)}">${esc(label)}</button>`;
function toast(text){const el=$('toast');el.textContent=text;el.classList.remove('hide');clearTimeout(el._timeout);el._timeout=setTimeout(()=>el.classList.add('hide'),3500);}
function show(title,html){const el=$('modal');if(el.classList.contains('hide'))lastModalFocus=document.activeElement;el.classList.remove('hide');document.body.classList.add('v091-modal-open');$('app').inert=true;el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label',title);el.innerHTML=`<div class="dialog"><div class="topline"><h2>${esc(title)}</h2><button type="button" class="header-btn" id="close-dialog">✕ 閉じる</button></div>${html}</div>`;$('close-dialog').onclick=close;requestAnimationFrame(()=>$('close-dialog')?.focus({preventScroll:true}));return el;}
function close(){$('modal').classList.add('hide');$('modal').innerHTML='';document.body.classList.remove('v091-modal-open');$('app').inert=false;if(lastModalFocus?.isConnected)lastModalFocus.focus({preventScroll:true});}
function confirm(title,message,yes){const box=show(title,`<p>${message}</p><div class="modal-actions">${b('キャンセル','no','ghost')}${b('決定','yes','primary')}</div>`);box.querySelector('[data-action=no]').onclick=close;box.querySelector('[data-action=yes]').onclick=()=>{close();yes();};}
function pick(title,ids,{min=1,max=1,initial=[],info='',confirmLabel=null}={}){
 return new Promise(resolve=>{let selected=[...initial],lastScroll=0;
 function toggle(id){if(selected.includes(id))selected=selected.filter(x=>x!==id);else if(selected.length<max)selected.push(id);else toast(`選択できるのは最大${max}枚だよ`);}
 function saveScroll(){lastScroll=document.querySelector('.pick-cards')?.scrollTop||lastScroll;}
 function draw(){const role=title.includes('編成を変更');
 const box=show(title,`<div class="pick-intro"><p>${esc(info||'カードを選択してね。')}</p><div class="pick-progress"><span>選択中 <strong>${selected.length}</strong>枚</span><span>必要 ${min}〜${max}枚</span></div><p class="pick-help">① カードで効果を確認 → ② 「選択する」 → ③ 下の「決定」</p></div><div class="cards pick-cards">${ids.map(id=>{const c=m(id),pos=selected.indexOf(id),yes=pos>=0;return `<div class="pick-tile ${yes?'is-picked':''}"><div class="pick-card-heading"><span>${esc(c.name||c.id)}</span>${yes?`<strong>${role?pos===0?'MAIN':'SUPPORT '+pos:'✓ '+(pos+1)+'番目'}</strong>`:''}</div><button type="button" class="game-card hand" data-inspect="${esc(id)}" aria-label="${esc(c.name)}の能力を見る"><img src="${img(id)}" alt="${esc(c.name)}"><span>🔎 大きく見る</span></button><div class="pick-stats">${esc(c.keyword||[c.species,c.cap!==undefined&&c.cap!==null&&String(c.cap).trim()?'CAP '+c.cap:'',c.cost!==undefined&&c.cost!==null&&String(c.cost).trim()?'COST '+c.cost:''].filter(Boolean).join(' · ')||c.kind)}</div><button type="button" aria-pressed="${yes?'true':'false'}" class="pick-toggle ${yes?'checked':''}" data-select="${esc(id)}" ${!yes&&selected.length>=max?'disabled aria-disabled="true" title="一度に選べる枚数の上限。別のカードを外してね"':''}>${yes?'✓ 選択中・外す':selected.length>=max?'選択上限・先に外す':'＋ 選択する'}</button></div>`}).join('')||'<p>対象カードがないよ。</p>'}</div><div class="pick-selection-summary">${role?'配置する順番：MAIN → SUPPORT 1 → SUPPORT 2':'現在選んだカード'}<strong>${selected.length?selected.map((id,i)=>`${i+1}. ${esc(m(id).name)}`).join(' / '):'なし'}</strong></div><div class="modal-actions pick-footer">${b('キャンセル','cancel','ghost')}${`<button type="button" class="btn primary" data-action="ok" ${selected.length<min||selected.length>max?'disabled aria-disabled="true"':''}>${esc(confirmLabel?confirmLabel(selected.length):`この${selected.length}枚で決定`)}${selected.length<min?`<small class="ux-btn-reason">あと${min-selected.length}枚選んでね</small>`:''}</button>`}</div>`);
 const grid=box.querySelector('.pick-cards');if(grid)grid.scrollTop=lastScroll;
 box.querySelectorAll('[data-inspect]').forEach(n=>n.onclick=()=>{saveScroll();showCard(n.dataset.inspect,{onBack:draw,roleOverride:role?(selected.indexOf(n.dataset.inspect)===0?'MAIN':selected.includes(n.dataset.inspect)?'SUPPORT':null):null})});
 box.querySelectorAll('[data-select]').forEach(n=>n.onclick=()=>{saveScroll();toggle(n.dataset.select);draw();});
 box.querySelector('[data-action=cancel]').onclick=()=>{close();resolve(null)};
 box.querySelector('#close-dialog').onclick=()=>{close();resolve(null)};
 box.querySelector('[data-action=ok]').onclick=()=>{if(selected.length<min||selected.length>max){toast(`必要な枚数を選んでね（${min}〜${max}枚）`);return;}close();resolve(selected)};}
 draw();});}
function commit(action){const r=current();if(!r)return;if(action.eventCopy===undefined&&E.handEventOptions){const choices=E.handEventOptions(r,0,action);if(choices.length){const box=show('この行動の能力をHAND COPY',`<p>COPYカードを捨て、この行動で成立する元能力を1回だけ実行する。</p><div class="modal-actions">${choices.map((o,i)=>b(m(o.handId).name+' → '+m(o.sourceId).name,'eventcopy'+i,'secondary')).join('')}${b('使わない','skip','ghost')}</div>`);choices.forEach((o,i)=>box.querySelector(`[data-action="eventcopy${i}"]`).onclick=()=>{close();commit({...action,eventCopy:{handId:o.handId,sourceId:o.sourceId}});});box.querySelector('[data-action=skip]').onclick=()=>{close();commit({...action,eventCopy:null});};return;}}try{E.apply(r,0,action);if(action.type==='explore'||action.type==='explore_stray')activeTab='capture';else if(['hand_copy_attack','explore_resolve','camp','draft_pick','guardian_check','start_done','buy','move','guardian_challenge','interfere','pushback','rearrange'].includes(action.type))activeTab='turn';safeSave();render();handlePendingField();handlePendingEffects();runCPUs();}catch(e){toast('⚠ '+e.message);}}
function commitMany(actions){const r=current();if(!r)return;try{E.applyMany(r,0,actions);safeSave();render();handlePendingField();handlePendingEffects();runCPUs();}catch(e){toast('⚠ '+e.message);}}
function handlePendingField(){const r=current();if(r?.fieldDiscardPending?.owner!==0)return;
 if(r.interruptPending||r.targetEffectPending||r.supportDisablePending||r.statusSacrificePending||r.statusCleansePending||r.effectPending)return;
 if(!r.players[0].hand.length)return toast('L5 FIELD破棄を確認してください');
 pick('L5灼熱｜FIELD破棄',r.players[0].hand,{info:'適応のないMAINで探索したため、手札1枚を捨てる。DISCARD能力は発動しない。'}).then(sel=>{if(sel)commit({type:'field_discard',id:sel[0]});else toast('手札を1枚捨てるまで次の行動に進めないよ');});}

let pendingEffectShown=false,interruptShown=false;
async function handlePendingEffects(){
 const r=current();if(!r)return;
 if(r.interruptPending){const e=r.interruptPending.window;if(e.owner>0){try{Bot.resolvePendingCpu();safeSave();render();return handlePendingEffects();}catch(error){toast('割り込みが未解決：'+error.message);return;}}
  if(interruptShown)return;interruptShown=true;
  if(e.kind==='C055_TARGET'){const box=show('C055｜追加寄生の対象',`<p>一次対象への新規PARASITE付与が成立。自分と同じLEVELの別の相手MAINを1体選ぶ。追加ACTIONは消費しない。</p><div class="modal-actions">${e.candidates.map((seat,i)=>b(r.players[seat].name,'spread'+i,'secondary')).join('')}</div>`);e.candidates.forEach((seat,i)=>box.querySelector(`[data-action="spread${i}"]`).onclick=()=>{interruptShown=false;close();commit({type:'interrupt_reply',ids:[seat]});});box.querySelector('#close-dialog').onclick=()=>toast('追加寄生の対象を選択してね');return;}
  if(e.kind==='C055_DEFENSE'){const box=show('C055追加寄生｜REACTION',`<p>追加寄生に対する防御を選ぶ。</p><div class="modal-actions">${e.options.map((o,i)=>b(m(o.id).name+(o.asMainCost?'（MAIN防御のコスト）':''),'spreaddefense'+i,'secondary')).join('')}${b('使わない','skipspread','ghost')}</div>`);e.options.forEach((o,i)=>box.querySelector(`[data-action="spreaddefense${i}"]`).onclick=()=>{interruptShown=false;close();commit({type:'interrupt_reply',ids:[o.key]});});const pass=()=>{interruptShown=false;close();commit({type:'interrupt_reply',ids:[]});};box.querySelector('[data-action=skipspread]').onclick=pass;box.querySelector('#close-dialog').onclick=pass;return;}
  if(e.kind==='HAND_COPY'){const box=show('HAND COPY｜能力を使う',`<p>この出来事に元能力を1回使う。COPYカードを捨て、HAND合計1回を消費する。</p><div class="modal-actions">${e.options.map((o,i)=>b(m(o.handId).name+' → '+m(o.sourceId).name,'reactivehand'+i,'secondary')).join('')}${b('使わない','skiphand','ghost')}</div>`);e.options.forEach((o,i)=>box.querySelector(`[data-action="reactivehand${i}"]`).onclick=()=>{interruptShown=false;close();commit({type:'interrupt_reply',ids:[o.key]});});box.querySelector('[data-action=skiphand]').onclick=()=>{interruptShown=false;close();commit({type:'interrupt_reply',ids:[]});};box.querySelector('#close-dialog').onclick=()=>{interruptShown=false;close();commit({type:'interrupt_reply',ids:[]});};return;}
  const label={ORDER:'山札の並べ替え',FORMATION_SWAP:'入れ替えるSUPPORT',REVEALED_DISCARD:'公開された相手の手札を1枚選択',ITEM_HAND:'ITEM使用後のHAND',RECYCLE_BOTTOM:'山札の下に戻すCREATURE',INTERFERENCE_RESCUE:'他プレイヤーへの妨害を無効化',CAPTURE_AID:'他プレイヤーの捕獲直前',POWER_RESCUE:'他プレイヤーのPOWER低下',CAPTURE_FAILURE:'通常捕獲失敗'}[e.kind];
  const selection=await pick(label+'｜REACTION',e.candidates,{min:e.required?1:e.kind==='ORDER'?e.max:0,max:e.max,info:e.kind==='ORDER'?'山札の上から順に全カードを選択。先頭の1枚を引く。':'使うカードを選択。使用しない場合は0枚で決定。'});interruptShown=false;
  if(selection===null){toast(e.kind==='ORDER'?'山札に戻す順序を選んでね':'使用しない場合は0枚で決定してね');return handlePendingEffects();}
  commit({type:'interrupt_reply',ids:selection});return;
 }
 if(r.targetEffectPending){const e=r.targetEffectPending;if(e.owner>0){try{Bot.resolvePendingCpu();safeSave();render();return handlePendingEffects();}catch(error){toast('対象選択が未解決：'+error.message);return;}}
 if(document.querySelector('#modal:not(.hide) [data-target-effect-choice]'))return;
 const choices=E.targetEffectCandidates(r,e),box=show(`${m(e.source).name}｜効果の対象を選択`,`<div data-target-effect-choice data-modal-must-resolve><div class="modal-actions">${choices.map((choice,i)=>b(typeof choice==='number'?r.players[choice].name:m(choice).name,'targeteffect'+i,'secondary')).join('')}</div></div>`);
 choices.forEach((choice,i)=>box.querySelector(`[data-action="targeteffect${i}"]`).onclick=()=>{close();commit({type:'target_effect_reply',choice});});box.querySelector('#close-dialog').onclick=()=>toast('効果の対象を選択してね');return;}
 // Off-turn CPU reactions may leave a forced discard pending during a human turn.
 // Resolve only CPU-owned choices; never auto-select for the human player.
 if(r.supportDisablePending?.owner>0){
  const e=r.supportDisablePending;
  try{E.apply(r,e.owner,{type:'support_disable_reply',id:e.candidates[0]});safeSave();render();return handlePendingEffects();}
  catch(err){toast('CPUのSUPPORT選択が未解決：'+err.message);return;}
 }
 if(r.supportDisablePending?.owner===0&&!pendingEffectShown){
  pendingEffectShown=true;const e=r.supportDisablePending;
  const chosen=await pick(`${m(e.source)?.id||'能力'}｜無効化する相手のSUPPORT`,e.candidates,{min:1,max:1,info:'SUPPORT能力をこのターン無効化する'});
  pendingEffectShown=false;
  if(chosen?.length)commit({type:'support_disable_reply',id:chosen[0]});else toast('無効化対象を選択してください');return;
 }
 if(r.statusSacrificePending?.owner>0){
  const e=r.statusSacrificePending;try{E.apply(r,e.owner,{type:'status_sacrifice_reply',use:true});safeSave();render();return handlePendingEffects();}catch(err){console.error(err);toast('CPU脱皮が未解決：'+err.message);return;}
 }
 if(r.statusSacrificePending?.owner===0&&!pendingEffectShown){
  pendingEffectShown=true;const e=r.statusSacrificePending;
  const choice=await pick('脱皮｜STATUS解除',[e.id],{min:0,max:1,info:`${e.status}を解除するためSUPPORTを捨てる？ 選ばずに確定すると使用しない。`});
  pendingEffectShown=false;commit({type:'status_sacrifice_reply',use:!!choice?.length});return;
 }
 if(r.statusCleansePending?.owner>0){try{Bot.resolvePendingCpu();safeSave();render();return handlePendingEffects();}catch(e){toast('CPUのSTATUS解除が未解決：'+e.message);return;}}
 if(r.statusCleansePending?.owner===0){if(document.querySelector('#modal:not(.hide) [data-status-cleanse-choice]'))return;const e=r.statusCleansePending,options=e.statuses.filter(st=>r.players[0].status.includes(st));const required=e.required===true;const box=show(`${m(e.source).name}｜STATUSを解除`, `<div data-status-cleanse-choice data-modal-must-resolve><p>${required?'解除するSTATUSを1つ選んでね。':'解除するSTATUSを1つ選ぶ。使わないこともできる。'}</p><div class="modal-actions">${options.map((st,i)=>b(st,'cleanse'+i,'secondary')).join('')}${required?'':b('使わない','skipcleanse','ghost')}</div></div>`);options.forEach((st,i)=>box.querySelector(`[data-action="cleanse${i}"]`).onclick=()=>{close();commit({type:'status_cleanse_reply',status:st});});const skip=box.querySelector('[data-action=skipcleanse]');if(skip)skip.onclick=()=>{close();commit({type:'status_cleanse_reply'});};box.querySelector('#close-dialog').onclick=()=>toast(required?'解除するSTATUSを選んでね':'解除するか、使わないかを選んでね');return;}
 if(r.effectPending?.owner>0){
  try{if(Bot.resolvePendingCpu()){safeSave();render();return handlePendingEffects();}}
  catch(e){console.error('CPU EFFECT ERROR',e);toast('CPU追加効果が停止：'+e.message);return;}
 }
 if(r.effectPending?.owner===0&&!pendingEffectShown){
  pendingEffectShown=true;const source=r.effectPending.source;
  const chosen=await pick('カード能力の追加効果',r.players[0].hand,{min:1,max:1,info:`${m(source)?.name||'カード'}の能力により1枚引いたよ。続けて手札を1枚捨ててね。`});
  pendingEffectShown=false;if(chosen)commit({type:'resolve_effect',id:chosen[0]});else toast('DISCARD効果の破棄を確定するまで次の行動には進めないよ');return;
 }
 if(r.pendingAttack?.target>0){
  try{if(Bot.resolvePendingCpu()){safeSave();render();return handlePendingEffects();}}catch(e){console.error('CPU REACTION ERROR',e);toast('CPU防御の選択が停止：'+e.message);return;}
 }
 if(r.pendingAttack?.target===0){
   const hit=r.pendingAttack;if(document.querySelector('#modal:not(.hide) .reaction-modal'))return;
   const choices=E.reactionOptions(r,0,hit.text);
   const box=show('CPUの妨害｜REACTION',`<div class="reaction-modal"><p>${esc(r.players[hit.seat].name)}から妨害を受けたよ。</p><p>${esc(hit.text)}</p><p>防御する方法を選んでね。</p><div class="modal-actions">${choices.map((o,i)=>b((o.asMainCost?'墨隠れで捨てる：':'防御ITEMを使う：')+m(o.id).name,'reaction'+i,'secondary')).join('')}${b('防御しない','pass','primary')}</div></div>`);
   choices.forEach((o,i)=>{box.querySelector(`[data-action="reaction${i}"]`).onclick=()=>{close();commit({type:'reaction_reply',id:o.id,asMainCost:o.asMainCost});};});
   box.querySelector('[data-action=pass]').onclick=()=>{close();commit({type:'reaction_reply'});};
   box.querySelector('#close-dialog').onclick=()=>toast('REACTIONを選んでね');
 }


}
function safeSave(){try{localStorage.setItem('rinne-solo-v07',JSON.stringify(current()));}catch(e){console.warn('autosave blocked',e.message);}}
function loadSave(){try{let x=localStorage.getItem('rinne-solo-v07')||localStorage.getItem('rinne-solo-v06')||localStorage.getItem('rinne-solo-v04')||localStorage.getItem('rinne-solo-v03');if(!x)return null;let state=JSON.parse(x);E.verifyRoom(state);return state;}catch{return null;}}
function reset(){lastAutoCPU=null;activeTab='turn';focusId=null;clearTimeout(botTimer);window.gameRoom=null;try{localStorage.removeItem('rinne-solo-v07');localStorage.removeItem('rinne-solo-v06');localStorage.removeItem('rinne-solo-v04');localStorage.removeItem('rinne-solo-v03');}catch{}landing();}
function startGame(){window.RinneSymbols?.unlockAudio();activeTab='turn';focusId=null;let name=$('player-name')?.value.trim()||'探検者',mode=$('game-mode')?.value||'ORIGIN';let room=E.baseRoom(name);room.mode=mode;room.setupPreset='R2';for(let i=0;i<3;i++)E.addPlayer(room,cpuNames[i]+' [CPU]');E.setup(room);window.gameRoom=room;safeSave();render();window.RinneSymbols?.preview(1);runCPUs();}
function landing(){window.RinneFx?.reset();window.RinneDepth?.reset();clearTimeout(botTimer);document.body.classList.remove('v091-task-open','v091-modal-open');$('app').inert=false;let previous=loadSave();$('app').innerHTML=`<div class="landing"><div class="landing-box">${lbl('SINGLE PLAYER · v0.9.5')}<h1>RINNE</h1><div class="eyebrow" style="color:#edcc98;letter-spacing:.22em">地底世界をめぐる、生命と進化の冒険</div><p>325枚の最新版カードで、L2〜L8の担当GUARDIANを突破する。<br>あなた VS コンピューター3人。</p><div><span class="rule-chip">1人 ＋ CPU3人</span><span class="rule-chip">325枚 最新版</span><span class="rule-chip">POWER / 捕獲力 常時表示</span></div><label>プレイヤー名 <input id="player-name" placeholder="例：RINNE探検隊" value="あなた" maxlength="15"></label><label>勝利モード <select id="game-mode"><option value="ORIGIN">ORIGIN｜L8 GUARDIAN突破で勝利</option><option value="RETURN">RETURN｜L8突破後、地上へ帰還</option></select></label><div class="preset-note">ITEM R2：初期ITEMは1人7枚（ランタン2・捕獲ネット3・コンパス1・応急1）／市場公開3枚。GUARDIANはL2〜L8の各階層に1体ずつ担当。</div>${b('冒険をはじめる ▶','start','primary')}${b('🎓 チュートリアルを体験','tutorial','secondary')}${b('演出を試す','fx_preview','ghost')}${previous?b('前回の続きから遊ぶ','resume','secondary'):''}<p class="caption">v0.9.5：POWER / 捕獲力HUD・PC/スマホ最適化・GUARDIAN即時CHECK・L8 FINAL統合・ITEM R2を反映。カードの最新能力は拡大表示で確認できます。</p></div></div>`;window.RinneStartBackground?.mount(document.querySelector('.landing'));document.querySelector('[data-action=start]').onclick=startGame;document.querySelector('[data-action=tutorial]').onclick=()=>startTutorial();document.querySelector('[data-action=fx_preview]').onclick=showFxPreview;if(previous)document.querySelector('[data-action=resume]').onclick=()=>{window.RinneFx?.reset();window.gameRoom=previous;activeTab='turn';focusId=null;safeSave();render();handlePendingField();handlePendingEffects();runCPUs();};}
// v0.8 live UX: the same v0.7 game engine, fewer decisions displayed at once.
let activeTab='turn',focusId=null,viewedCPUSeat=1,v9FocusOpen=false;
const stageTitle={DRAFT:'初期仲間を選ぼう',CHECK:'GUARDIANの結果を確認',START:'仲間を編成しよう',ACTIONS:'次の行動を選ぼう',FINISHED:'対戦終了'};
function goalFor(r,p){
 if(p.returning)return {title:'地上への帰還',detail:'RETURN：自分の手番に1回、1 ACTIONで1階層上昇。',now:`LEVEL ${p.level}`};
 const lv=p.level;if(lv===1)return {title:'仲間3体を揃えよう',detail:`MAIN ${p.main?1:0}/1・SUPPORT ${p.support.length}/2。最初のCAPTURE成功2回は任意で即SUPPORTへ。`,now:`${(p.main?1:0)+p.support.length} / 3`};
 const g=p.guardian?.[String(lv)],card=g?m(g.id):null,force=card?.force||'—',cap=card?.cap||'—';
 if(lv>=2&&lv<=7)return {title:`L${lv} 担当GUARDIANを突破`,detail:'FORCEまたはCAPTUREで挑戦。1 ACTION＋移動枠を使い、その場で即時CHECK。',now:g?.status==='waiting'?`FORCE ${force} / CAP ${cap}`:'突破済み'};
 return {title:'L8｜最終GUARDIANを突破',detail:r.mode==='ORIGIN'?'突破した時点で勝利。':'突破するとRETURN開始。上昇は次の自ターン以降。',now:`FORCE ${force} / CAP ${cap}`};
}
// v0.8.2: UI eligibility is advisory only; the engine remains the authority.
function gateFor(action,extra={}){
 const r=current(),p=who();if(!r||!p)return {ok:false,reason:'ゲーム開始前'};
 const blocked=(reason)=>({ok:false,reason});const yes=(reason='実行できる')=>({ok:true,reason});
 const own=humanTurn(),phase=r.phase,exp=!!r.explore,lockedField=!!r.fieldDiscardPending;
 if(action==='draft')return own&&phase==='DRAFT'?yes():blocked('初期仲間を選ぶ段階ではない');
 if(action==='formation'||action==='startdone')return own&&phase==='START'?yes():blocked('自分のSTART時のみ');
 if(action==='check')return own&&phase==='CHECK'?yes('判定結果はカードを確認'):blocked('CHECK待ちではない');
 if(action==='field')return r.fieldDiscardPending?.owner===0?yes():blocked('L5の破棄待ちではない');
 if(action==='camp')return own&&phase==='ACTIONS'&&!exp&&!lockedField?yes():blocked(!own?'CPUの手番中':exp?'公開カードを解決してね':lockedField?'L5の手札破棄が先':'CAMPできる手番ではない');
 if(action==='item')return own&&['START','ACTIONS'].includes(phase)&&p.hand.some(id=>['SUPPLY','START ITEM'].includes(m(id).kind))?yes('ITEMのTIMINGは原文で確認'):blocked('手札・タイミングを確認（ITEMを使える状態ではない）');
 if(action==='more'){
   if(!own||phase!=='ACTIONS'||r.explore?.owner!==0)return blocked('自分の探索中だけ');
   const ids=[p.main,...p.support,...p.hand].filter(Boolean);
   const standard=ids.some(id=>E.exploreSourceCount(p,id)>0&&!r.explore.usedExploreSources?.includes(id));
   const copied=copyExploreChoices(r,p).length>0;
   return standard||copied?yes():blocked('使える追加公開能力・ITEMがない');
 }
 if(action==='trade')return blocked('TRADEは廃止されました');
 if(action==='hand')return own&&['ACTIONS','START'].includes(phase)&&!p.actedHand&&p.hand.some(id=>E.handEffects.has(m(id).id)||(E.handCopyActionOptions?.(r,0,id).length||E.handAttackOptions?.(r,0,id).length))?yes('自ターン合計1回／ACTION外'):blocked('使用可能なHANDがない、または使用済み');
 if(!own)return blocked('CPUの手番中');
 if(phase!=='ACTIONS')return blocked(phase==='START'?'STARTを完了してね':phase==='DRAFT'?'初期MAINを選んでね':phase==='CHECK'?'GUARDIAN CHECKが先':'いまは実行できない');
 if(exp)return blocked('探索候補の解決が先');
 if(lockedField)return blocked('L5の手札破棄が先');
 if(r.actionPoints<=0)return blocked('残りACTIONが0');
 const ap=r.actionPoints;
 if(action==='interfere'){if(!p.main||p.mainAbilityDisabled||p.status.includes('STUN')||p.status.includes('SLEEP'))return blocked('MAINが妨害できない状態');let t=E.mainAbilityText(r,p);if(!/妨害：/.test(t))return blocked('MAINに妨害能力がない');if(!E.interferenceSupported(t))return blocked('この妨害効果はまだ未対応');return (E.interferenceTargets(r,0).length||(E.handPowerAttackOptions?.(r,0).length||0))?yes('1 ACTION＋条件を満たす対象を選ぶ'):blocked('射程・能力条件を満たす相手がいない');}
 if(action==='explore')return yes('1 ACTION消費／ITEM不要');
 if(action==='buy'){
    const candidates=extra.id?[extra.id]:r.market;
    if(!candidates?.length)return blocked('公開市場にITEMがない');
    return candidates.some(id=>p.hand.length>=Number(m(id).cost||0))?yes('購入は1 ACTION＋手札COST枚'):blocked('支払えるITEMがない：手札不足');
 }
 if(action==='move'){
   if(p.moved)return blocked('移動は1手番1回');
   if(p.returning)return yes('帰還移動：1 ACTION');
   if(p.level===1)return p.main&&p.support.length===2?yes('L1→L2へ降下'):blocked('MAIN1体＋SUPPORT2体が必要');
   return blocked('L2〜L8の降下は担当GUARDIAN突破で行う');
 }
 if(action==='guardian'){
   if(p.returning||p.level<2||p.level>8)return blocked('降下中のL2〜L8で挑戦');
   const g=p.guardian?.[String(p.level)];if(!g||g.status!=='waiting')return blocked('担当GUARDIANは突破済み／不在');if(p.moved)return blocked('この手番は移動枠を使用済み');
   return yes('1 ACTION＋移動枠／その場で即時CHECK');
 }
  if(action==='pushback'){
   if(ap<2)return blocked('2 ACTION必要');
   if(!p.hand.some(isCreature))return blocked('手札CREATURE1枚が必要');
   return (E.pushbackTargets(r,0).length||E.handPowerPushbackOptions(r,0).length)?yes('元MAINの条件・射程を適用／REACTIONで防御'):blocked('射程・条件を満たす帰還中の相手がいない（L8へは不可）');
 }
 if(action==='manual')return yes('未自動化能力は印字で確認');
 return yes();
}
function smartBtn(label,act,style='',extra={}){
 const g=gateFor(act,extra),note=!g.ok?`<span class="ux-btn-reason">${esc(g.reason)}</span>`:g.reason==='実行できる'?'':`<span class="ux-btn-reason ux-btn-hint">${esc(g.reason)}</span>`;
 return `<button type="button" class="btn ux-rule-button ${style} ${g.ok?'':'ux-not-available'}" data-action="${esc(act)}" ${g.ok?'':`disabled aria-disabled="true"`} title="${esc(g.reason)}">${esc(label)}${note}</button>`;
}
function roleForCard(id){const r=current();if(!r)return null;for(const p of r.players){if(p.main===id)return 'MAIN';if(p.support?.includes(id))return 'SUPPORT';}return null;}

function candidateTile(id,chosen=false){let c=m(id);return `<div class="ux-candidate ${chosen?'ux-chosen':''}"><button type="button" class="ux-card-view" data-card="${esc(id)}" aria-label="${esc(c.name)}の詳細を表示"><img loading="lazy" src="${img(id)}" alt="${esc(c.name)}"><span>🔎 詳しく見る</span></button><div class="ux-card-caption"><b>${esc(c.name)}</b><small>${esc(c.species||'')} · CAP ${esc(c.cap??'—')} · META ${esc(c.meta??'—')}</small></div><button type="button" class="ux-select-btn ${chosen?'selected':''}" data-focus="${esc(id)}">${chosen?'✓ 比較中':'このカードを選ぶ'}</button></div>`;}
function opponentStrip(r){return r.players.slice(1).map((q,i)=>`<div class="ux-rival"><span class="ux-rival-num">CPU ${i+1}</span><span class="ux-rival-name">${esc(q.name.replace(' [CPU]',''))}</span><span class="ux-rival-lv">L${q.level}${q.returning?' ↥':''}</span><span class="ux-rival-info">仲間 ${(q.main?1:0)+q.support.length}/3 · 手札 ${q.hand.length}</span><div class="ux-rival-cards">${[q.main,...q.support].filter(Boolean).map(id=>`<button data-card="${esc(id)}" aria-label="${esc(m(id).name)}を確認"><img src="${img(id)}" alt="${esc(m(id).name)}"></button>`).join('')}</div></div>`).join('');}
function teamPanel(p){return `<section class="ux-panel"><div class="ux-panel-heading"><b>あなたの編成</b><small>カード画像をタップで能力全文</small></div><div class="ux-formation">${[p.main,p.support[0],p.support[1]].map((id,i)=>`<div class="ux-formation-slot"><span>${i===0?'MAIN':`SUPPORT ${i}`}</span>${id?ccard(id,'hand')+`<div class="ux-slot-ability"><b>${i===0?'MAIN':'SUPPORT'}有効</b><span>${esc((i===0?m(id).main:m(id).support)||'対応する印字能力なし').slice(0,46)}</span></div>`:'<div class="ux-empty">空き</div>'}</div>`).join('')}</div><div class="ux-panel-heading"><b>あなたの手札 ${p.hand.length}枚</b><small>山札 ${p.deck.length} · 捨て札 ${p.discard.length}</small></div><div class="ux-hand">${p.hand.map(id=>ccard(id,'hand')).join('')||'<p class="ux-note">手札は空。CAMPで補充できるよ。</p>'}</div>${p.equip?.length?`<div class="ux-note">装備中：${p.equip.map(id=>esc(m(id).name)).join(' / ')}</div>`:''}</section>`;}
// v0.8.4: contextual, optional, non-consuming-by-inspection exploration controls.
function timingPanel(r,p){
 if(r.explore?.owner!==0)return '';
 const options=E.exploreTimingOptions(r,0);
 if(!options.length)return '';
 const known=options.filter(x=>x.item),abilities=options.filter(x=>!x.item);
 const ready=options.filter(x=>x.ready).length;
 const tiles=arr=>arr.map(x=>{
  const c=m(x.id),disabled=!x.ready;
  return `<div class="ux-timing-entry ${disabled?'ux-timing-disabled':''}"><button type="button" class="ux-timing-image" data-card="${esc(x.id)}" aria-label="${esc(c.name)}を拡大"><img src="${img(x.id)}" alt="${esc(c.name)}"></button><div class="ux-timing-copy"><b>${esc(c.name)}</b><small>${esc(x.timing)} · ${esc(c.effect|| (p.main===x.id?c.main:c.support)||'')}</small><span>${esc(x.label)}</span>${disabled?`<em>使用不可：${esc(x.reason)}</em>`:''}</div><button type="button" class="ux-timing-use" data-timing="${esc(x.kind)}" data-source="${esc(x.id)}" data-copy-source="${esc(x.copySourceId||'')}" ${disabled?'disabled aria-disabled="true"':''}>${disabled?'使用不可':'この効果を使う'}</button></div>`;
 }).join('');
 return `<section class="ux-panel ux-timing-panel"><div class="ux-panel-heading"><b>✨ 今、この探索で使える効果</b><small>${ready}件利用可能 · 閲覧だけでは消費しない</small></div><p class="ux-timing-lead">3枚に欲しいCREATUREがいなければ、捕獲を決める前にここから追加公開・引き直しができるよ。</p>${known.length?`<div class="ux-timing-category">手札のITEM${tiles(known)}</div>`:''}${abilities.length?`<div class="ux-timing-category">MAIN・SUPPORT能力${tiles(abilities)}</div>`:''}${options.length?'':'<p class="ux-timing-empty">この探索で使える追加公開・引き直しはないよ。今の3枚からCAPTURE／METAを選ぼう。</p>'}<p class="ux-timing-note">使うかどうかは任意。ITEMは効果を確定したときだけ消費される。<strong>「カードを見る」では使わない。</strong></p></section>`;
}
function chooseTribeForItem(previous=null){
 const tribes=['蟲種','樹種','胞子種','獣種','鱗種','水棲種','始原種','未知種'];
 if(previous)return Promise.resolve(previous);
 return new Promise(resolve=>{
   const box=show('I02｜探す種族を選ぼう',`<p>公開カードにない種族を宣言すると、最大2枚まで引き直せるよ。</p><div class="ux-tribe-options">${tribes.map((s,i)=>`<button type="button" class="btn secondary" data-tribe="${i}">${s}</button>`).join('')}</div>${b('戻る','tribecancel','ghost')}`);
   box.querySelectorAll('[data-tribe]').forEach(el=>el.onclick=()=>{const n=Number(el.dataset.tribe);close();resolve(tribes[n]);});
   box.querySelector('[data-action=tribecancel]').onclick=()=>{close();resolve(null)};
   box.querySelector('#close-dialog').onclick=()=>{close();resolve(null)};
 });
}
async function useExploreTiming(kind,id,copySourceId=null){if(kind==='pheromone')return revisedPheromone(id);
 const r=current();if(!r||r.explore?.owner!==0)return toast('探索中だけ使える効果だよ');
 const opt=E.exploreTimingOptions(r,0).find(x=>x.kind===kind&&x.id===id&&(!copySourceId||x.copySourceId===copySourceId));
 if(!opt||!opt.ready)return toast('今は使用できないよ：'+(opt?.reason||'タイミングを確認してね'));
 if(kind==='copy_hand_more'){
  const source=opt.copySourceId;
  confirm('HAND COPYで探索を追加する？',`${esc(m(id).name)}を捨て、${esc(m(source).name)}のMAIN能力をCOPYして${opt.amount?`野生カードを${opt.amount}枚追加公開する。`:'探索終了後に1枚引き、1枚捨てる。'}`,()=>commit({type:'explore_more',sourceId:id,copyHandId:id,copySourceId:source}));
  return;
 }
 if(kind==='copy_more'){
  const source=opt.copySourceId;
  confirm('探索能力をCOPYする？',`${esc(m(id).name)}で${esc(m(source).name)}のMAIN能力をCOPYし、野生カードを${opt.amount}枚追加公開する。`,()=>commit({type:'explore_more',sourceId:id,copySourceId:source}));
  return;
 }
 if(kind==='more'){
  confirm('追加公開する？',`${esc(m(id).name)}：${esc(m(id).effect|| (who().main===id?m(id).main:m(id).support))}<br>野生カードを${opt.amount}枚追加で公開する。${opt.item?'<strong>実行時にITEMを除外。</strong>':'同じ探索では同じ能力をもう一度使えない。'}`,()=>commit({type:'explore_more',sourceId:id}));
  return;
 }
 if(kind==='redraw'||kind==='copy_hand_redraw'){
  let species;
  if(m(id).id==='I02'){
    species=await chooseTribeForItem(r.explore.redrawSpecies?.[id]);
    if(!species)return;
    if(r.explore.ids.some(x=>m(x).species===species))return toast('その種族はすでに公開中。別の種族を選んでね');
  }
  const selected=await pick('入れ替えたい公開カードを1枚選択',r.explore.ids,{info:`${m(id).name}の効果で公開1枚を引き直す。カードを見てから選んでね。`});
  if(!selected)return;
  confirm('引き直しを確定',`${esc(m(id).name)}で${esc(m(selected[0]).name)}を山札の底へ戻して1枚公開。${opt.item&&!(r.explore.redrawCount?.[id])?'このITEMは使用時に除外される。':''}`,()=>commit({type:'explore_redraw',sourceId:id,id:selected[0],species,...(kind==='copy_hand_redraw'?{copyHandId:id,copySourceId:opt.copySourceId}:{})}));return;
 }
 if(kind==='item'){
  confirm('探索後ITEMを使用',`${esc(m(id).name)}：${esc(m(id).effect)}<br>効果を処理し、ITEMを除外する。`,()=>commit({type:'use_item',id}));
 }
}
function choicesPanel(r,p){if(!r.explore||r.explore.owner!==0)return '';
 if(!r.explore.ids.includes(focusId))focusId=r.explore.ids[0];
 const count=E.exploreTimingOptions(r,0).filter(o=>o.ready).length;
 return `${count?`<div class="ux-timing-banner"><strong>✨ この探索で使えるITEM・能力が ${count} 件あるよ</strong><button type="button" data-action="timing_focus">確認して使う ↓</button></div>`:''}<section class="ux-panel"><div class="ux-panel-heading"><b>探索したCREATURE ${r.explore.ids.length}枚</b><small>カードを読むだけではACTION消費なし</small></div><div class="ux-candidates">${r.explore.ids.map(id=>candidateTile(id,id===focusId)).join('')}</div></section>${timingPanel(r,p)}`;}

// v0.9 BATTLE BOARD: visual-only composition. No rule/action engine replacement.
function v9Card(id,role,p,emptyName='空き枠'){
 if(!id)return `<div class="v9-slot v9-slot-empty"><div class="v9-slot-label">${esc(role)}</div><div class="v9-empty-mark">＋</div><small>${esc(emptyName)}</small></div>`;
 const c=m(id), ability=role==='MAIN'?c.main:c.support;
 return `<div class="v9-slot v9-slot-filled ${role==='MAIN'?'v9-main-slot':''}"><span class="v9-slot-label">${esc(role)}</span><button class="v9-slot-card" data-card="${esc(id)}" title="${esc(c.name)}を拡大" aria-label="${esc(role)}・${esc(c.name)}の詳細を見る"><img src="${img(id)}" loading="lazy" alt="${esc(c.name)}"><span class="v9-card-name">${esc(c.name)}</span></button><span class="v9-role-hint" title="${esc(ability||'印刷能力なし')}">${esc((ability||'能力なし').replace(/^(MAIN|SUPPORT)\s*[｜:：]\s*/,''))}</span></div>`;
}
function v9Formation(p){
 const sequence=[{id:p.support?.[0],role:'SUPPORT 1',active:'SUPPORT'},{id:p.main,role:'MAIN',active:'MAIN'},{id:p.support?.[1],role:'SUPPORT 2',active:'SUPPORT'}];
 return `<div class="v9-formation">${sequence.map(x=>v9Card(x.id,x.active,p,x.role)).join('')}</div>`;
}
function v95TotalPower(p){return Math.max(0,Number(window.Bot?.power?.(p)||0));}
function v95TotalCapture(p){return Math.max(0,Number(window.Bot?.capScore?.(p,null)||0));}
function v95StatsBadge(p){
 const power=v95TotalPower(p),cap=v95TotalCapture(p);
 return `<span class="v95-stats-badge" aria-label="合計POWER ${power}、現在捕獲力 ${cap}" title="捕獲力は現在の編成・FIELDによる値。対象固有条件と使用ITEMは判定時に反映"><span class="v95-stat v95-stat-power"><small>合計POWER</small><strong>${power}</strong></span><span class="v95-stat v95-stat-cap"><small>捕獲力</small><strong>${cap}</strong></span></span>`;
}
function v95RivalStats(p){
 const power=v95TotalPower(p),cap=v95TotalCapture(p);
 return `<span class="v95-rival-stats" aria-label="POWER ${power}、捕獲力 ${cap}"><span><i>PWR</i><b>${power}</b></span><span><i>CAP</i><b>${cap}</b></span></span>`;
}
function v9OppPicker(r){
 return r.players.slice(1).map((q,i)=>`<button type="button" class="v9-rival-chip ${viewedCPUSeat===q.seat?'selected':''} ${r.seat===q.seat?'v9-turn-cpu':''}" data-view-cpu="${q.seat}" aria-pressed="${viewedCPUSeat===q.seat?'true':'false'}"><b>CPU ${i+1}</b><span>L${q.level}${q.returning?'・帰還':''}</span>${v95RivalStats(q)}<small>手札${q.hand.length} / 仲間${Number(!!q.main)+q.support.length}</small></button>`).join('');
}
function v9OpponentPanel(r){
 const q=r.players[viewedCPUSeat]||r.players[1];
 const s=(q.status||[]).map(x=>`<span class="v9-status-tag">${esc(x)}</span>`).join('');
 return `<section class="v9-board v9-enemy" aria-label="CPUの公開盤面"><div class="v9-board-head"><div class="v9-name-block"><span class="v9-side-tag">OPPONENT / CPU ${viewedCPUSeat}</span><b>${esc(q.name.replace(' [CPU]',''))}</b></div><div class="v9-board-meta">${v95StatsBadge(q)}<span>L${q.level} ${esc(levels[q.level]||'')}${q.returning?' ↑':''}</span>${r.seat===q.seat?'<strong class="v9-turn-label">手番中</strong>':''}</div></div><div class="v9-public-chips"><span>▱ 手札 ${q.hand.length}枚（非公開）</span><span>山札 ${q.deck.length}</span><button type="button" data-public-discard="${q.seat}">捨て札 ${q.discard.length} ▸</button>${s}</div>${v9Formation(q)}<div class="v9-aux-info">${q.equip?.length?`装備 ${q.equip.length}枚 · `:''}GUARDIAN：${[2,3,4,5,6,7,8].filter(l=>q.guardian?.[String(l)]?.status!=='waiting').map(l=>'L'+l).join(' / ')||'未突破'}　<span>タップで実カードの能力を確認</span></div></section>`;
}
function v9SelfPanel(p){
 const buffs=(p.status||[]).map(x=>`<span class="v9-status-tag">${esc(x)}</span>`).join('');
 return `<section class="v9-board v9-self" aria-label="自分の公開盤面"><div class="v9-board-head"><div class="v9-name-block"><span class="v9-side-tag">YOU / YOUR CREATURES</span><b>${esc(p.name)}</b></div><div class="v9-board-meta">${v95StatsBadge(p)}<span>L${p.level} ${esc(levels[p.level]||'')}${p.returning?' ↑':''}</span></div></div><div class="v9-public-chips"><span>山札 ${p.deck.length}</span><button type="button" data-public-discard="0">捨て札 ${p.discard.length} ▸</button>${buffs}</div>${v9Formation(p)}${p.equip?.length?`<div class="v9-aux-info">装備中：${p.equip.map(id=>`<button type="button" class="v9-equip" data-card="${esc(id)}">${esc(m(id).name)}</button>`).join(' ')}</div>`:''}</section>`;
}
function v9Hand(p){
 return `<section class="v9-hand-panel" aria-label="自分の手札"><div class="v9-hand-head"><b>YOUR HAND <span>${p.hand.length}枚</span></b><span>カードをタップ → 詳細を見る（消費なし）</span></div><div class="v9-hand-scroller">${p.hand.map(id=>ccard(id,'hand')).join('')||'<p class="v9-hand-empty">手札なし。CAMPで補充できるよ。</p>'}</div></section>`;
}
function v9Toolbar(r,p){
 const phase=r.phase,exp=r.explore?.owner===0;
 if(!humanTurn())return `<div class="v9-toolbar-wait"><span class="v9-spin">◌</span> CPUが行動中…</div>`;
 if(phase==='DRAFT')return smartBtn('初期MAINを選ぶ','draft','primary');
 if(phase==='CHECK')return smartBtn('GUARDIAN CHECK','check','primary');
 if(phase==='START')return smartBtn('編成を変更','formation','secondary')+(E.startAbilityEligible(r,p.seat,'C173')&&p.status?.length&&!r.startStatusCleanseUsed?.[String(p.seat)]?b('白脱皮：STATUS解除','startcleanse','secondary'):'')+smartBtn('START完了','startdone','primary');
 if(phase==='FINISHED')return '';
 if(r.fieldDiscardPending?.owner===0)return smartBtn('L5：手札1枚を捨てる','field','primary');
 if(exp)return b('CAPTURE','viewcapture','primary')+b('META','viewmeta','secondary')+b('使えるITEM','timing_focus','secondary')+b('手番','viewturn','ghost');
 return smartBtn('探索','explore','primary')+smartBtn('補給','buy','secondary')+smartBtn('移動','move','secondary')+smartBtn('CAMP','camp','secondary');
}
function v9PublicDiscard(seat){
 const r=current(),p=r?.players?.[seat];if(!p)return;
 const ids=p.discard||[];
 const box=show(`${p.name}｜公開の捨て札`, `<p>捨て札 ${ids.length}枚。カードをタップすると能力全文を表示するよ。山札の順番は非公開。</p><div class="cards catalog-cards">${ids.map(id=>ccard(id,'small')).join('')||'<p>捨て札は空だよ。</p>'}</div>`);
 box.querySelectorAll('[data-card]').forEach(el=>el.onclick=()=>showCard(el.dataset.card,{onBack:()=>v9PublicDiscard(seat)}));
}
// v0.9.2: one decision at a time. This layer never changes card/rule data.
let lastAutoCPU=null;
const standaloneItems=new Set(['SI04','I16','I07','I27','I28','I29','I30','I31','I32','I33','I34','I35','I36','I18','I21','I37','I40']);
const captureItems=new Set(['SI02','I08','I09','I11','I12','I13','I14']);
const metaItems=new Set(['I22','I23','I24','I25','I26']);
const reactionItems=new Set(['I10','I15','I17','I19','I20','I38','I39']);
const pendingForHuman=()=>{const r=current();return r?.interruptPending?.window.owner===0?'interrupt':r?.targetEffectPending?.owner===0?'target_effect':r?.supportDisablePending?.owner===0?'support_disable':r?.statusSacrificePending?.owner===0?'status_sacrifice':r?.statusCleansePending?.owner===0?'status_cleanse':r?.pendingAttack?.target===0?'reaction':r?.effectPending?.owner===0?'effect':r?.fieldDiscardPending?.owner===0?'field':null;};
function uiGate(action,extra={}){
 const pending=pendingForHuman();
 if(pending)return {ok:false,reason:(pending==='reaction'||pending==='interrupt')?'先にREACTIONを選んでね':pending==='effect'?'先にカード効果を解決してね':'先に灼熱FIELDの破棄を解決してね'};
 return gateFor(action,extra);
}
function uiButton(label,action,{primary=false,gate=null,hint='',id=''}={}){
 const state=gate||{ok:true,reason:''};
 return `<button type="button" ${id?`id="${id}"`:''} class="v091-button ${primary?'is-primary':''}" data-action="${esc(action)}" ${state.ok?'':'disabled aria-disabled="true"'}><strong>${esc(label)}</strong>${hint||!state.ok?`<small>${esc(!state.ok?state.reason:hint)}</small>`:''}</button>`;
}
function routeStep(tab){activeTab=tab;render();}
function v91Menu(){
 const box=show('メニュー',`<div class="v091-menu"><div class="v091-menu-group"><h3>確認する</h3>${b('ルールブック','rulebook','ghost')}${b('カード図鑑','catalog','ghost')}${b('行動ログ','v91_log','ghost')}${b('この版の対応範囲','v91_limits','ghost')}</div><div class="v091-menu-group"><h3>学ぶ・使う</h3>${b('チュートリアル','tutorial','ghost')}${b('シナジーの練習','synergy_tutorial','ghost')}${b('ITEM・HANDを確認','v91_effects','ghost')}${b('判定メモ','manual','ghost')}</div><div class="v091-menu-group"><h3>保存・設定</h3>${b('セーブを書き出す','export','ghost')}${b('セーブを読み込む','import','ghost')}${b(delay===320?'CPUを高速にする':'CPUを標準速度にする','speed','ghost')}${b('演出：'+(window.RinneFx?.isEnabled()?'ON':'OFF'),'fx_toggle','ghost')}${b('演出を試す','fx_preview','ghost')}${b('最初からやり直す','reset','ghost')}</div></div>`);
 box.querySelectorAll('[data-action]').forEach(el=>el.onclick=()=>{close();route(el.dataset.action);});
}
function showFxPreview(){
 const options=[['capture','捕獲'],['meta','進化'],['guardian','GUARDIAN突破'],['level','階層移動']];
 const box=show('冒険の演出',`<p>各演出は約1.8秒。ゲームを動かさず、演出だけを試せるよ。動きを減らす端末設定にも対応。</p>${!window.RinneFx?.isEnabled()?b('演出をONにする','enable_fx','primary'):''}<div class="modal-actions">${options.map(([kind,label])=>b(label,kind,'secondary')).join('')}</div><p>ガーディアン登場（約1.8秒）</p><div class="modal-actions">${b('登場演出を試す','guardian_entry','secondary')}</div><p>階層シンボル（約1.8秒・キラキラ）</p><div class="modal-actions fx-symbol-choices">${Array.from({length:9},(_,lv)=>b(lv===0?'WORLD':`L${lv} ${window.RinneSymbols?.names[lv]||''}`,'symbol_'+lv,'secondary')).join('')}</div>`);
 box.querySelector('[data-action=guardian_entry]').onclick=()=>{if(!window.RinneFx?.isEnabled())return toast('演出をONにしてから試せるよ');close();window.RinneFx?.preview('guardian_entry');};
 box.querySelector('[data-action=enable_fx]')?.addEventListener('click',()=>{window.RinneFx?.setEnabled(true);close();showFxPreview();});
 for(let lv=0;lv<=8;lv++)box.querySelector(`[data-action="symbol_${lv}"]`).onclick=()=>{if(!window.RinneFx?.isEnabled())return toast('演出をONにしてから試せるよ');window.RinneSymbols?.unlockAudio();close();window.RinneSymbols?.preview(lv);};
 for(const [kind] of options)box.querySelector(`[data-action="${kind}"]`).onclick=()=>{if(!window.RinneFx?.isEnabled())return toast('演出をONにしてから試せるよ');close();window.RinneFx?.preview(kind);};
}
function effectAvailability(id){
 const r=current(),p=who(),c=m(id),code=c.id;
 const no=(reason,kind='later')=>({ok:false,reason,kind});
 if(!r||!p||!p.hand.includes(id))return no('手札にないカード');
 const item=['SUPPLY','START ITEM'].includes(c.kind),hand=String(c.other||'').includes('HAND');
 if(!item&&!hand)return no('手札で直接使う効果ではありません');
 if((item&&!E.itemSupported(id))||(hand&&!E.handEffects.has(code)&&!(E.handCopyActionOptions?.(r,0,id).length||E.handAttackOptions?.(r,0,id).length)))return no('この効果はデジタル版では未対応','unsupported');
 if(pendingForHuman())return no('先に発生中の効果・REACTIONを解決');
 if(!humanTurn())return no('自分の手番で確認。REACTIONは発生時に案内');
 if(!['START','ACTIONS'].includes(r.phase))return no('現在の処理が終わってから使います');
 if(hand){
   if(code==='C005'&&!p.status.length)return no('MAINに解除できるSTATUSがありません');
   if(['C067','C140'].includes(code))return no('ITEM使用後に選択します');
   if(p.actedHand)return no('この手番のHANDは使用済み');
   if(code==='C035'&&!p.discard.length)return no('戻せる捨て札がありません');
   return {ok:true,reason:['C079','C154','C181'].includes(code)?'HAND COPY · 元能力のコストを適用':'HAND · ACTION消費なし',kind:'hand'};
 }
 if(r.explore?.owner===0){const op=E.exploreTimingOptions(r,0).find(o=>o.id===id);if(op)return {ok:op.ready,reason:op.ready?op.label:op.reason,kind:'timing',op};}
 if(code==='I28'&&r.explore?.source==='wild')return {ok:true,reason:'公開カードを最大2枚引き直す',kind:'item'};
 if(captureItems.has(code))return no('CAPTUREのITEM選択で提示されます');
 if(metaItems.has(code))return no('METAの素材選択後に提示されます');
 if(reactionItems.has(code))return no('対応する出来事のREACTIONで提示されます');
 if(!standaloneItems.has(code))return no('探索で候補を公開した時に提示されます');
 if(['SI04','I16'].includes(code)&&!p.status.length)return no('解除するSTATUSがありません');
 if(code==='I07'&&r.explore?.owner!==0)return no('探索の候補を公開した後に使います');
 if(['I18','I21'].includes(code)&&!p.main)return no('装備先のMAINがいません');
 if(['I27','I28','I29','I30','I31'].includes(code)&&!(code==='I28'&&r.explore?.source==='wild')){
   const qs=r.players.slice(1).filter(q=>q.level===p.level);
   if(!qs.length)return no('同じLEVELの相手がいません');
   if(code==='I28'&&r.explore?.source!=='wild'&&!qs.some(q=>q.stray.length))return no('同じLEVELの相手に遊動個体がありません');
   if(code==='I29'&&!qs.some(q=>q.support.some(id=>!q.disabledSupportIds?.includes(id)&&!!m(id).support)))return no('無効化できるSUPPORT能力がありません');
   
 }
 if(code==='I36'&&p.hand.length<2)return no('対象にする別の手札がありません');
 if(code==='I35'&&!r.removedItems?.some(x=>['SUPPLY','START ITEM'].includes(m(x).kind)&&r.usedItemOwners?.[x]===p.seat))return no('自分が使用して除外したITEMがありません');
 return {ok:true,reason:c.timing==='EQUIP'?'MAINへ装備':'FREE · ACTION消費なし',kind:'item'};
}
function effectEntries(){
 const p=who();if(!p)return [];
 return p.hand.filter(id=>['SUPPLY','START ITEM'].includes(m(id).kind)||String(m(id).other||'').includes('HAND')).map(id=>({id,...effectAvailability(id)}));
}
function groupEffects(entries){
 const map=new Map();for(const x of entries){const k=m(x.id).id+'|'+x.ok+'|'+x.reason;if(!map.has(k))map.set(k,{...x,count:0});map.get(k).count++;}return [...map.values()];
}
function v91EffectDrawer(){
 if(current()?.explore?.owner===0)return v91ExploreEffects();
 const all=groupEffects(effectEntries()),ready=all.filter(x=>x.ok),later=all.filter(x=>!x.ok);
 const tile=x=>`<div class="v091-effect-row"><button type="button" class="v091-effect-art" data-effect-card="${esc(x.id)}" aria-label="${esc(m(x.id).name)}の詳細"><img src="${img(x.id)}" alt="${esc(m(x.id).name)}"></button><div><b>${esc(m(x.id).name)}${x.count>1?` <small>×${x.count}</small>`:''}</b><p>${esc(m(x.id).effect||m(x.id).other||'')}</p><small>${esc(x.reason)}</small></div>${uiButton(x.ok?'使う':x.kind==='unsupported'?'未対応':'待機','none',{gate:x}) .replace('data-action="none"',`data-effect-use="${esc(x.id)}"`)}</div>`;
 const box=show('ITEM・HAND',`<p class="v091-quiet">いま使えるものから表示。確認だけでは消費しません。</p><div class="v091-effect-list">${ready.map(tile).join('')||'<p class="v091-empty-note">今、この場面で使える効果はありません。</p>'}</div>${later.length?`<details class="v091-fold"><summary>ほかのタイミング・未対応 ${later.length}種類</summary>${later.map(tile).join('')}</details>`:''}`);
 box.querySelectorAll('[data-effect-card]').forEach(el=>el.onclick=()=>showCard(el.dataset.effectCard,{onBack:v91EffectDrawer}));
 box.querySelectorAll('[data-effect-use]').forEach(el=>el.onclick=()=>{const id=el.dataset.effectUse,st=effectAvailability(id);if(!st.ok)return;close();if(st.kind==='hand')useHandById(id);else useItemById(id);});
}
function v91ExploreEffects(){
 const r=current(),p=who();if(r?.explore?.owner!==0)return v91EffectDrawer();
 const available=E.exploreTimingOptions(r,0);
 // Different physical copies remain individually usable; group only identical unused copies in the list.
 const map=new Map();for(const op of available){const k=m(op.id).id+'|'+op.kind+'|'+(op.copySourceId||'')+'|'+op.ready+'|'+op.reason;if(!map.has(k))map.set(k,{...op,count:0});map.get(k).count++;}
 const ops=[...map.values()],ready=ops.filter(x=>x.ready),later=ops.filter(x=>!x.ready);
 const tile=x=>{const c=m(x.id);return `<div class="v091-effect-row"><button type="button" class="v091-effect-art" data-explain="${esc(x.id)}" aria-label="${esc(c.name)}の詳細"><img src="${img(x.id)}" alt="${esc(c.name)}"></button><div><b>${esc(c.name)}${x.count>1?` <small>×${x.count}</small>`:''}</b><p>${esc(x.label)}</p><small>${esc(x.ready?x.item?'ITEM · 確定時に消費':'編成中の能力':x.reason)}</small></div><button type="button" class="v091-effect-use" data-context="${esc(x.kind)}" data-source="${esc(x.id)}" data-copy-source="${esc(x.copySourceId||'')}" ${x.ready?'':'disabled aria-disabled="true"'}>${x.ready?'使う':'待機'}</button></div>`;};
 const box=show('この探索で使える効果',`<p class="v091-quiet">追加公開・引き直しは任意。使わずに候補を選んでも大丈夫。</p>${ready.map(tile).join('')||'<p class="v091-empty-note">追加公開・引き直しに使える効果はありません。</p>'}${later.length?`<details class="v091-fold"><summary>使用済み・条件未達 ${later.length}種類</summary>${later.map(tile).join('')}</details>`:''}<div class="v091-effect-other">${b('手札の別の効果を確認','other','ghost')}</div>`);
 box.querySelectorAll('[data-explain]').forEach(el=>el.onclick=()=>showCard(el.dataset.explain,{onBack:v91ExploreEffects}));
 box.querySelectorAll('[data-context]').forEach(el=>el.onclick=()=>{close();useExploreTiming(el.dataset.context,el.dataset.source,el.dataset.copySource||null);});
 box.querySelector('[data-action=other]').onclick=()=>{
  // Access to other legal FREE/HAND effects is retained; not falsely presented as exploration boosts.
  const all=groupEffects(effectEntries().filter(x=>x.kind!=='timing'));
  const inner=show('手札のほかの効果',`<p>捕獲・META・REACTION専用のカードは、その手順で提示されます。</p>${all.map(x=>`<div class="v091-simple-effect"><button type="button" data-read="${esc(x.id)}">${esc(m(x.id).name)}</button><small>${esc(x.reason)}</small><button type="button" class="btn" data-free-use="${esc(x.id)}" ${x.ok?'':'disabled'}>使う</button></div>`).join('')||'<p>該当するカードはありません。</p>'}`);
  inner.querySelectorAll('[data-read]').forEach(el=>el.onclick=()=>showCard(el.dataset.read,{onBack:v91ExploreEffects}));
  inner.querySelectorAll('[data-free-use]').forEach(el=>el.onclick=()=>{const id=el.dataset.freeUse,st=effectAvailability(id);if(!st.ok)return;close();if(st.kind==='hand')useHandById(id);else useItemById(id);});
 };
}
function v91ContextLink(){
 const r=current(),p=who();if(!r||!p)return '';
 const entries=effectEntries(),count=entries.filter(x=>x.ok).length;
 if(!entries.length)return '';
 return `<button type="button" class="v091-effect-link" data-action="v91_effects">ITEM・HAND${count?` <span>${count}枚 使用可</span>`:' <small>タイミングを確認</small>'}</button>`;
}
function v91ExploreLink(){
 const r=current();if(r.explore?.owner!==0)return '';
 const count=E.exploreTimingOptions(r,0).filter(o=>o.ready).length;
 return `<button type="button" class="v091-context-hint ${count?'has-effects':''}" data-action="v91_effects"><span>${count?'追加公開・引き直しができます':'探索中の効果を確認'}</span><b>${count?`${count}件`:'0件'} ›</b></button>`;
}
function v91Method(){
 const r=current(),p=who(),id=focusId,c=m(id),base=Bot.capScore(p,id);
 const mats=[...p.hand,...(p.main?[p.main]:[]),...p.support].filter(x=>isCreature(x)&&m(x).species===c.species);
 const canMeta=mats.length>=2&&String(c.meta||'').trim()!==''&&Number.isFinite(Number(c.meta));
 return `<div class="v091-method-card"><button data-card="${esc(id)}" aria-label="${esc(c.name)}の能力を見る"><img src="${img(id)}" alt="${esc(c.name)}"></button><div><h3>${esc(c.name)}</h3><p>${esc(c.species)}</p><p>必要CAP <b>${esc(c.cap)}</b> <span>／ META <b>${esc(c.meta)}</b></span></p><small>カードをタップで能力全文</small></div></div>${v91ExploreLink()}<div class="v091-methods">${uiButton('捕獲する · CAPTURE','v91_capture',{primary:true,hint:`現在の捕獲力 ${base} ／ ITEMは次に選択`})}${uiButton('進化させる · META','v91_meta',{gate:{ok:canMeta,reason:'同じ印刷種族の素材2体以上が必要'},hint:`同種族の素材候補 ${mats.length}体`})}</div><p class="v091-quiet">対象・編成・状態を反映した捕獲力です。ITEMとCOPYは次に選択。</p>`;
}
function v91Candidate(id){const c=m(id);return `<article class="v091-choice-card"><button type="button" class="v091-choice-art" data-card="${esc(id)}" aria-label="${esc(c.name)}の能力を見る"><img src="${img(id)}" alt="${esc(c.name)}"></button><b>${esc(c.name)}</b><small>CAP ${esc(c.cap)} · META ${esc(c.meta)}</small><button type="button" class="v091-select" data-candidate="${esc(id)}">この1体にする</button></article>`;}
function v91Workspace(){
 const r=current(),p=who();if(!r||!humanTurn()||pendingForHuman()||r.phase!=='ACTIONS')return '';
 let tab=activeTab;
 if(r.explore?.owner===0&&tab!=='turn'&&!['capture','method'].includes(tab))tab='capture';
 if(tab==='method'&&!r.explore?.ids?.includes(focusId))tab='capture';
 if(!r.explore&&['capture','method'].includes(tab))return '';
 if(tab==='turn')return '';
 let title='',label='',body='',back='v91_board',backLabel='盤面に戻る',footer='';
 if(tab==='actions'){
  title='何をする？';label='1つの行動を選択';
  const guarded=!p.returning&&p.level>=2&&p.level<=8,move=guarded?'guardian':'move';
  body=`<div class="v091-action-grid">${uiButton('探索する','explore',{primary:true,gate:uiGate('explore'),hint:'生き物を探す · 1 ACTION'})}${uiButton('補給する','v91_supply',{gate:uiGate('buy'),hint:'ITEMを買う · 1 ACTION'})}${uiButton(guarded?'GUARDIANに挑む':p.returning?'地上へ帰還する':'階層を進む',move,{gate:uiGate(move),hint:guarded?'移動の挑戦 · 1 ACTION':'移動 · 1 ACTION'})}${uiButton('妨害する','v91_interfere',{gate:(uiGate('interfere').ok||uiGate('pushback').ok)?{ok:true}:uiGate('interfere'),hint:'相手の進行を妨げる'})}</div>`;
  if(E.mainDrawCycleProfile(r,p)?.available||E.handEventOptions(r,0,{type:'main_draw_cycle'}).some(o=>o.code==='C186'))body+=uiButton('MAINの手札交換を使う','main_draw_cycle',{hint:'条件成立・このターン1回'});
  footer=`<p class="v091-quiet">使うITEM・HANDは、手札の「ITEM・HAND」から確認できます。</p>`;
 } else if(tab==='capture'){
  title='どの生き物を選ぶ？';label='探索 1 / 2 · 候補を選ぶ';
  body=`${v91ExploreLink()}<div class="v091-candidates">${r.explore.ids.map(v91Candidate).join('')}</div><p class="v091-quiet">カード画像＝能力を見る ／ 下のボタン＝候補に選ぶ</p>`;
  footer=`<button type="button" class="v091-text-button" data-action="v91_skip">今回は獲得せず、探索を終える</button>`;
 } else if(tab==='method'){
  title='どうやって仲間にする？';label='探索 2 / 2 · 手段を選ぶ';back='v91_candidates';backLabel='候補を選び直す';body=v91Method();
 } else if(tab==='supply'){
  title='どのITEMを買う？';label=`補給 · 公開${r.market.length}枚`;back='v91_actions';backLabel='行動に戻る';
  body=`<p class="v091-quiet">画像で効果を確認。購入は次の画面で支払うカードを選んでから。</p><div class="v091-candidates">${r.market.map(id=>{const c=m(id),g=uiGate('buy',{id});return `<article class="v091-choice-card"><button type="button" class="v091-choice-art" data-card="${esc(id)}" aria-label="${esc(c.name)}の効果を見る"><img src="${img(id)}" alt="${esc(c.name)}"></button><b>${esc(c.name)}</b><small>COST ${esc(c.cost)}</small><button type="button" class="v091-select" data-buy="${esc(id)}" ${g.ok?'':'disabled aria-disabled="true"'}>${g.ok?'このITEMにする':'手札不足'}</button></article>`;}).join('')}</div>`;
 } else return '';
 return `<div class="v091-task-shade" id="v091-task" role="dialog" aria-modal="true" aria-labelledby="v091-task-title"><section class="v091-task-sheet"><header class="v091-task-head"><button type="button" class="v091-back" data-action="${back}">‹ ${backLabel}</button><small>${esc(label)}</small><h2 id="v091-task-title">${esc(title)}</h2></header><div class="v091-task-body">${body}</div>${footer?`<footer class="v091-task-foot">${footer}</footer>`:''}</section></div>`;
}
function v91Dock(r,p){
 const pending=pendingForHuman();
 if(pending)return uiButton(pending==='reaction'?'REACTIONを選ぶ':pending==='field'?'灼熱の手札破棄を選ぶ':'追加効果のカードを選ぶ','v91_pending',{primary:true});
 if(!humanTurn())return '<div class="v091-wait" role="status">CPUの手番中<span>盤面のカードはいつでも確認できます</span></div>';
 if(r.phase==='DRAFT')return uiButton('最初のMAINを選ぶ','draft',{primary:true});
 if(r.phase==='CHECK')return uiButton('GUARDIAN CHECKへ','check',{primary:true});
 if(r.phase==='START')return uiButton('編成を変更','formation')+(E.startAbilityEligible(r,p.seat,'C173')&&p.status?.length&&!r.startStatusCleanseUsed?.[String(p.seat)]?b('白脱皮：STATUS解除','startcleanse','secondary'):'')+uiButton('この編成で進む','startdone',{primary:true});
 if(r.phase==='FINISHED')return '';
 if(r.explore?.owner===0)return uiButton('探索を続ける','v91_continue',{primary:true,hint:'公開したカードから1体を選ぶ'});
 const gate={ok:r.actionPoints>0,reason:'残りACTIONが0'};
 return uiButton('行動する','v91_actions',{primary:true,gate,hint:r.actionPoints>0?`残り ${r.actionPoints} ACTION`:''})+(E.mainProfile(r,p,['C012'])?uiButton('CREATUREを渡す','give_creature',{gate,hint:'同LEVELの相手の捨て札へ · 1 ACTION'}):'')+uiButton('CAMPへ進む','camp',{gate:uiGate('camp'),hint:'残す手札を選んで手番を終える'});
}
function v91Stage(r,p){
 const goal=goalFor(r,p),pending=pendingForHuman();
 const phaseLabel=pending?'効果を解決中':!humanTurn()?'CPUの手番':r.explore?'探索を解決中':({START:'START · 編成',CHECK:'GUARDIAN CHECK',DRAFT:'最初の仲間',ACTIONS:'あなたの手番',FINISHED:'対戦終了'}[r.phase]||r.phase);
 return `<section class="v091-goal" aria-label="次の目標"><div class="v091-phase"><span>${esc(phaseLabel)}</span>${humanTurn()&&r.phase==='ACTIONS'?`<b>● ${r.actionPoints} / 2 ACTION</b>`:''}</div>${window.RinneDepth?.locationMarkup(p)||''}<div class="v091-goal-body"><div><h1>${esc(goal.title)}</h1></div><span class="v091-progress">${esc(goal.now)}</span></div></section>`;
}
async function route(cmd){
 const r=current(),p=who();
 if(cmd==='v91_menu'){v91Menu();return;}
 if(cmd==='v91_board'){routeStep('turn');return;}
 if(cmd==='v91_actions'){if(!r||!humanTurn()||r.phase!=='ACTIONS'||r.actionPoints<=0||r.explore||pendingForHuman())return;routeStep('actions');return;}
 if(cmd==='v91_supply'){if(uiGate('buy').ok)routeStep('supply');return;}
 if(cmd==='v91_candidates'){focusId=null;routeStep('capture');return;}
 if(cmd==='v91_continue'){routeStep(focusId?'method':'capture');return;}
 if(cmd==='v91_capture'){if(r?.explore?.ids?.includes(focusId))captureDialog(focusId);return;}
 if(cmd==='v91_meta'){if(r?.explore?.ids?.includes(focusId))metaDialog(focusId);return;}
 if(cmd==='v91_effects'||cmd==='timing_focus'||cmd==='item'||cmd==='hand'){v91EffectDrawer();return;}
 if(cmd==='v91_skip'){
  const id=r?.explore?.ids?.[0];if(!id)return;
  confirm('この探索を終える？','公開したカードは獲得しません。使用したACTION・ITEMは戻りません。',()=>commit({type:'explore_resolve',id,method:'SKIP'}));return;
 }
 if(cmd==='v91_pending'){handlePendingField();handlePendingEffects();return;}
 if(cmd==='v91_interfere'){
  const normal=uiGate('interfere'),push=uiGate('pushback');
  if(!push.ok){if(normal.ok)command('interfere');return;}
  const box=show('妨害の方法',`<p>帰還中の相手には押し戻しを選べます。</p><div class="v091-methods">${uiButton('MAINの妨害能力','interfere',{gate:normal,hint:'1 ACTION'})}${uiButton('RETURN押し戻し','pushback',{gate:push,hint:'2 ACTION ＋ 手札CREATURE1枚'})}</div>`);
  box.querySelectorAll('[data-action]').forEach(el=>el.onclick=()=>{close();command(el.dataset.action);});return;
 }
 if(cmd==='v91_log'){
  show('行動ログ',`<div class="v091-logs">${(r?.log||[]).slice(0,40).map(x=>`<p>${esc(x.msg)}</p>`).join('')}</div>`);return;
 }
 if(cmd==='v91_limits'){
  show('v0.9.5の対応範囲','<p><b>325枚の最新版カード</b>、合計POWER / 捕獲力HUD、ITEM R2（初期7枚／市場3枚）、L2〜L8の担当GUARDIAN、即時CHECK、L8最終試練統合を反映しています。</p><p>COPY・一部の複雑なHAND / DISCARD連鎖・REACTION・種族変更など、完全自動化していない能力は残っています。表示上「未対応」とある場合も、ルール上禁止という意味ではありません。</p><p>カード本文を優先し、判断が必要な局面は判定メモを使ってください。</p>');return;
 }
 if(cmd==='buy'){routeStep('supply');return;}
 if(cmd==='explore'){
  if(!uiGate('explore').ok)return;
  if(p.stray?.length){
   const box=show('探索する場所',`<p>新しい候補を探すか、自分の前の遊動個体を追跡できます。</p>${b('野生山札から新しく探索','fresh','primary')}<div class="cards">${p.stray.map(id=>`<div>${ccard(id,'small')}<button class="btn" data-stray="${esc(id)}">追跡する</button></div>`).join('')}</div>`);
   box.querySelector('[data-action=fresh]').onclick=()=>{close();commit({type:'explore'});};
   box.querySelectorAll('[data-card]').forEach(el=>el.onclick=()=>showCard(el.dataset.card));
   box.querySelectorAll('[data-stray]').forEach(el=>el.onclick=()=>{close();commit({type:'explore_stray',id:el.dataset.stray});});return;
  }
 }
 if(['explore','formation','startdone','check','move','guardian','camp','interfere','pushback'].includes(cmd)&&!uiGate(cmd).ok)return toast(uiGate(cmd).reason);
 return command(cmd);
}
function render(){
 const r=current();if(!r){landing();return;}window.RinneStartBackground?.reset();
 const p=who();window.RinneDepth?.update(r);window.RinneSymbols?.observe(r);
 if(!humanTurn()&&lastAutoCPU!==r.seat){viewedCPUSeat=r.seat;lastAutoCPU=r.seat;}
 if(humanTurn())lastAutoCPU=null;
 if(viewedCPUSeat<1||viewedCPUSeat>3)viewedCPUSeat=1;
 if(!r.explore){focusId=null;if(['capture','method'].includes(activeTab))activeTab='turn';}
 if(r.explore&&focusId&&!r.explore.ids.includes(focusId))focusId=null;
 if(!humanTurn()||r.phase!=='ACTIONS')activeTab='turn';
 const workspace=v91Workspace();
 document.body.classList.toggle('v091-task-open',!!workspace);
 $('app').innerHTML=`<div id="v091-surface" ${workspace?'inert':''}><header class="v091-header"><div class="brand">RINNE<small>SOLO · v0.9.5</small></div><span class="v091-mode">${esc(r.mode)} · ITEM R2</span><button type="button" class="v091-menu-button" data-action="v91_menu" aria-label="メニューを開く">☰</button></header><main class="v9-world v091-world"><nav class="v9-rival-pickers" aria-label="表示するCPU">${v9OppPicker(r)}</nav>${v9OpponentPanel(r)}${v91Stage(r,p)}${v9SelfPanel(p)}<section class="v9-hand-panel"><header class="v9-hand-head"><b>手札 <span>${p.hand.length}枚</span></b>${v91ContextLink()}</header><div class="v9-hand-scroller">${p.hand.map(id=>ccard(id,'hand')).join('')||'<p class="v091-quiet">手札なし。CAMPで補充します。</p>'}</div></section><p class="v091-board-note">カードはタップで拡大。見るだけでは消費しません。</p></main><div class="v091-dock" aria-label="主な操作">${v91Dock(r,p)}</div></div>${workspace}${r.phase==='FINISHED'?`<div class="full-overlay"><div class="winner"><h1>${r.winner===0?'あなたの勝利！':'CPUの勝利！'}</h1><p>${esc(r.players[r.winner]?.name)} · ${esc(r.mode)}</p>${b('もう一度プレイ','restart','primary')}</div></div>`:''}`;
 $('app').querySelectorAll('[data-card]').forEach(el=>el.onclick=()=>showCard(el.dataset.card));
 $('app').querySelectorAll('[data-view-cpu]').forEach(el=>el.onclick=()=>{viewedCPUSeat=Number(el.dataset.viewCpu);render();});
 $('app').querySelectorAll('[data-public-discard]').forEach(el=>el.onclick=()=>v9PublicDiscard(Number(el.dataset.publicDiscard)));
 $('app').querySelectorAll('[data-candidate]').forEach(el=>el.onclick=()=>{focusId=el.dataset.candidate;routeStep('method');});
 $('app').querySelectorAll('[data-buy]').forEach(el=>el.onclick=()=>buyCard(el.dataset.buy));
 $('app').querySelectorAll('[data-action]').forEach(el=>el.onclick=()=>route(el.dataset.action));
 window.RinneFx?.observe(r);
 if(workspace&&$('modal').classList.contains('hide'))requestAnimationFrame(()=>$('v091-task')?.querySelector('button:not([disabled])')?.focus({preventScroll:true}));
}

async function useItemById(id){
 const r=current(),p=who(),c=m(id),code=c.id;
 if(!effectAvailability(id).ok)return toast(effectAvailability(id).reason);
 if(!E.itemSupported(id))return toast(`${c.name}はまだ自動化されていないため消費しないよ`);
 if(!['SI04','I16','I07','I27','I28','I29','I30','I31','I32','I33','I34','I35','I36','I18','I21','I37','I40'].includes(code))return toast('このITEMは探索・CAPTURE・META・REACTIONの専用画面から使ってね。ここでは消費しないよ');
 if(['I37','I40'].includes(code))return revisedGiftItem(id);
 if(code==='I28'&&r.explore?.source==='wild')return revisedPheromone(id);
 if(['SI04','I16'].includes(code)){
  if(!p.status.length)return toast('解除するSTATUSがないため使用できないよ');const modal=show('解除するSTATUSを選ぶ',`<div class="modal-actions">${p.status.map(st=>b(st,st,'secondary')).join('')}</div>`);
  p.status.forEach(st=>modal.querySelector(`[data-action="${st}"]`).onclick=()=>{close();commit({type:'use_item',id,status:st});});return;
 }
 if(['I27','I28','I29','I30','I31'].includes(code)){
  const targets=r.players.slice(1).filter(q=>q.level===p.level&&(code!=='I28'||q.stray.length)&&(code!=='I29'||q.support.some(id=>!q.disabledSupportIds?.includes(id)&&!!m(id).support)));if(!targets.length)return toast('同LEVELの対象がいない');
  const modal=show('ITEMの対象を選ぶ',`<p>${esc(c.effect||'')}</p><div class="modal-actions">${targets.map(q=>b(q.name,String(q.seat),'secondary')).join('')}</div>`);
  targets.forEach(q=>modal.querySelector(`[data-action="${q.seat}"]`).onclick=()=>{close();commit({type:'use_item',id,target:q.seat});});return;
 }
 if(code==='I32'||code==='I36'){
   const n=code==='I32'?2:1;const pool2=p.hand.filter(x=>x!==id);if(!pool2.length)return toast('対象の手札がない');const pay=await pick('ITEM効果：手札を選択',pool2,{min:code==='I32'?0:1,max:Math.min(n,pool2.length),info:esc(c.effect||'カードを選んでね')});if(pay)commit({type:'use_item',id,...(code==='I32'?{pay}:{card:pay[0]})});return;
 }
 if(code==='I34'){confirm('整理ケースを使う',`${esc(c.effect)}<br>使用後に山札へ戻す順番を選ぶ。`,()=>commit({type:'use_item',id}));return;}
 if(code==='I35'){const pool2=(r.removedItems||[]).filter(x=>['SUPPLY','START ITEM'].includes(m(x).kind)&&x!==id&&r.usedItemOwners?.[x]===p.seat);if(!pool2.length)return toast('自分が使用して除外したITEMがない');const choice=await pick('回収する除外ITEM',pool2,{info:'自分が使用して除外したITEM1枚を手札に戻す。緊急ポーチ自身は除外。'});if(choice)commit({type:'use_item',id,card:choice[0]});return;}
 confirm('ITEMを使用',`${esc(c.name)}：${esc(c.effect||'')}<br>使用後は除外。`,()=>commit({type:'use_item',id}));return;
}

async function useHandById(id){
 const r=current(),p=who(),c=m(id);
 if(!effectAvailability(id).ok)return toast(effectAvailability(id).reason);
 const attacks=E.handAttackOptions?.(r,0,id)||[];
 if(attacks.length){const box=show('HAND COPY｜妨害を選択',`<p>COPYカードを捨て、元の妨害を1 ACTIONで1回実行する。</p><div class="modal-actions">${attacks.map((o,i)=>o.targets.map(target=>b(m(o.sourceId).name+' → '+r.players[target].name,'hatk'+i+'_'+target,'secondary')).join('')).join('')}${b('他のHAND効果を選ぶ','other','ghost')}</div>`);
  const picked=await new Promise(resolve=>{attacks.forEach((o,i)=>o.targets.forEach(target=>box.querySelector(`[data-action="hatk${i}_${target}"]`).onclick=()=>{close();resolve({o,target});}));box.querySelector('[data-action=other]').onclick=()=>{close();resolve(null);};box.querySelector('#close-dialog').onclick=()=>{close();resolve(false);};});
  if(picked===false)return;if(picked){commit({type:'hand_copy_attack',id,sourceId:picked.o.sourceId,target:picked.target});return;}
 }
 const copies=E.handCopyActionOptions?.(r,0,id)||[];
 if(attacks.length&&!copies.length)return;
 if(copies.length){const selected=await pick('HAND COPYの元能力',copies.map(x=>x.sourceId),{info:'コピーカードを捨て、元能力のコストも支払って1回実行する。'});if(!selected)return;const option=copies.find(x=>x.sourceId===selected[0]);let extra={};
  if(option.code==='C012'){const target=await chooseOtherSeat('CREATUREを渡す相手',r.players.slice(1).filter(q=>q.level===p.level));if(target===null)return;const pay=await pick('渡すCREATURE',p.hand.filter(x=>x!==id&&['STARTER','WILD','GUARDIAN'].includes(m(x).kind)),{min:1,max:1});if(!pay)return;extra={target,payId:pay[0]};}
  if(option.code==='S08'){const modes=[];if(p.status.length)modes.push({seat:0,name:'STATUSを1つ解除'});if(p.hand.some(x=>x!==id))modes.push({seat:1,name:'手札1枚を捨てて1枚引く'});const mode=await chooseOtherSeat('薬草の効果を選択',modes);if(mode===null)return;if(mode===1){const pay=await pick('捨てる手札',p.hand.filter(x=>x!==id),{min:1,max:1});if(!pay)return;extra={mode:'cycle',payId:pay[0]};}}
  if(['S08','C005'].includes(option.code)&&extra.mode!=='cycle'){const box=show('解除するSTATUS',`<div class="modal-actions">${p.status.map(st=>b(st,st,'secondary')).join('')}</div>`);const status=await new Promise(resolve=>{p.status.forEach(st=>box.querySelector(`[data-action="${st}"]`).onclick=()=>{close();resolve(st);});box.querySelector('#close-dialog').onclick=()=>{close();resolve(null);};});if(!status)return;extra.status=status;}
  if(['S12','C011'].includes(option.code)){const pay=await pick('元能力で捨てる手札',p.hand.filter(x=>x!==id),{info:'COPYカードとは別に手札1枚を捨て、その後1枚引く。'});if(!pay)return;extra.payId=pay[0];}
  commit({type:'hand_copy_action',id,sourceId:option.sourceId,...extra});return;
 }
 if(c.id==='C005'){return chooseCleanseHand(id);}
 if(c.id==='C035'){
   const restored=await pick('山札の上に戻す捨て札',p.discard,{info:'捨て札1枚を選び、自分の山札の上に置く。'});if(restored)commit({type:'hand_use',id,target:restored[0]});
 }else confirm('HANDの効果を確認',`${esc(c.name)}を捨ててHAND効果を使う。<br>${esc(c.other)}`,()=>commit({type:'hand_use',id}));return;
}

function mobileQuick(r,p){if(!humanTurn())return '<div class="quick-wait">CPUの手番中… 自動で進むよ</div>';
 if(r.phase==='DRAFT')return b('初期仲間を選ぶ','draft','primary wide');
 if(r.phase==='CHECK')return b('GUARDIANを判定','check','primary wide');
 if(r.phase==='START')return b('編成する','formation','secondary')+(E.startAbilityEligible(r,p.seat,'C173')&&p.status?.length&&!r.startStatusCleanseUsed?.[String(p.seat)]?b('白脱皮：STATUS解除','startcleanse','secondary'):'')+b('START完了 →','startdone','primary');
 if(r.fieldDiscardPending?.owner===0)return b('手札1枚を捨てる','field','primary wide');
 if(r.explore)return b('探索カードを選ぶ','exploreresolve','primary')+b('他の行動','moreactions','secondary');
 return b('🌿 探索','explore','primary')+b('⚙ 行動一覧','moreactions','secondary')+b('CAMP 次の手番','camp','ghost');
}
function controls(r,p){
 if(r.phase==='DRAFT')return smartBtn('初期仲間を選ぶ','draft','primary');
 if(r.phase==='CHECK')return smartBtn('GUARDIAN CHECK','check','primary');
 if(r.phase==='START')return smartBtn('編成を変更','formation','secondary')+(E.startAbilityEligible(r,p.seat,'C173')&&p.status?.length&&!r.startStatusCleanseUsed?.[String(p.seat)]?b('白脱皮：STATUS解除','startcleanse','secondary'):'')+smartBtn('START完了 →','startdone','primary');
 if(r.phase==='FINISHED')return '';
 if(r.fieldDiscardPending?.owner===0)return smartBtn('L5灼熱：手札を1枚捨てる','field','primary');
 if(r.explore?.owner===0)return `${b('探索したカードを確認','viewcapture','primary')}${smartBtn('追加公開','more','secondary')}${smartBtn('CAMP','camp','ghost')}`;
 return [
  smartBtn('🌿 探索する','explore','primary'),smartBtn('✦ ITEMを補給','buy','secondary'),
  smartBtn('↓ 階層を進む','move','secondary'),smartBtn('⚔ GUARDIAN戦','guardian','secondary'),
  smartBtn('ITEMを使用','item','ghost'),smartBtn('🖐 HAND能力','hand','secondary'),smartBtn('⚔ 妨害する','interfere','secondary'),smartBtn('メモ・手動裁定','manual','ghost'),
  smartBtn('RETURN押し戻し','pushback','ghost'),smartBtn('CAMP · 手番終了','camp','primary')
 ].join('');
}
// v0.9.2: role-first choice UI. All selections stay local until the final confirmation.
function formationWizard({draft=false}={}){
 return new Promise(resolve=>{
  const room=current(),owner=who(),revision=room?.revision;
  if(!room||!owner||!humanTurn()||room.phase!==(draft?'DRAFT':'START')){toast('自分の編成を選ぶタイミングではありません');resolve(null);return;}
  const pool=[...new Set(draft?room.starterOffer:[owner.main,...owner.support,...owner.hand.filter(isCreature)].filter(Boolean))];
  let slots=draft?[null,null,null]:[owner.main||null,owner.support[0]||null,owner.support[1]||null];
  let step=0,settled=false;
  const titles=['MAINを選択','SUPPORTを選択 · 1体目','SUPPORTを選択 · 2体目','編成を確認'];
  const roleNames=['MAIN','SUPPORT 1','SUPPORT 2'];
  const valid=()=>current()===room&&room.revision===revision&&room.seat===0&&room.phase===(draft?'DRAFT':'START');
  function cancel(){if(settled)return;settled=true;close();resolve(null);}
  function choose(id){
   if(settled||!valid()){toast('盤面が変わったため、編成を開き直してください');cancel();return;}
   if(id&&!pool.includes(id))return;
   if(step>0&&id&&slots.some((s,i)=>i!==step&&s===id)){toast('ほかの枠に選択中です。その枠から選び直してください');return;}
   if(id)slots=slots.map((s,i)=>i!==step&&s===id?null:s);
   slots[step]=id;step=draft?3:step+1;
   // Do not ask the player to choose an empty slot when no candidate exists.
   while(!draft&&step<3&&!pool.some(x=>!slots.some((v,i)=>i!==step&&v===x))){slots[step]=null;step++;}
   if(step===3&&!slots[1]&&slots[2]){slots[1]=slots[2];slots[2]=null;}
   draw();
  }
  function commitChoice(){
   if(settled)return;
   if(!valid()){toast('盤面が変わったため、もう一度選んでください');cancel();return;}
   if(draft&&!slots[0])return;
   const all=slots.filter(Boolean);if(new Set(all).size!==all.length||!all.every(id=>pool.includes(id))){toast('編成の重複を確認してください');return;}
   settled=true;close();resolve(draft?{type:'draft_pick',id:slots[0]}:{type:'rearrange',main:slots[0],support:slots.slice(1).filter(Boolean)});
  }
  function heading(){return draft?(step===3?'初期MAINを確認':'最初のMAINを選択'):titles[step];}
  function progress(){return `<div class="f92-steps" aria-label="編成の手順">${(draft?['MAIN','確認']:['MAIN','SUPPORT 1','SUPPORT 2','確認']).map((t,i)=>{const idx=draft?(i===0?0:3):i;return `<span class="${idx===step?'is-current':idx<step?'is-complete':''}" ${idx===step?'aria-current="step"':''}><i>${idx<step?'✓':i+1}</i>${t}</span>`;}).join('')}</div>`;}
  function assigned(){return `<div class="f92-assigned">${slots.map((id,i)=>`<div class="${i===step?'is-current':''}"><span>${roleNames[i]}</span><b>${id?esc(m(id).name):'空き'}</b></div>`).join('')}</div>`;}
  function candidate(id){
   const c=m(id),role=step===0?'MAIN':'SUPPORT',text=c[role.toLowerCase()],selected=slots[step]===id;
   const otherSlot=slots.findIndex((s,i)=>i!==step&&s===id),blocked=step>0&&otherSlot!==-1;
   const buttonLabel=blocked?`${roleNames[otherSlot]}に選択中`:selected?`この${role}で次へ`:`${role}に選ぶ`;
   return `<article class="f92-card ${selected?'is-selected':''} ${blocked?'is-assigned':''}" data-option="${esc(id)}"><button type="button" class="f92-art" data-f92-read="${esc(id)}" aria-label="${esc(c.name)}の${role}能力を大きく見る"><img src="${img(id)}" alt="${esc(c.name)}" loading="lazy"><small>拡大する</small></button><div class="f92-card-info"><header><b>${esc(c.name)}</b><small>${esc(c.species||'')} · ${esc(c.id)}</small></header><div class="f92-role-text"><strong>${role}能力</strong><p>${text&&text!=='―'?esc(String(text).replace(/^(MAIN|SUPPORT)\s*[｜:：]\s*/,'')):`${role}能力の印字はありません。`}</p></div>${c.keyword&&c.keyword!=='―'?`<small class="f92-keyword">${esc(c.keyword)}</small>`:''}<button type="button" data-f92-pick="${esc(id)}" class="f92-select" ${blocked?'disabled aria-disabled="true"':''}>${esc(buttonLabel)}</button></div></article>`;
  }
  function review(){
   const shown=draft?[0]:[0,1,2];
   const returned=[owner.main,...owner.support].filter(id=>id&&!slots.includes(id));
   return `<p class="f92-intro">${draft?'このSTARTERを最初のMAINにします。':'この配置で確定します。選び直す場合は各枠の「変更」を押してください。'}</p><div class="f92-review ${draft?'is-draft':''}">${shown.map(i=>{const id=slots[i],c=id?m(id):null,role=i===0?'MAIN':'SUPPORT';return `<article><strong>${roleNames[i]}</strong>${id?`<button type="button" class="f92-review-art" data-f92-read="${esc(id)}" data-f92-role="${role}" aria-label="${esc(c.name)}の能力を見る"><img src="${img(id)}" alt="${esc(c.name)}"></button><b>${esc(c.name)}</b>`:'<div class="f92-empty-card">空き</div><b>配置しない</b>'}<button type="button" class="f92-edit" data-f92-edit="${i}">変更</button></article>`;}).join('')}</div>${!draft?`<p class="f92-notice">${returned.length?`${returned.map(id=>esc(m(id).name)).join('・')}は手札に戻ります。`:'編成は最大3体。SUPPORTが0体・1体でも確定できます。'}<br>ここでは配置のみ確定。次に盤面の「この編成で進む」でSTARTを終了します。</p>`:''}`;
  }
  function draw(){
   if(settled)return;
   const reviewing=step===3,role=step===0?'MAIN':'SUPPORT';
   const intro=draft?'まずは冒険の中心になるSTARTERを1体選びましょう。':step===0?'この編成の中心になる1体。MAIN能力を見て選びましょう。':`MAINを助ける${step===1?'1体目':'2体目'}。SUPPORT能力を見て選びましょう。空きのままでも進めます。`;
   const content=progress()+(!draft&&!reviewing?assigned():'')+(reviewing?review():`<p class="f92-intro">${esc(intro)}</p><div class="f92-candidates">${pool.map(candidate).join('')||'<p class="f92-notice">配置できるCREATUREがありません。空き枠のまま進めます。</p>'}</div>`);
   const box=show(heading(),`<div class="formation92" data-step="${step}" data-mode="${draft?'draft':'formation'}">${content}<footer class="f92-footer">${step>0?'<button type="button" class="f92-back" data-f92-back>‹ 戻る</button>':'<button type="button" class="f92-back" data-f92-cancel>キャンセル</button>'}${reviewing?`<button type="button" class="f92-confirm" data-f92-confirm>${draft?'このMAINで開始':'編成を確定'}</button>`:!draft?`<button type="button" class="f92-skip" data-f92-skip>${step===0?'MAINを置かずに次へ':'このSUPPORT枠を空けて次へ'}</button>`:''}</footer><p class="f92-safety">画像は能力の確認用。最後に確定するまで、カード・ACTION・効果は変わりません。</p></div>`);
   box.querySelector('.dialog').classList.add('f92-dialog');
   box.querySelector('#close-dialog').onclick=cancel;
   box.querySelectorAll('[data-f92-read]').forEach(el=>el.onclick=()=>{
    const roleHint=el.dataset.f92Role||role;
    showCard(el.dataset.f92Read,{onBack:draw,roleOverride:roleHint,previewOnly:true,backLabel:'← 選択に戻る'});
   });
   box.querySelectorAll('[data-f92-pick]').forEach(el=>el.onclick=()=>choose(el.dataset.f92Pick));
   box.querySelectorAll('[data-f92-edit]').forEach(el=>el.onclick=()=>{step=Number(el.dataset.f92Edit);draw();});
   box.querySelector('[data-f92-back]')?.addEventListener('click',()=>{step=draft?0:Math.max(0,step-1);draw();});
   box.querySelector('[data-f92-cancel]')?.addEventListener('click',cancel);
   box.querySelector('[data-f92-skip]')?.addEventListener('click',()=>choose(null));
   box.querySelector('[data-f92-confirm]')?.addEventListener('click',commitChoice);
   box.querySelector('.dialog').scrollTop=0;
  }
  draw();
 });
}

function copyExploreChoices(r,p){
 if(!p?.main||!r?.explore||r.explore.owner!==0||r.explore.usedExploreSources?.includes(p.main))return [];
 if(!['C079','C122','C149','C154','C181'].includes(m(p.main).id))return [];
 return E.copyTargetCandidates(r,0,m(p.main).id,'MAIN').filter(c=>{
  const pre=E.copyActivationPreflight(r,0,p.main,c.physicalId,'MAIN');
  return pre.ok&&pre.execution?.kind==='EXTRA_EXPLORE'&&Number.isInteger(pre.execution.amount)&&pre.execution.amount>0;
 });
}
async function command(cmd){const r=current(),p=who();switch(cmd){
case 'timing_focus':{const panel=document.querySelector('.ux-timing-panel');panel?.scrollIntoView({behavior:'smooth',block:'center'});return;}case 'viewturn':activeTab='turn';render();return;case 'viewcapture':activeTab='capture';render();return;case 'viewmeta':activeTab='meta';render();return;case 'viewsupply':activeTab='supply';render();return;case 'viewcamp':activeTab='camp';render();return;case 'tutorial':startTutorial();return;case 'synergy_tutorial':startTutorial(5);return;case 'moreactions':{document.querySelector('.controls')?.scrollIntoView({behavior:'smooth',block:'center'});return;}case 'none':return;case 'start':startGame();return;case 'resume':return;case 'reset':confirm('最初からやり直す？','現在の記録を破棄して最初から始めるよ。',reset);return;case 'restart':reset();return;
case 'rulebook':{if(window.RINNE_SINGLE_HTML_RULES){const win=window.open('','_blank');if(win){win.document.open();win.document.write(window.RINNE_SINGLE_HTML_RULES);win.document.close();}else toast('ポップアップを許可してね');}else window.open('rules.html','_blank');return;}
case 'catalog':openCatalog();return;
case 'field':handlePendingField();return;
case 'guard':confirm('防御装備の処理','妨害を受けたときに押してね。I18は使い切り、I21は次のSTARTまで持続する。',()=>commit({type:'guard_interference'}));return;
case 'fx_toggle':window.RinneFx?.setEnabled(!window.RinneFx?.isEnabled());toast(window.RinneFx?.isEnabled()?'演出をONにしたよ':'演出をOFFにしたよ');return;
case 'fx_preview':showFxPreview();return;
case 'import':{const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.onchange=async()=>{try{const file=input.files?.[0];if(!file)return;const state=JSON.parse(await file.text());E.verifyRoom(state);clearTimeout(botTimer);window.RinneFx?.reset();window.gameRoom=state;activeTab='turn';focusId=null;safeSave();render();handlePendingField();handlePendingEffects();runCPUs();toast('セーブデータを読み込んだよ');}catch(e){toast('読み込み不可：'+e.message);}};input.click();return;}
case 'speed':delay=delay===320?80:320;toast(delay===80?'CPU高速モード':'CPU標準モード');return;case 'export':{const b=new Blob([JSON.stringify(r,null,2)],{type:'application/json'});let url=URL.createObjectURL(b);let a=document.createElement('a');a.href=url;a.download='RINNE_CPU_保存データ.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);return;}
case 'draft':{const selection=await formationWizard({draft:true});if(selection)commit(selection);return;}
case 'formation':{const selection=await formationWizard();if(selection)commit(selection);return;}
case 'startcleanse':{
 if(!E.startAbilityEligible(r,0,'C173')||!p.status?.length)return toast('C173の解除条件を満たしていません');
 if(r.startStatusCleanseUsed?.['0'])return toast('このSTARTでは使用済みです');
 const box=show('C173｜白脱皮',`<p>START時にSTATUSを1つ解除できる。</p><div class="modal-actions">${p.status.filter(st=>r.startSnapshot.status.includes(st)).map((st,i)=>b(st,'status'+i,'secondary')).join('')}${b('やめる','cancel','ghost')}</div>`);
 p.status.filter(st=>r.startSnapshot.status.includes(st)).forEach((st,i)=>box.querySelector(`[data-action="status${i}"]`).onclick=()=>{close();commit({type:'start_status_cleanse',status:st})});
 box.querySelector('[data-action=cancel]').onclick=close;return;}
case 'startdone':{const choice=E.startSpeciesOptions(r,0);if(choice){const selected=[];const choose=()=>{const options=choice.candidates.filter(x=>!selected.includes(x));const box=show(choice.code+'｜STARTの種族を選ぶ',`<p>${choice.support?'開始時のSUPPORT1体に蟲種を追加。':choice.replace?'このターンの種族を置き換えます。':'このターンの種族を追加します。'}${choice.count===2?' 異なる2種を選択：'+selected.length+'/2':''}</p><div class="modal-actions" data-modal-must-resolve>${options.map((x,i)=>b(choice.support?m(x).name:x,'species'+i,'secondary')).join('')}</div>`);box.querySelector('#close-dialog').onclick=()=>toast('STARTの選択を完了してね');options.forEach((x,i)=>box.querySelector(`[data-action="species${i}"]`).onclick=()=>{selected.push(x);if(selected.length<choice.count){choose();return;}close();commit(choice.support?{type:'start_species',id:selected[0]}:{type:'start_species',species:selected});commit({type:'start_done'});});};choose();return;}commit({type:'start_done'});return;}
case 'maincopy':{const choices=E.copyTargetCandidates(r,0,m(p.main).id,'MAIN').filter(x=>{const pre=E.copyActivationPreflight(r,0,p.main,x.physicalId,'MAIN');return pre.ok&&['STATIC_POWER','STATIC_CAPTURE','EXTRA_EXPLORE','COPIED_PROFILE','COPIED_COST_MAIN','COPIED_ATTACK_MAIN'].includes(pre.execution?.kind);});const box=show('MAIN COPY｜このターンの能力',`<p>元能力の使用時点・コスト・回数制限に従う。対応済みの補正・追加探索・コスト誘発・STATUS解除（1 ACTION）・手札交換（1 ACTION）・解除後POWER・妨害・STATUS防御・直接POWER低下・最初の妨害・POWER比較への防御を選択。防御COPYも次のプレイヤーのSTARTで失効。開始後に取得したSTART能力は遡及発動しない。</p><div class="modal-actions">${choices.map((x,i)=>b(m(x.physicalId).name,'copybind'+i,'secondary')).join('')||'<p>対応済みの合法な対象なし</p>'}</div>`);choices.forEach((x,i)=>box.querySelector(`[data-action="copybind${i}"]`).onclick=()=>{close();commit({type:'copy_main',sourceId:x.physicalId});});return;}

case 'check':{let g=p.guardian[String(p.level)];if(!g?.pending)return toast('未挑戦です');const mm=m(g.id),fo=g.pending.method==='FORCE',pred=fo?Bot.canForce(p,g):Bot.canCaptureGuardian(p,g,g.pending.bonus||0);confirm('GUARDIAN CHECK',`${esc(mm.name)} · ${esc(g.pending.method)} / ${esc(mm.guardian_rule)}<br>数値の簡易判定：<b>${pred?'成功候補':'達成を確認できない'}</b><br>実際のカード効果、REACTION、STATUSを見たうえで結果を決めてね。`,()=>checkDecision(g,pred));return;}
case 'main_draw_cycle':commit({type:'main_draw_cycle'});return;
case 'explore':commit({type:'explore'});return;case 'exploreresolve':if(r.explore?.ids?.length)openExploration(r.explore.ids[0]);return;
case 'more':{
 const sources=[p.main,...p.support,...p.hand].filter(Boolean).filter(id=>E.exploreSourceCount(p,id)>0&&!r.explore?.usedExploreSources?.includes(id));
 const copies=copyExploreChoices(r,p);
 if(!sources.length&&!copies.length){toast('使える追加公開能力・ITEMがないよ');return;}
 const box=show('追加公開の根拠カード',`<p>通常能力・ITEMまたはCOPY元を選んでね。COPYは探索追加能力のみ対応。</p><div class="modal-actions">${sources.map((id,i)=>b(m(id).name,'regular'+i,'secondary')).join('')}${copies.map((c,i)=>b('COPY：'+m(c.physicalId).name+'（'+c.cardId+'）','copy'+i,'secondary')).join('')}${b('やめる','cancel','ghost')}</div>`);
 sources.forEach((id,i)=>box.querySelector(`[data-action="regular${i}"]`).onclick=()=>{close();commit({type:'explore_more',sourceId:id});});
 copies.forEach((c,i)=>box.querySelector(`[data-action="copy${i}"]`).onclick=()=>{close();commit({type:'explore_more',sourceId:p.main,copySourceId:c.physicalId});});
 box.querySelector('[data-action=cancel]').onclick=close;
 return;}
case 'redraw':{
 const sources=[p.main,...p.support,...p.hand,...(r.explore?.usedExploreSources||[])].filter(Boolean).filter(id=>{
 const c=m(id),t=[c.main,c.support,c.effect].filter(Boolean).join(' ');
 return /引き直|山札の下へ/.test(t)&&(!r.explore?.redrawCount?.[id]||['I02','I03'].includes(c.id)&&r.explore.redrawCount[id]<2);
 });
 if(!sources.length)return toast('使用可能な引き直し能力・ITEMがないよ');
 let choice=await pick('引き直す能力・ITEMを選ぶ',sources,{info:'使用済みITEMでもI02・I03は最大2回まで続けて使用可能。'});if(!choice)return;
 let cards=await pick('山札の下に戻す公開カード',r.explore.ids,{info:'引き直したいカードを1枚選ぶ'});if(!cards)return;
 const id=choice[0],species=m(id).id==='I02'?prompt('I02：探したい種族（例：獣種）','獣種'):undefined;
 if(m(id).id==='I02'&&!species)return;
 commit({type:'explore_redraw',sourceId:id,id:cards[0],species});return;}
case 'give_creature':return giveCreatureDialog();
case 'buy':{let sel=await pick('補給したいITEMを選択',r.market.filter(id=>p.hand.length>=Number(m(id).cost||0)),{info:'手札でCOSTを支払えるカードのみ。市場全体は「補給」タブで確認できるよ。'});if(sel)buyCard(sel[0]);return;}
case 'move':moveAction();return;case 'guardian':guardianAction();return;
case 'hand':{
 if(p.actedHand)return toast('HANDはこのターンもう使用済み');const pool=p.hand.filter(id=>E.handEffects.has(m(id).id)||(E.handCopyActionOptions?.(r,0,id).length||E.handAttackOptions?.(r,0,id).length));
 if(!pool.length)return toast('今使えるHAND能力はないよ');const chosen=await pick('HAND能力を使うカード',pool,{info:'HANDは自ターン合計1回。能力を読んでから選ぼう。'});if(!chosen)return;
 const id=chosen[0];return useHandById(id);}
case 'interfere':{
 const desc=E.mainAbilityText(r,p);const options=E.interferenceTargets(r,0),assisted=E.handPowerAttackOptions?.(r,0)||[];
 if(!options.length&&!assisted.length)return toast('妨害できる相手がいないよ');const box=show('妨害する相手を選ぶ',`<p>${esc(desc)}</p><p>1 ACTION消費。対象のREACTIONや装備で防がれる場合がある。</p><div class="modal-actions">${options.map(q=>b(`${q.name} / L${q.level}`,String(q.seat),'secondary')).join('')}${assisted.map((o,i)=>o.targets.map(target=>b('HAND '+m(o.handId).name+' → '+m(o.sourceId).name+'／'+r.players[target].name+' POWER+'+o.amount,'power'+i+'_'+target,'secondary')).join('')).join('')}</div>`);
 options.forEach(q=>box.querySelector(`[data-action="${q.seat}"]`).onclick=()=>{close();commit({type:'interfere',target:q.seat});});assisted.forEach((o,i)=>o.targets.forEach(target=>box.querySelector(`[data-action="power${i}_${target}"]`).onclick=()=>{close();commit({type:'interfere',target,copyHandId:o.handId,copySourceId:o.sourceId});}));return;}
case 'item':{
 const pool=p.hand.filter(id=>['SUPPLY','START ITEM'].includes(m(id).kind));if(!pool.length)return toast('手札にITEMがないよ');
 const chosen=await pick('ITEMを選ぶ',pool,{info:'対応しているITEMだけ効果を自動処理する。未対応は消費されない。'});if(!chosen)return;
 const id=chosen[0],c=m(id),code=c.id;
 if(!E.itemSupported(id))return toast(`${c.name}はまだ自動化されていないため消費しないよ`);
 if(!['SI04','I16','I07','I27','I28','I29','I30','I31','I32','I33','I34','I35','I36','I18','I21','I37','I40'].includes(code))return toast('このITEMは探索・CAPTURE・META・REACTIONの専用画面から使ってね。ここでは消費しないよ');
 if(['I37','I40'].includes(code))return revisedGiftItem(id);
 if(code==='I28'&&r.explore?.source==='wild')return revisedPheromone(id);
 if(['SI04','I16'].includes(code)){
  if(!p.status.length)return toast('解除するSTATUSがないため使用できないよ');const modal=show('解除するSTATUSを選ぶ',`<div class="modal-actions">${p.status.map(st=>b(st,st,'secondary')).join('')}</div>`);
  p.status.forEach(st=>modal.querySelector(`[data-action="${st}"]`).onclick=()=>{close();commit({type:'use_item',id,status:st});});return;
 }
 if(['I27','I28','I29','I30','I31'].includes(code)){
  const targets=r.players.slice(1).filter(q=>q.level===p.level&&(code!=='I28'||q.stray.length)&&(code!=='I29'||q.support.some(id=>!q.disabledSupportIds?.includes(id)&&!!m(id).support)));if(!targets.length)return toast('同LEVELの対象がいない');
  const modal=show('ITEMの対象を選ぶ',`<p>${esc(c.effect||'')}</p><div class="modal-actions">${targets.map(q=>b(q.name,String(q.seat),'secondary')).join('')}</div>`);
  targets.forEach(q=>modal.querySelector(`[data-action="${q.seat}"]`).onclick=()=>{close();commit({type:'use_item',id,target:q.seat});});return;
 }
 if(code==='I32'||code==='I36'){
   const n=code==='I32'?2:1;const pool2=p.hand.filter(x=>x!==id);if(!pool2.length)return toast('対象の手札がない');const pay=await pick('ITEM効果：手札を選択',pool2,{min:code==='I32'?0:1,max:Math.min(n,pool2.length),info:esc(c.effect||'カードを選んでね')});if(pay)commit({type:'use_item',id,...(code==='I32'?{pay}:{card:pay[0]})});return;
 }
 if(code==='I34'){confirm('整理ケースを使う',`${esc(c.effect)}<br>使用後に山札へ戻す順番を選ぶ。`,()=>commit({type:'use_item',id}));return;}
 if(code==='I35'){const pool2=(r.removedItems||[]).filter(x=>['SUPPLY','START ITEM'].includes(m(x).kind)&&x!==id&&r.usedItemOwners?.[x]===p.seat);if(!pool2.length)return toast('自分が使用して除外したITEMがない');const choice=await pick('回収する除外ITEM',pool2,{info:'自分が使用して除外したITEM1枚を手札に戻す。緊急ポーチ自身は除外。'});if(choice)commit({type:'use_item',id,card:choice[0]});return;}
 confirm('ITEMを使用',`${esc(c.name)}：${esc(c.effect||'')}<br>使用後は除外。`,()=>commit({type:'use_item',id}));return;}
case 'main_cycle':{
 if(r.phase!=='ACTIONS'||r.seat!==0||r.actionPoints<1||r.explore)return toast('探索中以外のACTION中に1 ACTION必要です');
 const source=E.mainHandCycleSource(r,p);if(!p.main||!source)return toast('MAINに手札交換能力がありません');
 if(p.mainAbilityDisabled||p.status.some(st=>['SLEEP','STUN'].includes(st)))return toast('現在MAIN能力を使えません');
 if(!p.hand.length)return toast('捨てる手札がありません');
 const chosen=await pick('MAIN能力：捨てる手札1枚を選ぶ',p.hand,{min:1,max:1,info:esc(E.C[source].main)+'<br>1 ACTIONを使い、選んだカードを捨ててから1枚引く。HAND能力の使用回数は消費しない。',confirmLabel:'1 ACTIONで捨てて引く'});
 if(chosen)commit({type:'main_hand_cycle',id:chosen[0]});return;}
case 'main_cleanse':{
 if(r.phase!=='ACTIONS'||r.seat!==0||r.actionPoints<1)return toast('ACTION中に1 ACTION必要です');
 if(!p.main||!E.mainStatusCleanseSource(r,p))return toast('MAINにSTATUS解除能力がありません');
 if(!p.status.length)return toast('解除するSTATUSがありません');
 if(p.mainAbilityDisabled||p.status.includes('SLEEP')||p.status.includes('STUN'))return toast('現在MAIN能力を使えません');
 const chosen=show('MAIN能力｜1 ACTIONでSTATUS解除',`<p>${esc(E.C[E.mainStatusCleanseSource(r,p)].main)}</p><div class="modal-actions">${p.status.map(st=>b(st,st,'secondary')).join('')}</div>`);
 p.status.forEach(st=>chosen.querySelector(`[data-action="${st}"]`).onclick=()=>{close();commit({type:'main_status_cleanse',status:st});});
 return;}
case 'manual':manualMenu();return;case 'pushback':pushbackMenu();return;case 'camp':{
 const stowed=await pick('CAMP：STOWするカードを選ぶ',p.hand,{min:0,max:p.hand.length,info:'捨て札へ送るカードだけ選んでね。選ばないカードはKEEPし、その後、手札5枚まで補充。0枚ならすべてKEEP。',confirmLabel:n=>n?`${n}枚をSTOWして進む`:'STOWせずに進む'});
 if(stowed===null)return;
 const chosen=p.hand.filter(id=>!stowed.includes(id));
 const sources=(p.support||[]).filter(id=>!p.disabledSupportIds?.includes(id)&&['C006','C081','C130'].includes(m(id)?.id));
 const targets=p.status.filter(x=>!['STUN','SLEEP'].includes(x));
 let campCleanse=null;
 if(sources.length&&targets.length){
  campCleanse=await new Promise(resolve=>{
   const opts=sources.flatMap(id=>targets.map(status=>({id,status})));
   const box=show('CAMP｜STATUSの任意解除',`<p>SUPPORTの能力でSTATUSを1つ解除できるよ。使用しなくてもCAMPは続けられる。</p><div class="modal-actions">${opts.map((o,i)=>b(`${esc(m(o.id).name)}：${o.status}解除${m(o.id).id==='C130'?'＋1枚DRAW':''}`,'choice'+i,'secondary')).join('')}${b('解除しない','skip','ghost')}</div>`);
   opts.forEach((o,i)=>box.querySelector(`[data-action="choice${i}"]`).onclick=()=>{close();resolve(o)});
   box.querySelector('[data-action=skip]').onclick=()=>{close();resolve(null)};
   box.querySelector('#close-dialog').onclick=()=>{close();resolve(null)};
  });
 }
 confirm('CAMPの最終確認',`STOW <b>${stowed.length}枚</b> ／ KEEP <b>${chosen.length}枚</b> ／ 補充予定 <b>${Math.max(0,5-chosen.length)}枚</b>${campCleanse?` ／ ${esc(campCleanse.status)}解除`:''}`,()=>commit({type:'camp',keep:chosen,campCleanse}));
 return;}
}}
function checkDecision(){toast('v0.9.5ではGUARDIANは挑戦宣言時に即時CHECKします');}
async function buyCard(id){let c=m(id),cost=Number(c.cost||0),p=who();if(!p.hand.length||p.hand.length<cost)return toast(`手札${cost}枚で支払いが必要`);const sel=await pick(`${c.name} / COST ${cost}`,p.hand,{min:cost,max:cost,info:`手札をちょうど${cost}枚捨てて補給する。DISCARD効果は正本を確認。`});if(sel)confirm('補給の最終確認',`${esc(c.name)}を獲得する。<br>COST <b>${cost}</b> ／ 支払い <b>${sel.length}枚</b>。<br>支払いは捨て札、購入ITEMは捨て札へ。`,()=>commit({type:'buy',id,pay:sel}));}
function cardDetailMarkup(id,roleHint=null,previewOnly=false){
 const c=m(id),role=roleHint||roleForCard(id);const fields=[['常在・適応',c.keyword],['MAIN',c.main],['SUPPORT',c.support],['その他・DISCARD・HAND',c.other],['効果・使用条件',c.effect],['SYNERGY',c.synergy],['GUARDIAN固有条件',c.guardian_rule]].filter(([_,v])=>v&&String(v).trim()&&String(v)!=='―');
 const roleLabel=role?`<div class="ux-active-role">現在の注目：<strong>${role}</strong>の能力${previewOnly||roleHint&&roleHint!==roleForCard(id)?'（配置前の役割プレビュー）':'（現在の編成に対応）'}</div>`:'<div class="ux-active-role ux-no-role">手札・候補カード：MAIN／SUPPORT両方を比較できるよ</div>';
 return `<div class="inspect-card"><img class="card-art-large" src="${img(id)}" alt="${esc(c.name)}のカード画像"><div class="inspect-info"><p class="eyebrow">${esc(c.id)}｜${esc(c.kind)} ${c.level?`・LEVEL ${esc(c.level)}`:''}</p><p class="stat">${c.species?esc(c.species)+' · ':''} ${c.pow!==undefined?'POW '+esc(c.pow||'—')+' · ':''}${c.cap!==undefined?'CAP '+esc(c.cap||'—')+' · ':''}${c.meta!==undefined?'META '+esc(c.meta||'—'):''}${c.cost!==undefined?' COST '+esc(c.cost):''}</p>${roleLabel}${fields.map(([label,text])=>`<section class="ability-block ${role&&label===role?'ux-ability-active':role&&(label==='MAIN'||label==='SUPPORT')?'ux-ability-inactive':''}"><strong>${esc(label)}${role&&role===label?(previewOnly?' · 配置プレビュー':' · 現在の役割'):''}</strong><div>${esc(text)}</div></section>`).join('')||'<p class="caption">カード画像に印字された効果を確認してね。</p>'}<p class="caption">※現在の配置に応じた表示の強調。効果の自動発動を保証するものではないよ。</p></div></div>`;
}
function showCard(id,opts={}){
 const c=m(id),actualRole=roleForCard(id);let preview=opts.roleOverride||actualRole;
 function draw(){const box=show(c.name||'カードの詳細',cardDetailMarkup(id,preview,!!opts.previewOnly)+`<div class="ux-role-switch"><span>能力の見比べ：</span><button type="button" data-preview-role="MAIN" class="${preview==='MAIN'?'chosen':''}">MAINで見る</button><button type="button" data-preview-role="SUPPORT" class="${preview==='SUPPORT'?'chosen':''}">SUPPORTで見る</button></div><div class="ux-readonly"><span>🔎 閲覧モード</span> ここではカードを消費・購入・選択しないよ。戻って専用ボタンから実行してね。</div>`);
 box.querySelectorAll('[data-preview-role]').forEach(el=>el.onclick=()=>{preview=el.dataset.previewRole;draw();});
 if(opts.onBack){box.querySelector('#close-dialog').onclick=opts.onBack;if(opts.backLabel)box.querySelector('#close-dialog').textContent=opts.backLabel;}
 }
 draw();
}
function openCatalog(search=''){
 const hits=E.cards.filter(c=>`${c.id} ${c.name||''} ${c.effect||''} ${c.keyword||''}`.toLowerCase().includes(search.toLowerCase())).slice(0,70);
 const box=show('カード図鑑｜いつでも能力確認',`<label class="catalog-search">ID・名前・能力で検索<input id="catalog-input" placeholder="例：C074 / 適応 / 捕獲" value="${esc(search)}" autocomplete="off"></label><div class="caption">検索結果 ${hits.length}件表示（最大70件）。山札の順番や相手の手札は表示しないよ。</div><div class="cards catalog-cards">${hits.map(c=>{const pic=E.physical.find(p=>p.card_id===c.id)?.physical_id;return pic?`<button class="game-card small" data-catalog="${esc(pic)}" aria-label="${esc(c.name)}の詳細"><img src="${img(pic)}" alt="${esc(c.name)}"><span>${esc(c.name)}</span></button>`:''}).join('')}</div>`);
 box.querySelector('#catalog-input').oninput=e=>{const cursor=e.target.selectionStart;const value=e.target.value;openCatalog(value);const inp=$('catalog-input');inp.focus();inp.setSelectionRange(cursor,cursor);};
 box.querySelectorAll('[data-catalog]').forEach(el=>el.onclick=()=>showCard(el.dataset.catalog,{onBack:()=>openCatalog(search)}));
}
function moveAction(){const p=who();confirm('階層を移動',p.returning?'RETURN：地上へ1階層上昇する。':'MAIN1体＋SUPPORT2体を揃えてL1からL2へ降下する。',()=>commit({type:'move'}));}
async function guardianCopyChoice(r,fixed=false){const choices=E.guardianCopyOptions(r,0).filter(o=>!fixed||o.compound);if(!choices.length)return null;const box=show('GUARDIAN｜HAND COPY',`<p>カードを捨てて、このCAPTURE判定に捕獲力を加える。</p><div class="modal-actions">${choices.map((x,i)=>b(esc(`${m(x.handId).name} → ${m(x.sourceId).name}（${x.compound?'SUPPORT種族補正・捕獲差分':'捕獲力+'}${x.amount}${x.costCaptureBonus?`・コスト誘発+${x.costCaptureBonus}`:''}）`),'gcopy'+i,'secondary')).join('')}${b('使わない','skip','ghost')}</div>`);return new Promise(resolve=>{choices.forEach((x,i)=>box.querySelector(`[data-action="gcopy${i}"]`).onclick=()=>{close();resolve(x);});box.querySelector('[data-action=skip]').onclick=()=>{close();resolve(null);};});}
async function guardianPowerCopyChoice(r){const choices=E.handPowerOptions(r,0);if(!choices.length)return null;const box=show('GUARDIAN FORCE｜HAND COPY',`<p>COPYカードを捨て、このFORCE判定だけにPOWERを加える。借りた常在能力は保持しない。</p><div class="modal-actions">${choices.map((o,i)=>b(m(o.handId).name+' → '+m(o.sourceId).name+' POWER+'+o.amount+(o.code==='C186'?'・SUPPORT種族補正':''),'gpower'+i,'secondary')).join('')}${b('使わない','skip','ghost')}</div>`);return new Promise(resolve=>{choices.forEach((o,i)=>box.querySelector(`[data-action="gpower${i}"]`).onclick=()=>{close();resolve(o);});box.querySelector('[data-action=skip]').onclick=()=>{close();resolve(null);};});}
function guardianAction(){const r=current(),p=who(),g=p.guardian[String(p.level)];if(!g)return toast('この階層には担当GUARDIANがいないよ');const c=m(g.id),pow=Bot.power(p),cap=Bot.capScore(p,g.id),fNeed=Number(c.force||0),cNeed=Number(c.cap||0),fa=Bot.guardianAssist?.(p,g,'FORCE')||0,fs=Bot.forceSupportBonus?.(p,g)||0,ca=Bot.guardianAssist?.(p,g,'CAPTURE')||0;let box=show('GUARDIANに挑戦',`<div class="detail"><img src="${img(g.id)}"><div><p><strong>${esc(c.name)}</strong> · L${p.level}</p><p>固有条件：${esc(c.guardian_rule||'追加条件なし')}</p><p class="stat">あなたの合計POWER <b>${pow}</b>${fa?` ＋攻略補助${fa}`:''}${fs?` ＋SUPPORT補正${fs}`:''} / FORCE <b>${fNeed}</b></p><p class="stat">基本捕獲力 <b>${cap}</b>${ca?` ＋攻略補助${ca}`:''} / CAP <b>${cNeed}</b></p><p>挑戦は <b>1 ACTION＋移動枠</b>。ITEM / REACTIONの後、その場で即時CHECK。</p></div></div><div class="modal-actions">${b('FORCEで即時挑戦','force','secondary')}${b('CAPTUREで即時挑戦','capture','primary')}</div>`);window.RinneFx?.guardianEntrance?.({id:g.id,imageUrl:img(g.id)});box.querySelector('[data-action=force]').onclick=async()=>{close();const copy=await guardianPowerCopyChoice(r);commit({type:'guardian_challenge',method:'FORCE',...(copy?{copyHandId:copy.handId,copySourceId:copy.sourceId}:{})});};box.querySelector('[data-action=capture]').onclick=async()=>{close();const nets=p.hand.filter(id=>m(id).id==='I14'||E.captureItemBonus(id,g.id)>0);const used=await pick('CAPTUREに使うITEM（任意）',nets,{min:0,max:nets.length,info:`基本捕獲力 ${cap}${ca?`＋攻略補助${ca}`:''} ／ 必要CAP ${cNeed}。I14は固定5で他と併用不可。`});if(!used)return;if(used.some(id=>m(id).id==='I14')&&used.length>1)return toast('I14は他の捕獲ITEMと併用できない');const copy=await guardianCopyChoice(r,used.some(id=>m(id).id==='I14'));commit({type:'guardian_challenge',method:'CAPTURE',captureItems:used,...(copy?{copyHandId:copy.handId,copySourceId:copy.sourceId}:{})});};}
function openExploration(id){const r=current(),p=who();if(!r.explore?.ids?.includes(id))return showCard(id);let c=m(id),base=Bot.capScore(p,id),threshold=Number(c.cap||0);let box=show(`探索｜${c.name}`,`<div class="detail"><img src="${img(id)}"><div><p>${esc(c.species)} · LEVEL ${esc(c.level)}</p><p class="stat">必要CAP ${threshold} / 基本捕獲力・簡易計算 ${base}</p><p>${esc(c.keyword||'')}</p><p class="caption">数字は限定計算。全カード能力の完全な自動計算ではないよ。必要なら印字能力・FIELD・ITEMで補正を確認してね。</p></div></div><div class="modal-actions">${b('CAPTURE','capture','primary')}${b('META進化','meta','secondary')}${b('捕獲失敗','fail','danger')}${b('見送る','skip','ghost')}</div>`);
 box.querySelector('[data-action=capture]').onclick=()=>{close();captureDialog(id);};box.querySelector('[data-action=meta]').onclick=()=>{close();metaDialog(id);};box.querySelector('[data-action=fail]').onclick=async()=>{close();const options=E.captureFailureOptions(current(),0);let selection=[];if(options.length){selection=await pick('捕獲失敗｜REACTION',options,{min:0,max:1,info:'I10またはC066を使うと、このCREATUREを遊動個体に残す。使わない場合は0枚で決定。'});if(selection===null)return;}commit({type:'explore_resolve',id,method:'FAIL',...(selection.length?{failureReactionId:selection[0]}:{})});};box.querySelector('[data-action=skip]').onclick=()=>{close();commit({type:'explore_resolve',id,method:'SKIP'});};}
async function captureDialog(id){
 const p=who(),t=m(id),base=Bot.capScore(p,id);
 const nets=p.hand.filter(x=>E.captureItemBonus(x,id)>0||m(x).id==='I14');
 const picked=await pick('捕獲に使うITEM（任意）',nets,{min:0,max:nets.length,info:`対象：${t.name} / 必要CAP ${t.cap} / 簡易捕獲力 ${base}。0枚でも選択可能。`});
 if(!picked)return;
 const fixed=picked.some(x=>m(x).id==='I14'),bonus=picked.reduce((sum,x)=>sum+E.captureItemBonus(x,id),0),needed=Number(t.cap);
 let copySourceId=null,copyHandId=null,copyBonus=0,copyCostBonus=0;
 {
  const r=current(),choices=[];
  if(!fixed&&p.main&&['C079','C122','C149','C154','C181'].includes(m(p.main)?.id)&&!r.explore?.copyCaptureUsed&&!E.copyMainBonus(r,p,'STATIC_CAPTURE',id)){
   for(const x of E.copyTargetCandidates(r,0,m(p.main).id,'MAIN')){
    const pre=E.copyActivationPreflight(r,0,p.main,x.physicalId,'MAIN');
    const amount=pre.ok?E.copyCaptureAmount(r,p,pre.execution,id):0;if(amount>0)choices.push({source:x.physicalId,hand:null,amount});
   }
  }
  if(!p.actedHand){
   for(const handId of p.hand.filter(x=>['C079','C154','C181'].includes(m(x)?.id))){
    for(const x of E.copyTargetCandidates(r,0,m(handId).id,'HAND')){
     const pre=E.copyActivationPreflight(r,0,handId,x.physicalId,'HAND');
     const amount=pre.ok?E.copyCaptureAmount(r,p,pre.execution,id,true,handId):0;if(pre.ok&&(!fixed||pre.sourceCardId==='C186')&&(amount>0||pre.sourceCardId==='C186'&&p.support.length===2))choices.push({source:x.physicalId,hand:handId,amount,costCaptureBonus:E.creatureCostCaptureBonus(r,p)});
    }
   }
  }
  if(choices.length){
   const box=show('捕獲能力をCOPYする？',`<p>HAND COPYはカードを捨てて使用する。使わずに捕獲もできるよ。</p><div class="modal-actions">${choices.map((x,i)=>b(esc(`${x.hand?'HAND '+m(x.hand).name:'MAIN'} → ${m(x.source).name}（${m(x.source).id==='C186'?'SUPPORT種族補正・捕獲差分':'捕獲力+'}${x.amount}${x.costCaptureBonus?`＋コスト誘発${x.costCaptureBonus}`:''}）`),'copy'+i,'secondary')).join('')}${b('使わない','skip','ghost')}</div>`);
   const selected=await new Promise(resolve=>{
    choices.forEach((x,i)=>box.querySelector(`[data-action="copy${i}"]`).onclick=()=>{close();resolve(x)});
    box.querySelector('[data-action=skip]').onclick=()=>{close();resolve(null)};
   });
   if(selected){copySourceId=selected.source;copyHandId=selected.hand;copyBonus=selected.amount;copyCostBonus=selected.costCaptureBonus||0;}
  }
 }
 const total=fixed?5:base+bonus+copyBonus+copyCostBonus;
 if(fixed&&picked.length>1)return toast('自動捕獲装置は他の補正ITEMと併用できないよ');
 const can=total>=needed;
 const dlg=show('CAPTUREの判定',`<p class="cap-score">${fixed?'自動捕獲装置 固定5':'基本・編成 '+base+' ＋ 使用ITEM '+bonus+' ＋ COPY '+copyBonus+' ＋ コスト誘発 '+copyCostBonus} ＝ <b>${total}</b> ／ 必要CAP <b>${needed}</b></p><p>${can?'この捕獲力で判定するよ。':fixed?'固定5では捕獲力が不足しているため、確定すると捕獲失敗になるよ。':'今の捕獲力では不足。他プレイヤーのREACTION後に判定し、援護が足りなければ捕獲失敗になるよ。'}</p><div class="modal-actions">${b(can?'捕獲を確定':fixed?'捕獲失敗を確定':'REACTION後に判定','captureyes','primary')}${b('キャンセル','captureno','ghost')}</div>`);
 dlg.querySelector('[data-action=captureno]').onclick=close;
 dlg.querySelector('[data-action=captureyes]').onclick=()=>{
   close();const now=who();const eligible=now?.level===1&&!now.returning&&(now.l1CaptureCount??2)<2;
   const opts={type:'explore_resolve',method:'CAPTURE',id,captureItems:picked,...(copySourceId?{copySourceId}:{}),...(copyHandId?{copyHandId}:{}),...(!can?{awaitCaptureAid:true}:{})};
   if(eligible&&now.support.length<2){const box=show('L1初期捕獲｜即SUPPORTに配置',`<div class="detail"><img src="${img(id)}" alt="${esc(t.name)}"><div><p><strong>${esc(t.name)}</strong></p><p>最初のCAPTURE成功 ${(now.l1CaptureCount??2)+1}/2</p><p>空きSUPPORTへ直接配置できるよ。配置すると能力もすぐ有効。</p></div></div><div class="modal-actions">${b('SUPPORTへ配置','put','primary')}${b('捨て札へ獲得','discard','secondary')}</div>`);
      box.querySelector('[data-action=put]').onclick=()=>{close();commit({...opts,directSupport:true});};
      box.querySelector('[data-action=discard]').onclick=()=>{close();commit({...opts,directSupport:false});};
   }else commit({...opts,...(eligible?{directSupport:false}:{})});
 };
}
async function metaDialog(id){let t=m(id),p=who();let pool=[...p.hand,...(p.main?[p.main]:[]),...p.support].filter(x=>isCreature(x)&&m(x).species===t.species);if(pool.length<2)return toast('同種族の素材CREATUREが2枚以上必要');let chosen=await pick('META素材を同時に選択（2枚以上）',pool,{min:2,max:pool.length,info:`目標META ${t.meta} / 同じ印字種族。素材は野生山札の底へ循環。`});if(chosen){const sum=chosen.reduce((a,x)=>a+Number(m(x).meta||0),0);
 const pool=p.hand.filter(x=>['I22','I23','I24','I25','I26'].includes(m(x).id));
 const used=pool.length?await pick('METAに使うITEM（任意）',pool,{min:0,max:pool.length,info:'成長促進剤・培養液など。条件を満たすITEMだけが効果を発揮する。'}):[];
 if(used===null)return;
 const bonus=used.reduce((n,x)=>n+(m(x).id==='I22'?1:['I23','I24'].includes(m(x).id)?2:0),0);
 const reduction=used.filter(x=>m(x).id==='I25').length;
 confirm('META最終確認',`${esc(t.name)}を獲得する。<br>素材${chosen.length}体・合計META <b>${sum}</b>＋ITEM補正 <b>${bonus}</b> ／ 必要 <b>${Math.max(0,Number(t.meta)-reduction)}</b><br>適応しないITEMは消費しない。素材は野生山札の底へ循環。`,()=>commit({type:'explore_resolve',method:'META',id,materials:chosen,metaItems:used}));}}
async function pushbackMenu(){const r=current(),p=who();if(!uiGate('pushback').ok)return toast(uiGate('pushback').reason);
 const options=[...E.pushbackTargets(r,0).map(q=>({target:q.seat})),...E.handPowerPushbackOptions(r,0).flatMap(o=>o.targets.map(target=>({target,copyHandId:o.handId,copySourceId:o.sourceId})))];
 const list=show('RETURN 押し戻し','<p>元MAINの条件・射程を満たす相手へ、効果を押し戻しに置き換える。2 ACTIONと手札CREATURE1枚を消費する。HAND COPYを使う場合は、別にCOPYカードを捨てる。</p><div class="modal-actions">'+options.map((o,i)=>{const q=r.players[o.target];return b(`${q.name} · L${q.level}${o.copyHandId?' / HAND '+m(o.copySourceId).name:''}`,o.copyHandId?'power'+i:String(o.target),'secondary');}).join('')+'</div>');
 options.forEach((o,i)=>list.querySelector(`[data-action="${o.copyHandId?'power'+i:o.target}"]`).onclick=async()=>{close();const pool=p.hand.filter(id=>isCreature(id)&&id!==o.copyHandId),sel=await pick('押し戻しの除外コスト（1枚）',pool,{info:'CREATUREは所属LEVELの野生山札の底へ循環。DISCARD能力は発動しない。'});if(!sel)return;confirm('押し戻しを宣言',`${esc(r.players[o.target].name)}へ押し戻しを宣言する。防御されてもコストは戻らない。`,()=>commit({type:'pushback',...o,id:sel[0]}));});
}

async function tradeDialog(){return toast('TRADEは廃止されました');}
function manualMenu(){let box=show('判定メモ',`<p>不正な無料DRAW・捨て札操作は封鎖したよ。HAND・妨害は専用ボタンから使用してね。</p><div class="modal-actions">${current()?.phase==='ACTIONS'&&humanTurn()&&current().actionPoints>0&&who()?.main&&!who().mainAbilityDisabled&&!who().status.some(st=>['SLEEP','STUN'].includes(st))&&E.mainStatusCleanseSource(current(),who())&&who().status?.length?b('MAIN能力：STATUS解除（1 ACTION）','main_cleanse','secondary'):''}${current()?.phase==='ACTIONS'&&humanTurn()&&current().actionPoints>0&&!current().explore&&who()?.hand.length&&who()?.main&&!who().mainAbilityDisabled&&!who().status.some(st=>['SLEEP','STUN'].includes(st))&&E.mainHandCycleSource(current(),who())?b('MAIN能力：手札を捨てて引く（1 ACTION）','main_cycle','secondary'):''}${who()?.main&&['C079','C122','C149','C154','C181'].includes(m(who().main).id)&&humanTurn()?b('MAIN COPYを選ぶ','maincopy','secondary'):''}${b('判定メモを残す','note','secondary')}${b('閉じる','close','ghost')}</div>`);
 box.querySelector('[data-action=main_cycle]')?.addEventListener('click',()=>{close();command('main_cycle');});
 box.querySelector('[data-action=main_cleanse]')?.addEventListener('click',()=>{close();command('main_cleanse');});
 box.querySelector('[data-action=maincopy]')?.addEventListener('click',()=>{close();command('maincopy');});box.querySelector('[data-action=note]').onclick=()=>{close();let x=prompt('ゲームログに記録する内容','');if(x)commit({type:'note',note:x});};box.querySelector('[data-action=close]').onclick=close;}
function runCPUs(){clearTimeout(botTimer);if(!current()||humanTurn()||current().phase==='FINISHED')return;let n=0;function tick(){const r=current();if(!r||humanTurn()||r.phase==='FINISHED'){render();return;}if(n++>90){toast('CPU進行に時間がかかっています。続行するには画面を再読み込みしてね');return;}try{if(pendingForHuman()){handlePendingEffects();handlePendingField();return;}Bot.performOne();safeSave();render();handlePendingEffects();}catch(e){console.error('CPU TURN ERROR',e);toast('CPU判定が停止：'+e.message);return;}botTimer=setTimeout(tick,delay);}botTimer=setTimeout(tick,delay);}

let lessonStep=0,lessonNetUsed=false;const lessonMaterials=new Set(),lessonCosts=new Set(),lessonSynergy=new Set();
const synergyChoices=[['C003_01','MAINが蟲種なら','成立'],['C004_01','MAINが蟲種なら','成立'],['C007_01','MAINが胞子種なら','不成立']];
function synergyCountPractice(){return [...lessonSynergy].filter(id=>id!=='C007_01').length;}
function synergyMarkup(){const n=synergyCountPractice();return `<div class="synergy-trainer"><div class="synergy-main"><strong>MAIN：S02 ハサミコ</strong><span>蟲種 / SYNERGYタグなし</span></div><p class="synergy-instruction">SUPPORTを2体選ぼう。カード画像で効果を確認できるよ。</p><div class="synergy-choices">${synergyChoices.map(([id,rule,result])=>`<button type="button" data-lesson-synergy="${id}" class="synergy-choice ${lessonSynergy.has(id)?'chosen':''}" aria-pressed="${lessonSynergy.has(id)}"><strong>${esc(m(id).name)} <small>（${esc(m(id).species)}）</small></strong><span>${esc(rule)}</span><em>${lessonSynergy.has(id)?(result==='成立'?'✓ 条件成立':'× 条件不成立'):'＋ SUPPORTに選ぶ'}</em></button>`).join('')}</div><div class="synergy-score ${lessonSynergy.size===2&&n===2?'success':''}"><span>配置 ${lessonSynergy.size}/2体</span><strong>SYNERGY ${n} / 2</strong></div><p class="synergy-feedback">${lessonSynergy.size<2?'2体を選ぶと成立数がわかるよ。':n===2?'✓ この編成で2つが同時成立！ L2の降下条件達成（移動は別途1 ACTION）。':'あと'+(2-n)+'つ必要。選んだカードのSUPPORT条件を確認してみよう。'}</p><p class="synergy-foot">※この練習は3カードの条件のみを厳密に計算。本番の全能力を完全自動認証する機能ではないよ。</p></div>`;}
const lessons=[
 {title:'冒険の全体像',lead:'8つの階層を下り、最深部の試練に挑もう。',body:'1人＋CPU3人。自分の番は「START → 2 ACTION → CAMP」。ORIGINはL8の試練突破、RETURNは地上に帰った人が勝利。',cards:[],action:'手番を練習する',hint:'本番とは別の練習画面。セーブやカード配置を変更しないよ。'},
 {title:'① START｜仲間を編成',lead:'MAIN1体とSUPPORT最大2体をセットする。',body:'「MAINを選択 → SUPPORT 1 → SUPPORT 2 → 確認」の順で編成する。SUPPORTは空きでもよい。画像タップは読むだけで、最後の確定までは盤面を変えない。MAINは主役の能力、SUPPORTは補助能力。配置前のカードはMAIN／SUPPORTを切り替えて比較できるよ。通常の編成変更はSTART時だけ。L1最初のCAPTURE成功2回は例外として直接SUPPORTへ。',cards:['S02_01','C002_01'],action:'START完了 → 探索へ',hint:'ここではS02「ハサミコ」をMAINとして練習するよ。'},
 {title:'② 探索｜1 ACTION使う',lead:'探索すると、通常は現在の階層の野生カード3枚を公開。',body:'無料で探索できるわけではなく1 ACTIONを消費する。使えるACTIONは1手番2回。ランタンの追加公開などは、その能力・ITEMを使ったときだけ。',cards:['C003_01','C001_01','C007_01'],action:'C003を調べる',hint:'カードをタップしてCAPや能力を読んでみよう。'},
 {title:'③ CAPTURE｜必要CAPと比較',lead:'捕獲力 ≥ カードのCAPなら獲得できる。',body:'例：MAIN「S02 ハサミコ」の捕獲力は基本1＋MAIN能力1＝2。C003のCAPは3。そこで簡易捕獲ネットを1枚使うと、合計3で捕獲成功。',cards:['S02_01','SI02_01','C003_01'],action:'ネットを使って捕獲成功',practice:'net',hint:'能力・ITEMの数値は実カードに基づく例。捕獲成功したCREATUREは通常捨て札へ。'},
 {title:'④ L1特例｜SUPPORTに直接配置',lead:'最初にCAPTURE成功した2体だけ、空きSUPPORTへ直接配置できる。',body:'通常は捨て札へ入るけど、L1最初の成功2回だけは即配置を選べる。MAIN＋SUPPORT2体が揃えばL1の突破条件を満たす。移動には別途1 ACTION必要。',cards:['S02_01','C003_01'],action:'2つめの方法 META を学ぶ',hint:'この特例は正式採用済み。3回目以降・METAでは通常どおり捨て札へ。'},
 {title:'⑤ 合計POWER｜3体の数字を足す',lead:'MAINとSUPPORT最大2体の印字POWを合計し、有効な補正を加える。',body:'今の合計POWERは自分とCPUの盤面に常時表示される。編成や妨害で値が変わると表示も更新。L2以降のGUARDIAN FORCE判定では、この合計POWERを必要値と比較する。',cards:['S02_01','C003_01','C004_01'],action:'POWER表示を確認',hint:'MAINだけではなくSUPPORTの印字POWも必ず足す。SYNERGYはカードごとの能力条件として残る。'},
 {title:'⑥ META｜同じ種族2体以上を素材に',lead:'CAPTURE以外にも、進化してカードを獲得できる。',body:'例：蟲種C002（META3）と蟲種C003（META1）を同時に素材にすると合計4。公開された蟲種C023（要求META2）を満たす。素材2枚は所属野生山札の底へ循環し、進化後カードは捨て札に獲得する。',cards:['C002_01','C003_01','C023_01'],action:'補給とCAMPを学ぶ',practice:'meta',hint:'素材は同一種族・2体以上で、合計METAが対象の数値以上。実際には手持ちの素材から選ぶよ。'},
 {title:'⑦ 補給｜COST枚の手札を支払う',lead:'ITEMの購入にはお金は使わない。',body:'市場のカードを1枚選び、印字COSTと同じ枚数の手札を捨てて補給。例：I09はCOST2なので手札を2枚捨てる。購入したITEMは自分の捨て札に入る。ITEM R2では市場公開3枚、購入後は3枚になるまで補充する。',cards:['I09_01','SI01_01','SI03_01'],action:'CAMPを練習する',practice:'cost',hint:'市場の公開数が減ってもCOSTやカード性能は変更しないよ。'},
 {title:'⑧ CAMP｜手札の循環を作る',lead:'STOWするカードだけ選び、ほかはKEEP。',body:'CAMP画面では捨て札へ送るカードを選ぶ。未選択のカードは手元にKEEP。その後、手札が5枚になるまでDRAW。KEEP5枚だと0枚しか引かない。山札が空になれば捨て札をシャッフルして再利用する。',cards:['SI01_01','SI02_01','SI03_01'],action:'チュートリアル完了',hint:'捕獲したカードがすぐ手札に来ないのはこの循環のため。'},
 {title:'練習完了！',lead:'本番は「START→2 ACTION→CAMP」の繰り返し。',body:'ITEM R2は初期7枚／市場3枚。L2〜L8では担当GUARDIANを突破すると降下する。カードをタップで拡大し、合計POWERは自分とCPUの盤面でいつでも確認できる。',cards:[],action:'ゲーム開始画面へ',hint:'複雑なCOPY・REACTIONなどはカード原文も確認してね。'}
];
function startTutorial(step=0){window.RinneDepth?.suspend();clearTimeout(botTimer);document.body.classList.remove('v091-task-open','v091-modal-open');$('app').inert=false;lessonStep=step;lessonNetUsed=false;lessonMaterials.clear();lessonCosts.clear();lessonSynergy.clear();drawTutorial();}
function drawTutorial(){
 const s=lessons[lessonStep],last=lessonStep===lessons.length-1;
 $('modal').classList.add('hide');$('app').innerHTML=`<main class="tutorial-page"><div class="tutorial-wrap"><div class="tutorial-head"><span class="eyebrow">RINNE LEARNING QUEST · ${lessonStep+1} / ${lessons.length}</span><button type="button" class="header-btn" id="lesson-close">✕ 練習を終了</button></div><h1>🎓 ${esc(s.title)}</h1><div class="lesson-progress"><i style="width:${((lessonStep+1)/lessons.length)*100}%"></i></div><p class="lesson-lead">${esc(s.lead)}</p><p class="lesson-text">${esc(s.body)}</p><div class="lesson-cards">${s.cards.map(id=>`<button type="button" data-lesson-card="${id}" aria-label="${esc(m(id).name)}のカードを拡大"><img src="${img(id)}" alt="${esc(m(id).name)}"><span>🔎 ${esc(m(id).name)}</span></button>`).join('')||'<div class="lesson-emblem">🧬<small>RINNE</small></div>'}</div><div class="lesson-exercise">${s.practice==='net'?`<p><b>練習：</b>捕獲力 2 ＋ ${lessonNetUsed?'ネット1 = 3（CAP3達成！）':'ネットを使えば +1'} </p><button type="button" class="btn ${lessonNetUsed?'secondary':'primary'}" id="lesson-net">${lessonNetUsed?'✓ ネットを使用済み':'＋ 簡易捕獲ネットを使う'}</button>`:''}${s.practice==='meta'?`<p><b>練習：</b>進化素材を2体選択。選択中 ${lessonMaterials.size}/2体</p>${['C002_01','C003_01'].map(id=>`<button class="btn ${lessonMaterials.has(id)?'primary':'secondary'}" data-lesson-material="${id}" type="button">${lessonMaterials.has(id)?'✓':'＋'} ${esc(m(id).name)} (META${m(id).meta})</button>`).join('')}`:''}${s.practice==='cost'?`<p><b>練習：</b>I09を買うために手札2枚を支払う。選択中 ${lessonCosts.size}/2枚</p>${['SI01_01','SI03_01'].map(id=>`<button class="btn ${lessonCosts.has(id)?'primary':'secondary'}" data-lesson-cost="${id}" type="button">${lessonCosts.has(id)?'✓':'＋'} ${esc(m(id).name)}</button>`).join('')}`:''}${s.practice==='synergy'?synergyMarkup():''}</div><p class="lesson-hint">💡 ${esc(s.hint)}</p><div class="lesson-actions"><button type="button" class="btn ghost" id="lesson-back" ${lessonStep===0?'disabled':''}>← 戻る</button><button type="button" class="btn primary" id="lesson-next">${esc(s.action)} →</button></div>${!last?'<p class="caption">カードをタップすると画像・能力全文を確認できるよ。</p>':''}</div></main>`;
 $('lesson-close').onclick=()=>{if(current()){render();runCPUs();}else landing();};
 $('lesson-back').onclick=()=>{lessonStep=Math.max(0,lessonStep-1);drawTutorial();};
 $('lesson-next').onclick=()=>{if(last){if(current()){render();runCPUs();}else landing();return;}if(s.practice==='net'&&!lessonNetUsed){toast('まずネットを使って捕獲力を3にしよう');return;}if(s.practice==='meta'&&lessonMaterials.size!==2){toast('進化素材の2体を選ぼう');return;}if(s.practice==='cost'&&lessonCosts.size!==2){toast('支払いの手札2枚を選ぼう');return;}if(s.practice==='synergy'&&(lessonSynergy.size!==2||synergyCountPractice()!==2)){toast('SYNERGYを同時に2つ成立させよう。カードのSUPPORT条件を確認してね');return;}lessonStep++;drawTutorial();};
 $('lesson-net')?.addEventListener('click',()=>{lessonNetUsed=true;drawTutorial();});
 $('app').querySelectorAll('[data-lesson-synergy]').forEach(el=>el.onclick=()=>{const id=el.dataset.lessonSynergy;if(lessonSynergy.has(id))lessonSynergy.delete(id);else if(lessonSynergy.size<2)lessonSynergy.add(id);else {toast('SUPPORTは最大2体まで');return;}drawTutorial();});
 $('app').querySelectorAll('[data-lesson-material]').forEach(el=>el.onclick=()=>{let id=el.dataset.lessonMaterial;if(lessonMaterials.has(id))lessonMaterials.delete(id);else lessonMaterials.add(id);drawTutorial();});
 $('app').querySelectorAll('[data-lesson-cost]').forEach(el=>el.onclick=()=>{let id=el.dataset.lessonCost;if(lessonCosts.has(id))lessonCosts.delete(id);else lessonCosts.add(id);drawTutorial();});
 $('app').querySelectorAll('[data-lesson-card]').forEach(el=>el.onclick=()=>{const id=el.dataset.lessonCard;const x=show(m(id).name,cardDetailMarkup(id)+`<div class="modal-actions">${b('練習に戻る','back','primary')}</div>`);x.querySelector('[data-action=back]').onclick=close;});
}


document.addEventListener('keydown',event=>{
 const modal=$('modal'),inModal=modal&&!modal.classList.contains('hide');
 const layer=inModal?modal:$('v091-task');if(!layer)return;
 if(event.key==='Escape'){if(inModal&&(pendingForHuman()||modal.querySelector('[data-modal-must-resolve]'))){event.preventDefault();return;}event.preventDefault();if(inModal)$('close-dialog')?.click();else route('v91_board');return;}
 if(event.key!=='Tab')return;
 const all=[...layer.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),a[href],summary,[tabindex="0"]')].filter(x=>x.getClientRects().length&&!x.closest('[inert]'));
 if(!all.length)return;const first=all[0],last=all[all.length-1];
 if(event.shiftKey&&(document.activeElement===first||!layer.contains(document.activeElement))){event.preventDefault();last.focus();}
 else if(!event.shiftKey&&(document.activeElement===last||!layer.contains(document.activeElement))){event.preventDefault();first.focus();}
});

async function chooseOtherSeat(title,targets){const box=show(title,`<div class="modal-actions">${targets.map(q=>b(q.name,'seat'+q.seat,'secondary')).join('')}</div>`);return await new Promise(resolve=>{for(const q of targets)box.querySelector(`[data-action="seat${q.seat}"]`).onclick=()=>{close();resolve(q.seat);};box.querySelector('#close-dialog').onclick=()=>{close();resolve(null);};});}
async function revisedGiftItem(id){const r=current(),p=who(),code=m(id).id;const target=await chooseOtherSeat(m(id).name,r.players.slice(1));if(target===null)return;let card;if(code==='I37'){const choice=await pick('渡す手札を1枚選択',p.hand.filter(x=>x!==id),{min:1,max:1,info:'同意不要。カードは相手の手札に入る。'});if(!choice)return;card=choice[0];}commit({type:'use_item',id,target,card});}
async function revisedPheromone(id){const r=current();const targets=r.players.slice(1).filter(q=>q.level===who().level&&q.stray.length);if(targets.length){const box=show('誘導フェロモン',`<div class="modal-actions">${b('公開カードを引き直す','redraw','primary')}${b('相手の遊動個体を移す','stray','secondary')}</div>`);const mode=await new Promise(resolve=>{for(const mode of ['redraw','stray'])box.querySelector(`[data-action="${mode}"]`).onclick=()=>{close();resolve(mode);};box.querySelector('#close-dialog').onclick=()=>{close();resolve(null);};});if(!mode)return;if(mode==='stray'){const target=await chooseOtherSeat('遊動個体を移す相手',targets);if(target!==null)commit({type:'use_item',id,target,mode:'stray'});return;}}const choice=await pick('引き直す公開カード',r.explore.ids,{min:0,max:Math.min(2,r.explore.ids.length),info:'通常探索の公開カードを最大2枚引き直す。'});if(choice)commit({type:'use_item',id,redrawIds:choice});}
async function giveCreatureDialog(){const r=current(),p=who();const target=await chooseOtherSeat('CREATUREを渡す相手',r.players.slice(1).filter(q=>q.level===p.level));if(target===null)return;const choice=await pick('相手の捨て札へ渡すCREATURE',p.hand.filter(id=>['STARTER','WILD','GUARDIAN'].includes(m(id).kind)),{min:1,max:1});if(choice)commit({type:'main_give_creature',target,id:choice[0]});}
async function chooseCleanseHand(id){const p=who(),box=show('MAINのSTATUSを1つ解除',`<div class="modal-actions">${p.status.map(st=>b(st,st,'secondary')).join('')}</div>`);for(const status of p.status)box.querySelector(`[data-action="${status}"]`).onclick=()=>{close();commit({type:'hand_use',id,status});};}

window.gameRoom=null;landing();
})();

