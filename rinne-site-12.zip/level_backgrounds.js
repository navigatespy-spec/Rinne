/* Approved LEVEL 1–8 backgrounds, supplied in this order. Presentation only. */
'use strict';
window.RINNE_DEPTH_IMAGES = Object.freeze({
  "1": "assets/depths/rinne_background_l1_work162.jpeg",
  "2": "assets/depths/rinne_background_l2_work162.jpeg",
  "3": "assets/depths/rinne_background_l3_work162.jpeg",
  "4": "assets/depths/rinne_background_l4_work162.jpeg",
  "5": "assets/depths/rinne_background_l5_work162.jpeg",
  "6": "assets/depths/rinne_background_l6_work162.jpeg",
  "7": "assets/depths/rinne_background_l7_work162.jpeg",
  "8": "assets/depths/rinne_background_l8_work162.jpeg"
});
